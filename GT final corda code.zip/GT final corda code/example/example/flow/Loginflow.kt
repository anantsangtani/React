package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.flow.Loginflow.Acceptor
import com.example.flow.Loginflow.Initiator
import net.corda.core.contracts.StateAndContract
import net.corda.core.contracts.requireThat
import net.corda.core.flows.*
import net.corda.core.identity.Party
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.ProgressTracker.Step
import com.example.dao.ApplicationDao
import com.example.DTO.UserDTO
import com.example.model.user
import net.corda.core.utilities.unwrap






/**
 * This flow allows two parties (the [Initiator] and the [Acceptor]) to come to an agreement about the IOU encapsulated
 * within an [AssetState].
 *
 * In our simple example, the [Acceptor] always accepts a valid IOU.
 *
 * These flows have deliberately been implemented by using only the call() method for ease of understanding. In
 * practice we would recommend splitting up the various stages of the flow into sub-routines.
 *
 * All methods called within the [FlowLogic] sub-class need to be annotated with the @Suspendable annotation.
 */
object Loginflow {
    @InitiatingFlow
    @StartableByRPC
    class Initiator(val UserDTO: UserDTO,val otherParty: Party) : FlowLogic<List<UserDTO>>() {
        /**
         * The progress tracker checkpoints each stage of the flow and outputs the specified messages when each
         * checkpoint is reached in the code. See the 'progressTracker.currentStep' expressions within the call() function.
         */

        /**
         * The flow logic is encapsulated within the call() method.
         */
        @Suspendable
        override fun call(): List<UserDTO> {
            println("UsertDTO inside flow"+ UserDTO)
            // Obtain a reference to the notary we want to use.
            val otherPartyFlow = initiateFlow(otherParty)
            var customerList = otherPartyFlow.sendAndReceive<List<UserDTO>>(payload = UserDTO)
                    .unwrap(validator = { customerList -> customerList })
            println(customerList)
            return customerList
        }
    }

    @InitiatedBy(Initiator::class)
    class Acceptor(val otherPartyFlow: FlowSession) : FlowLogic<Unit>() {
        @Suspendable
        override fun call() {
            val applicationDao = ApplicationDao()
            var nodeName = serviceHub.myInfo.legalIdentities.first()
            var UserDTO = otherPartyFlow.receive(UserDTO::class.java).unwrap (validator = {UserDTO -> UserDTO})
            var customerList = applicationDao.searchUser(nodeName.toString(), otherPartyFlow.counterparty.name.toString(),
                    UserDTO.user_name,UserDTO.password,UserDTO.user_type)
            otherPartyFlow.send(customerList.toList())
        }
    }
}
