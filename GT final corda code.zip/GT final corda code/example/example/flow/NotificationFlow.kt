//package com.example.flow
//
//import co.paralleluniverse.fibers.Suspendable
//import com.example.flow.Loginflow.Acceptor
//import com.example.flow.Loginflow.Initiator
//import net.corda.core.contracts.StateAndContract
//import net.corda.core.contracts.requireThat
//import net.corda.core.flows.*
//import net.corda.core.identity.Party
//import net.corda.core.transactions.SignedTransaction
//import net.corda.core.transactions.TransactionBuilder
//import net.corda.core.utilities.ProgressTracker
//import net.corda.core.utilities.ProgressTracker.Step
//import com.example.dao.NotificationDao
//import com.example.DTO.SearchNotificationDTO
//import com.example.DTO.NotificationDTO
//import com.example.model.user
//import net.corda.core.utilities.unwrap
//
//
//
//
//
//
///**
// * This flow allows two parties (the [Initiator] and the [Acceptor]) to come to an agreement about the IOU encapsulated
// * within an [AssetState].
// *
// * In our simple example, the [Acceptor] always accepts a valid IOU.
// *
// * These flows have deliberately been implemented by using only the call() method for ease of understanding. In
// * practice we would recommend splitting up the various stages of the flow into sub-routines.
// *
// * All methods called within the [FlowLogic] sub-class need to be annotated with the @Suspendable annotation.
// */
//object NotificationFlow {
//    @InitiatingFlow
//    @StartableByRPC
//    class Initiator(val SearchNotificationDTO: SearchNotificationDTO,val otherParty: Party) : FlowLogic<List<NotificationDTO>>() {
//        /**
//         * The progress tracker checkpoints each stage of the flow and outputs the specified messages when each
//         * checkpoint is reached in the code. See the 'progressTracker.currentStep' expressions within the call() function.
//         */
//
//        /**
//         * The flow logic is encapsulated within the call() method.
//         */
//        @Suspendable
//        override fun call(): List<NotificationDTO> {
//            println("UsertDTO inside flow"+ SearchNotificationDTO)
//            // Obtain a reference to the notary we want to use.
//            val otherPartyFlow = initiateFlow(otherParty)
//            var customerList = otherPartyFlow.sendAndReceive<List<NotificationDTO>>(payload = SearchNotificationDTO)
//                    .unwrap(validator = { customerList -> customerList })
//            println(customerList)
//            return customerList
//        }
//    }
//
//    @InitiatedBy(Initiator::class)
//    class Acceptor(val otherPartyFlow: FlowSession) : FlowLogic<Unit>() {
//        @Suspendable
//        override fun call() {
//            val notificationDao = NotificationDao()
//            var nodeName = serviceHub.myInfo.legalIdentities.first()
//            var SearchNotificationDTO = otherPartyFlow.receive(SearchNotificationDTO::class.java).unwrap (validator = {SearchNotificationDTO -> SearchNotificationDTO})
//            var customerList = notificationDao.getNotification(nodeName.toString(),
//                    SearchNotificationDTO.user_id)
//            otherPartyFlow.send(customerList.toList())
//        }
//    }
//}
