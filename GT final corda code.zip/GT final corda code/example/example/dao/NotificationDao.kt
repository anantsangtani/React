package com.example.dao

import com.example.connection.DatabaseConnection
import com.example.DTO.NotificationDTO
import com.example.DTO.UpdateFlagDTO
//import com.example.model.UserDetails
import java.sql.*
import java.util.Date
import java.util.Calendar
import java.time.LocalDate
import java.time.Instant
import java.text.SimpleDateFormat
import java.lang.*;


/**
 * Created by 397947 on 5/26/2017.
 */

class NotificationDao {

    fun createNotification(nodeName: String) {
        println("inside dao")
        println(nodeName)
        val  connection = DatabaseConnection.getConnection(nodeName)
        var statement: PreparedStatement? = null
        var rs: ResultSet? = null

        try {
            val sql: String? = "CREATE TABLE IF NOT EXISTS NotificationTable5 (MessageID VARCHAR(50) PRIMARY KEY,Intendedfor Varchar(150),UserID VARCHAR(50) NULL, MessageText VARCHAR(150) NULL, ReadFlag boolean  NULL)"
            statement = connection.prepareStatement(sql)
            println("tablestatement-->"+statement)
            statement.execute()
            println("table created")
        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            //closeConnection(connection, statement, rs)
        }
    }


    fun insertNotificationDetails(nodeName: String,notificationDetails: List<NotificationDTO>):NotificationDTO? {

        val  connection = DatabaseConnection.getConnection(nodeName)
       println("Notifivation************************************************"+notificationDetails)
        var statement: PreparedStatement? = null
        var rs: ResultSet? = null
        var rs1: ResultSet? = null
        var message_id:String=""
        var Notification:NotificationDTO?=null

        try {
            val sql: String? = "INSERT INTO NotificationTable5(MessageID, Intendedfor, UserID, MessageText, ReadFlag) VALUES (?,?,?,?,?)"
            message_id = "Mes"+(Math.abs(Math.ceil(Math.random()*1000000))).toString().replace(".0","")
            statement = connection.prepareStatement(sql)
            println("messageId"+message_id)
            for(notificationDetail in notificationDetails) {
                statement.setString(1, message_id)
                statement.setString(2, notificationDetail.Intendedfor)
                statement.setString(3, notificationDetail.UserID)
                statement.setString(4, notificationDetail.MessageText)
                statement.setBoolean(5, notificationDetail.ReadFlag)
                statement.executeUpdate()
                println("statement***********"+statement)
                println("values inserted")
            }
            println("messageId"+message_id)

            val sql1: String="select * from NotificationTable5 where  MessageID = ? "
            statement=connection.prepareStatement(sql1)
            statement.setString(1, message_id)
            rs1=statement.executeQuery()
            println("result------------"+rs1)
            while(rs1.next()) {
                Notification = NotificationDTO(rs1.getString("MessageID"), rs1.getString("Intendedfor"), rs1.getString("UserID"), rs1.getString("MessageText"), rs1.getBoolean("ReadFlag"))
            }
            println("Notification"+Notification)
        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
           // closeConnection(connection, statement, rs)
        }
        return Notification;
    }


    fun generateNotification(nodeName: String,Lessee:String,Admin:String):String {
        println("inside the viewContract")
        println(nodeName)
        var contract_id:String=""
        val  connection = DatabaseConnection.getConnection(nodeName)
        val  connection1 = DatabaseConnection.getConnection(Lessee)
        val  connection2 = DatabaseConnection.getConnection(Admin)
        println("connection"+connection)
        var NotificationList : MutableList<NotificationDTO> = mutableListOf()
        var statement: PreparedStatement? = null
        var statement1: PreparedStatement? = null
        var statement2: PreparedStatement? = null
        var rs: ResultSet? = null
        var status:String=""
        var rs1: ResultSet? = null
        var formatter = SimpleDateFormat("yyyy-MM-dd")
        var whereClause = StringBuilder()

        try {
            val sql1: String? ="select *  from contractDetailsTableTT5"
            statement=connection.prepareStatement(sql1)
            rs1=statement.executeQuery()
            while(rs1.next()) {

                println(rs1.getString("status"))
                if ((rs1.getString("status")).equals("Fully Signed")) {

                    // val now = Calendar.getInstance()
                    var lessor_id: String = rs1.getString("lessor_id")
                    contract_id = rs1.getString("contract_id")
                    var AssetRefID: String = rs1.getString("AssetRefID")


                    //val month1 = now.get(Calendar.MONTH) + 1
                    // println("month-----------" + month1)
                    var s = rs1.getDate("end_date")
                    println(s.getMonth())
                    val now = Date()
                    val todayDate = formatter.format(now)
                    println("todat--------" + todayDate)
                    var endDate: String = formatter.format(rs1.getDate("end_date"))
                    println("endDate------" + endDate)
                    println("enddate" + endDate)

                    //var endmonth = Integer.parseInt(endDate)

                    // println("endmonth" + endmonth)


//                  var endmonth=rs.getDate("end_date");
//                   var endmonth1=endmonth.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
//                     val endate2= endmonth1.getMonthValue()
//                println("endmonth1---------"+endmonth1)

                    var message_id = "Mes" + (Math.abs(Math.ceil(Math.random() * 1000000))).toString().replace(".0", "")
                    if (todayDate.equals(endDate)) {
                        println("inside condition")
                        val sql3: String = "update contractDetailsTableTT5 set status=? where contract_id=? "
                        statement = connection.prepareStatement(sql3)
                        statement1 = connection1.prepareStatement(sql3)
                        statement.setString(1, "Breached")
                        statement.setString(2, contract_id)
                        statement.executeUpdate()
                        statement1.setString(1, "Breached")
                        statement1.setString(2, contract_id)
                        statement1.executeUpdate()

                        val sql4: String? = "Update AssetDetailsTableT5 set status=? where asset_id =?"
                        statement = connection.prepareStatement(sql4)
                        statement2 = connection2.prepareStatement(sql4)
                        statement.setString(1, "Approved-Available")
                        statement.setString(2, AssetRefID)
                        statement2.setString(1, "Approved-Available")
                        statement2.setString(2, AssetRefID)
                        println(statement2)
                        statement.executeUpdate()
                        statement2.executeUpdate()

                        val sql: String? = "INSERT INTO NotificationTable5(MessageID, Intendedfor, UserID, MessageText, ReadFlag) VALUES (?,?,?,?,?)"
                        statement = connection.prepareStatement(sql)
                        statement.setString(1, message_id)
                        statement.setString(2, "The period of the " + contract_id + "has expired on" + todayDate)
                        statement.setString(3, lessor_id)
                        statement.setString(4, "ok")
                        statement.setBoolean(5, false)
                        statement.executeUpdate()
                        println("Notification inserted")
                        status = "Updated"
                    } else {

                        status="failed"
                    }
                }
                }


        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            // closeConnection(connection, statement, rs)
        }
        return status
    }


    fun getNotificationById(nodeName: String,UserId:String):List<NotificationDTO>
    {
        val  connection = DatabaseConnection.getConnection(nodeName)
        var statement: PreparedStatement? = null
        var rs1: ResultSet? = null
        var message_id:String=""
        var NotificationDetails : MutableList<NotificationDTO> = mutableListOf()
        try {

                val sql1: String="select * from NotificationTable5 where  UserID = ? "
                statement=connection.prepareStatement(sql1)
                statement.setString(1, UserId)
                rs1=statement.executeQuery()
                println("result------------"+rs1)
                while(rs1.next()) {
                   var  Notification = NotificationDTO(rs1.getString("MessageID"), rs1.getString("Intendedfor"), rs1.getString("UserID"), rs1.getString("MessageText"), rs1.getBoolean("ReadFlag"))
                    NotificationDetails.add(Notification)
                }
                println("Notification"+NotificationDetails)
            } catch (se: SQLException) {
                System.out.println(se.message)
            } finally {
                // closeConnection(connection, statement, rs)
            }
            return NotificationDetails;
        }
     fun UpdateContract(Lessor: String,Lessee:String,Admin:String):String{

         val  connection = DatabaseConnection.getConnection(Lessor)
         val  connection1 = DatabaseConnection.getConnection(Lessee)
         val  connection2 = DatabaseConnection.getConnection(Admin)
         println("connection"+connection)
         var NotificationList : MutableList<NotificationDTO> = mutableListOf()
         var statement: PreparedStatement? = null
         var statement2: PreparedStatement? = null
         var rs2: ResultSet? = null
         var rs1: ResultSet? = null
         var formatter = SimpleDateFormat("MM")
         var whereClause = StringBuilder()
         var status:String="ok"

         try {
             val sql1: String? ="select *  from contractDetailsTableTT5"
             statement=connection.prepareStatement(sql1)
             rs1=statement.executeQuery()
             println(rs1)
             while(rs1.next()) {
                 // val now = Calendar.getInstance()

                 var contract_id:String=rs1.getString("contract_id")
                 var breachPeriod:Int=rs1.getInt("breachPeriod")
                 var AssetRefID:String=rs1.getString("AssetRefID")
                 println(contract_id)
                 println(breachPeriod)

                 val sql2: String? ="select paymentmonth,status from paymentschedule4 where contract_id=?"
                 statement=connection.prepareStatement(sql2)
                 statement.setString(1,contract_id)
                 rs2=statement.executeQuery()
                 println(rs2)
                 while(rs2.next()) {
                     // val now = Calendar.getInstance()
                     var duedate: String = formatter.format(rs2.getDate("paymentmonth"))
                     var status:String =rs2.getString("status")
                      println("duedate"+duedate)
                     println("status"+status)
                     val now = Calendar.getInstance()
                     now.add(Calendar.MONTH,-breachPeriod)
                     println()
                     println(formatter.format(now.get(Calendar.MONTH) + 1))
                    if(status=="NotPaid")
                    {
                          if(formatter.format(now.get(Calendar.MONTH) + 1).equals(duedate))
                          {
                              println("inside condition")
                              val sql3: String="update contractDetailsTableTT5 set status=? where contract_id=? "
                              statement=connection.prepareStatement(sql3)
                              statement2=connection1.prepareStatement(sql3)
                              statement.setString(1,"Breached")
                              statement.setString(2,contract_id)
                              statement.executeUpdate()
                              statement2.setString(1,"Breached")
                              statement2.setString(2,contract_id)
                              statement2.executeUpdate()
                              val sql4: String? = "Update AssetDetailsTableT5 set status=? where asset_id =?"
                              statement = connection.prepareStatement(sql4)
                              statement2 = connection2.prepareStatement(sql4)
                              statement.setString(1, "Approved-Available")
                              statement.setString(2, AssetRefID)
                              statement2.setString(1, "Approved-Available")
                              statement2.setString(2,AssetRefID)
                              println(statement2)
                              statement.executeUpdate()
                              statement2.executeUpdate()
                          }
                    }
//                     var today = formatter.format(now)
//                     println("todaydete---" + today)
//                     if (today.equals(duedate)) {
//                         println("ok")
//                     }
                 }


//                 var message_id = "Mes" + (Math.abs(Math.ceil(Math.random() * 1000000))).toString().replace(".0", "")
//                 if (todayDate.equals(endDate)) {
//                     var notification = NotificationDTO(message_id, " contract is going to expire", lessor_id, "ok", false)
//                     println("customer---------------" + notification)
//                     NotificationList.add(notification)
//
//
//                 }
//                 else
//                 {
//                     var notification = NotificationDTO("", "", "", "",false)
//
//                 }
             }


         } catch (se: SQLException) {
             System.out.println(se.message)
         } finally {
             // closeConnection(connection, statement, rs)
         }
         return status
     }



    fun UpdateFlag(Nodename: String,UpdateFlagDetails:UpdateFlagDTO):String
    {
        val  connection = DatabaseConnection.getConnection(Nodename)
        var statement: PreparedStatement? = null
        var status:String=""
        println(UpdateFlagDetails)
        try {

            val sql: String="update NotificationTable5 set ReadFlag=? where UserID=? "
                statement=connection.prepareStatement(sql)
            for(readflag in UpdateFlagDetails.readFlag)
            {
                val readflag1 = readflag.toBoolean()
                println(readflag1)
                statement.setBoolean(1,readflag1)
                statement.setString(2, UpdateFlagDetails.id)
                statement.executeUpdate()
                status = "success"
            }


        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            // closeConnection(connection, statement, rs)
        }
        return status
    }

    }










