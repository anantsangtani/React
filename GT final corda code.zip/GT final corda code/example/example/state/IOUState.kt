package com.example.state

import com.example.schema.IOUSchemaV1
import com.example.model.asset
import com.example.contract.AssetContract
import net.corda.core.contracts.ContractState
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState

/**
 * The state object recording IOU agreements between two parties.
 *
 * A state must implement [ContractState] or one of its descendants.
 *
 * @param value the value of the IOU.
 * @param lender the party issuing the IOU.
 * @param borrower the party receiving and approving the IOU.
 */
data class IOUState(val Asset: asset,
                    val sender: Party,
                    var recipient: Party,
                    val contract: AssetContract,
                    override val linearId: UniqueIdentifier = UniqueIdentifier()):
        LinearState, QueryableState {
    /** The public keys of the involved parties. */
    override val participants: List<AbstractParty> get() = listOf(sender,recipient)


    override fun generateMappedObject(schema: MappedSchema): PersistentState {


        return when (schema) {
            is IOUSchemaV1 -> IOUSchemaV1.assetDetails(
                    asset_id =this.Asset.asset_id,
                    name = this.Asset.name.toString(),
                    address = this.Asset.address.toString(),
                    city = this.Asset.city.toString(),
                    state = this.Asset.state.toString(),
                    country = this.Asset.country.toString(),
                    zipcode = this.Asset.zipcode.toString(),
                    lessor_id = this.Asset.lessor_id.toString(),
                    currentOccupantID=this.Asset.currentOccupantID.toString(),
                    status=this.Asset.status.toString(),
                    approvedBy=this.Asset.approvedBy.toString()
            )
            else -> throw IllegalArgumentException("Unrecognised schema $schema")
        }
    }

//    private fun  generateAssetId(asset_id: String?): String {
//        if(null!= asset_id && !"".equals(asset_id)){
//            return asset_id
//        }
//        var generateAssetId = "Ref"+(Math.abs(Math.ceil(Math.random()*1000000))).toString().replace(".0","")
//        this.Asset.asset_id = generateAssetId
//
//        return generateAssetId
//    }
    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(IOUSchemaV1)
}
