package com.example.state

import com.example.schema.IOUSchemaV1
import com.example.model.contract
import com.example.contract.AssetContract
import net.corda.core.contracts.ContractState
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState

/**
 * The state object recording IOU agreements between two parties.
 *
 * A state must implement [ContractState] or one of its descendants.
 *
 * @param value the value of the IOU.
 * @param lender the party issuing the IOU.
 * @param borrower the party receiving and approving the IOU.
 */
data class LessorContractState(val Contract: contract,
                    val sender: Party,
                    val recipient: Party,
                    val contract: AssetContract,
                    override val linearId: UniqueIdentifier = UniqueIdentifier()):
        LinearState, QueryableState {
    /** The public keys of the involved parties. */
    override val participants: List<AbstractParty> get() = listOf(sender, recipient)

    override fun generateMappedObject(schema: MappedSchema): PersistentState {

        val paymentDetailsList = mutableListOf<IOUSchemaV1.paymentDetails>()
        val finalPaymentList = this.Contract.paymentDetails
        for(finalPayment in finalPaymentList){
            paymentDetailsList.add(IOUSchemaV1.paymentDetails(amount = finalPayment.amount, duedate = finalPayment.duedate))
        }

        return when (schema) {
            is IOUSchemaV1 -> IOUSchemaV1.contract(
                    contract_id =contract_id,
                    AssetRefID=this.Contract.AssetRefID.toString(),
                    contract_name = this.Contract.contract_name.toString(),
                    lessor_id = this.Contract.lessor_id.toString(),
                    lesse_id = this.Contract.lesse_id.toString(),
                    description = this.Contract.description.toString(),
                    start_date = this.Contract.start_date.toString(),
                    end_date = this.Contract.end_date.toString(),
                    frequency = this.Contract.frequency.toString(),
                    amount=this.Contract.amount,
                    status=this.Contract.status.toString(),
                    comments=this.Contract.comments.toString(),
                    paymentDetails=paymentDetailsList.toList(),
                    breachPeriod=this.Contract.breachPeriod
            )
            else -> throw IllegalArgumentException("Unrecognised schema $schema")
        }
    }
    val contract_id = genarateContractId(this.Contract.contract_id)
    private fun  genarateContractId(contract_id: String?): String {
        if(null!= contract_id && !"".equals(contract_id)){
            return contract_id
        }
        var genaratedContractId = "Ref"+(Math.abs(Math.ceil(Math.random()*1000000))).toString().replace(".0","")
        this.Contract.contract_id = genaratedContractId

        return genaratedContractId
    }
    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(IOUSchemaV1)
}
