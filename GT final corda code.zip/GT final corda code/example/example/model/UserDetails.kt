package com.example.model
import net.corda.core.serialization.CordaSerializable

/**
 * Created by 397947 on 6/2/2017.
 */
/**
 * A simple class representing an Customer.
 *
 * This is the data structure that the parties will reach agreement over. These data structures can be arbitrarily
 * complex. See https://github.com/corda/corda/blob/master/samples/irs-demo/src/main/kotlin/net/corda/irs/contract/IRS.kt
 * for a more complicated example.
 *
 * @param value the Customer's value.
 */
@CordaSerializable
data class UserDetails(
        var user_id: String?,
        var name: String?,
        var address: String?,
        var contact_no: String?,
        var city: String?,
        var state: String?,
        var country: String?,
        var zipcode: String?


) {
    override fun toString(): String {
        return "UserDetails(user_id='$user_id', name='$name', address='$address', contact_no='$contact_no', city='$city', state='$state',country='$country',zipcode='$zipcode')"
    }

    override fun equals(other: Any?): Boolean {
        return super.equals(other)
    }

    override fun hashCode(): Int {
        return super.hashCode()
    }
}



