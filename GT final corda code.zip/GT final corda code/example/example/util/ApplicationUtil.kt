package com.example.util

import net.corda.core.identity.CordaX500Name
//import net.corda.core.identity.CordaX500Name
import net.corda.core.messaging.CordaRPCOps
import java.text.ParseException
import java.time.Instant
import java.util.Date
import java.text.SimpleDateFormat



/**
 * Created by cordadev1 on 6/3/2017.
 */
object ApplicationUtil {

    fun getRegulatoryName() : String {
        println("inside util")
        return ("O=PartyC,L=Paris,C=FR")
    }

    fun  getPartyName(nodeName: String): String  {
        var partyName : String = ""
         if(("PartyA").equals(nodeName)){
            partyName =("O=PartyA,L=London,C=GB")
        } else if(("PartyB").equals(nodeName)){
            partyName = ("O=PartyB,L=New York,C=US")
        }  else if(("Controller").equals(nodeName)){
            partyName = ("O=Controller,L=London,C=GB")
        } else if(("PartyD").equals(nodeName)){
           partyName = ("O=PartyD,L=Rome,C=FR")
        }
        return partyName
    }
}