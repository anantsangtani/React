package com.example.DTO

import net.corda.core.serialization.CordaSerializable
import java.io.InputStream

/**
 * Created by 397947 on 5/24/2017.
 */
@CordaSerializable
data class ContractDTO(

        var contract_id: String?,
        var AssetRefID: String?,
        var contract_name: String?,
        var description: String?,
        var start_date: String?,
        var end_date: String?,
        var frequency: String?,
        var amount: Float,
        var lessor_id: String?,
        var lesse_id: String?,
        var status: String?,
        var comments: String?,
        var paymentDetails: List<PaymentDTO>,
        var breachPeriod: Int


)