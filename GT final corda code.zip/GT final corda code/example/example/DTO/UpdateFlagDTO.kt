package com.example.DTO

import net.corda.core.serialization.CordaSerializable
import java.io.InputStream

/**
 * Created by 397947 on 5/24/2017.
 */
@CordaSerializable
data class UpdateFlagDTO(

        var readFlag : List<String>,
        var  id: String



)