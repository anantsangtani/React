package com.example.api


//import com.example.flow.AssetApprovalFlow.Initiator
import com.example.state.AssetState
import com.example.state.LessorContractState
import com.example.DTO.UserDTO
import com.example.DTO.FileStatusDTO
import com.example.DTO.ContractDTO
import com.example.DTO.UserDetailsDTO
import com.example.DTO.PaymentDTO
import com.example.DTO.AssetDTO
import com.example.DTO.ResultDTO
import com.example.DTO.LesseeDTO
import com.example.DTO.UpdateFlagDTO
import com.example.DTO.NotificationDTO
import com.example.DTO.FileDTO
import com.example.DTO.detailDTO
import com.example.DTO.SearchNotificationDTO
import com.example.model.user
import com.example.model.filedetail
import com.example.model.asset
import com.example.model.Notification
import com.example.model.paymentDetails
import com.example.model.contract
import com.example.util.ApplicationUtil
import com.example.util.ApplicationConstants
import com.example.dao.ApplicationDao
import com.example.dao.NotificationDao
import com.example.contract.AssetContract
import com.example.contract.LessorContract
import net.corda.core.identity.CordaX500Name
import net.corda.core.messaging.CordaRPCOps
import net.corda.core.messaging.startTrackedFlow
import net.corda.core.messaging.vaultQueryBy
import net.corda.core.utilities.getOrThrow
import net.corda.core.utilities.loggerFor
import org.slf4j.Logger
import javax.ws.rs.*
import java.util.Date
import com.example.flow.*
import net.corda.core.identity.Party
import javax.ws.rs.core.MediaType
import javax.ws.rs.core.Response
import javax.ws.rs.core.Response.Status.BAD_REQUEST
import javax.ws.rs.core.Response.Status.CREATED
import java.io.FileOutputStream
import java.io.File



val SERVICE_NAMES = listOf("Controller", "Network Map Service")

// This API is accessible from /api/example. All paths specified below are relative to it.
@Path("example")
class GTApi(private val rpcOps: CordaRPCOps) {
    private val myLegalName: CordaX500Name = rpcOps.nodeInfo().legalIdentities.first().name

    companion object {
        private val logger: Logger = loggerFor<GTApi>()
    }

//    @POST
//    @Path("create-user")
//    fun createUSER(UserDTO: List<UserDTO>): Response {
//        println("inside the  registration api")
//        var customerStates = mutableListOf<AssetState>()
//        var me: Party = rpcOps.nodeInfo().legalIdentities.first()
//        println(me)
//        val Admin = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyD"))
//        val Adminnode = rpcOps.wellKnownPartyFromX500Name(Admin)
//        println("check"+Admin)
//        println("test"+Adminnode)
//        val repository:CordaX500Name = CordaX500Name.parse(ApplicationUtil.getRegulatoryName())
//        val otherParty = rpcOps.wellKnownPartyFromX500Name(repository) ?: return Response.status(BAD_REQUEST).entity("Party named $repository cannot be found.\n").build()
//        println(me)
//        println(otherParty)
//        println(UserDTO)
//            for (UserDTO in UserDTO) {
//                println("UserDTO.user_type" + UserDTO.user_type)
//                    var user = user(UserDTO.user_id,UserDTO.user_type, UserDTO.password)
//                    println("customerDetails" + user)
//                    println("customerstate")
//                    var UserState = AssetState(user, me, otherParty,AssetContract())
//                    println("customerstate" + UserState)
//                    customerStates.add(UserState)
//
//            }
////
//           var msg: String =""
//        return try {
//            println("calling flow")
//
//            if(Adminnode == me)
//            {
//                val result = rpcOps
//                        .startTrackedFlow(AssetCreationFlow::Initiator, customerStates.toList(), otherParty).returnValue
//
//                msg = String.format("Transaction is %s saved successfully.", result)
//                Response.status(CREATED).entity(msg).build()
//            }
//            else
//            {
//                msg = String.format("Only Admin have an authority to create user")
//                Response.status(CREATED).entity(msg).build()
//            }
//
//        } catch (ex: Throwable) {
//            logger.error(ex.message, ex)
//            Response.status(BAD_REQUEST).entity(ex.message!!).build()
//        }
//    }



@POST
@Path("login")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
fun loginUser(UserDTO:UserDTO):ResultDTO?  {
    println("inside the  login api")
    var customerList: List<UserDTO> = listOf<UserDTO>()
    var output : ResultDTO? = null
    var msg: String = "Login Failed"
    var code: String= ""
    val admin: CordaX500Name = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyD"))
    val adminnode = rpcOps.wellKnownPartyFromX500Name(admin) ?: return output
    println(adminnode)
    //val otherParty = rpcOps.nodeInfo().legalIdentities.first().name
    println(UserDTO)
    try {
        println("calling flow")
// The line below blocks and waits for the flow to return.

        val result = rpcOps
                .startTrackedFlow(Loginflow::Initiator, UserDTO, adminnode).returnValue
        customerList = result.get()
          println ("customerList"+customerList)
        if (customerList.isEmpty()) {
            println("inside false")
            msg = String.format("Login Failed")
            code="1000"
            output=ResultDTO("","",msg,code)
            println(output)
        }
        else {
            for (a in customerList) {

                println(a.password)
                if ((a.user_name).equals(UserDTO.user_name) && (a.password).equals(UserDTO.password) && (a.user_type).equals(UserDTO.user_type)) {
                    println("inside true")
                    msg = String.format("Login Successfull")
                    code = "0000"
                    output = ResultDTO(a.user_name, a.user_type, msg, code)
                    println(output)
                }

            }
        }

    } catch (ex: Throwable) {
        logger.error(ex.message, ex)

    }

    return output

}

//    customerList = result.get()

@POST
@Path("create-contract")
fun createContract(ContractDTO: List<ContractDTO>): Response {
    println("inside the  registration api")
    var customerStates = mutableListOf<LessorContractState>()
    var contract_id:String ? =""
    var me: Party = rpcOps.nodeInfo().legalIdentities.first()
    println(me)
    val Lessor = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
    val Lessornode = rpcOps.wellKnownPartyFromX500Name(Lessor)
    println("check"+Lessor)
    println("test"+Lessornode)
    val lessee:CordaX500Name = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyB"))
    val lesseenode = rpcOps.wellKnownPartyFromX500Name(lessee) ?: return Response.status(BAD_REQUEST).entity("Party named $lessee cannot be found.\n").build()
    println(me)
    println(lesseenode)
    println(ContractDTO)
    var msg: String =""
    return try {
        println("calling flow")
        if(Lessornode == me)
        {
            val result = rpcOps
                    .startTrackedFlow(ContractCreationFlow::Initiator, ContractDTO.toList(),me, lesseenode).returnValue
            msg = String.format("%s", result)
            Response.status(CREATED).entity(msg).build()
        }
        else
        {
            msg = String.format("Only Lessor can create Contract")
            Response.status(CREATED).entity(msg).build()
        }

    } catch (ex: Throwable) {
        logger.error(ex.message, ex)
        Response.status(BAD_REQUEST).entity(ex.message!!).build()
    }
}


    @GET
    @Path("setdate")
    fun setDate()
    {
        val date = Date()
        println("date1"+date.getMonth()+1)
    }




    @POST
    @Path("submit-contract")
    fun submitContract(ContractDTO: List<ContractDTO>): Response {
        println("inside the  registration api")
        var NotificationDetails = mutableListOf<NotificationDTO>()
        var LessorStates = mutableListOf<LessorContractState>()
        var asset_id: String?=""
        var Notification:NotificationDTO?=null
        var PaymentList = mutableListOf<paymentDetails>()
        var me: Party = rpcOps.nodeInfo().legalIdentities.first()
        println(me)
        val Lessor = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
        val Lessornode = rpcOps.wellKnownPartyFromX500Name(Lessor)
        val Admin = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyD"))
        val AdminNode = rpcOps.wellKnownPartyFromX500Name(Admin)
        println("check"+Lessor)
        println("test"+Lessornode)
        val lessee:CordaX500Name = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyB"))
        val lesseenode = rpcOps.wellKnownPartyFromX500Name(lessee) ?: return Response.status(BAD_REQUEST).entity("Party named $lessee cannot be found.\n").build()
        println(me)
        println(lesseenode)
        println(ContractDTO)

        for (ContractDTO in ContractDTO) {
            for(PaymentDTO in ContractDTO.paymentDetails)
            {
                var payment = paymentDetails(PaymentDTO.amount,PaymentDTO.duedate)
                PaymentList.add(payment)
            }
            var lesse_id=ContractDTO.lesse_id
            var contract_id=ContractDTO.contract_id
             var notification=NotificationDTO("null",contract_id+"waiting for Review",lesse_id,ApplicationConstants.SUBMITCONTRACT,ApplicationConstants.FALSE)
            NotificationDetails.add(notification)
            asset_id= ContractDTO.AssetRefID
            var contract = contract(ContractDTO.contract_id,ContractDTO.AssetRefID, ContractDTO.contract_name,ContractDTO.description,ContractDTO.start_date,ContractDTO.end_date,ContractDTO.frequency,ContractDTO.amount,ContractDTO.lessor_id,ContractDTO.lesse_id,ContractDTO.status,ContractDTO.comments,PaymentList,ContractDTO.breachPeriod)
            var LessorState = LessorContractState(contract, me, (lesseenode),AssetContract())
            println("customerstate" + LessorState)
            println("NotificationDetails====================================================="+NotificationDetails)
            LessorStates.add(LessorState)

        }
        var msg:String=""
        return try {
            println("calling flow")
            if(Lessornode == me)
            {
                val result = rpcOps.startTrackedFlow(ContractSubmissionFlow::Initiator, LessorStates.toList(),me,AdminNode, lesseenode).returnValue
                val notificationDao = NotificationDao()
                notificationDao.createNotification(Lessornode.toString())
                Notification=notificationDao.insertNotificationDetails(Lessornode.toString(),NotificationDetails.toList())
                //val result1= rpcOps.startTrackedFlow(ChangeAssetFlow::Initiator,me,lesseenode,AdminNode,asset_id).returnValue

                msg = String.format("%s", result)
                Response.status(CREATED).entity(msg).build()
            }
            else
            {
                msg = String.format("Only Lessor can Submit Contract")
                Response.status(CREATED).entity(msg).build()
            }

        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity(ex.message!!).build()
        }
    }





    @POST
    @Path("sendback-review")
    fun sendBackReview(ContractDTO: List<ContractDTO>): Response {
        println("inside the  registration api")
        var LessorStates = mutableListOf<LessorContractState>()
            var NotificationDetails = mutableListOf<NotificationDTO>()
            var Notification:NotificationDTO?=null
        var asset_id: String?=""
        var PaymentList = mutableListOf<paymentDetails>()
        var me: Party = rpcOps.nodeInfo().legalIdentities.first()
        println(me)
        val Lessor = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
        val Lessornode = rpcOps.wellKnownPartyFromX500Name(Lessor)?: return Response.status(BAD_REQUEST).entity("Party named $Lessor cannot be found.\n").build()
        val Lessee = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyB"))
        val LesseeNode = rpcOps.wellKnownPartyFromX500Name(Lessee)

        println(me)
        println(ContractDTO)

        for (ContractDTO in ContractDTO) {
            for(PaymentDTO in ContractDTO.paymentDetails)
            {
                var payment = paymentDetails(PaymentDTO.amount,PaymentDTO.duedate)
                PaymentList.add(payment)
            }

            var lessor_id=ContractDTO.lessor_id
            var contract_id=ContractDTO.contract_id
            var notification=NotificationDTO("null",contract_id+"sent for your revision",lessor_id,ApplicationConstants.SENDBACKREVIEW,ApplicationConstants.FALSE)
            NotificationDetails.add(notification)
            asset_id= ContractDTO.AssetRefID
            var contract = contract(ContractDTO.contract_id,ContractDTO.AssetRefID, ContractDTO.contract_name,ContractDTO.description,ContractDTO.start_date,ContractDTO.end_date,ContractDTO.frequency,ContractDTO.amount,ContractDTO.lessor_id,ContractDTO.lesse_id,ContractDTO.status,ContractDTO.comments,PaymentList,ContractDTO.breachPeriod)
            var LessorState = LessorContractState(contract, me, (Lessornode),AssetContract())
            println("customerstate" + LessorState)
            LessorStates.add(LessorState)

        }
        var msg: String =""
        return try {
            println("calling flow")
            if(LesseeNode == me)
            {
                val result = rpcOps
                        .startTrackedFlow(ContractSendBackReviewFlow::Initiator, LessorStates.toList(),Lessornode, me).returnValue
                val notificationDao = NotificationDao()
                //val result1= rpcOps.startTrackedFlow(ChangeAssetFlow::Initiator,me,lesseenode,AdminNode,asset_id).returnValue
                Notification=notificationDao.insertNotificationDetails(Lessornode.toString(),NotificationDetails.toList())
                msg = String.format("%s", result)
                Response.status(CREATED).entity(msg).build()
            }
            else
            {
                msg = String.format("Only Lessee can Review  Contract")
                Response.status(CREATED).entity(msg).build()
            }

        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity(ex.message!!).build()
        }
    }


    @POST
    @Path("save-contract")
    fun saveContract(ContractDTO: List<ContractDTO>): Response {
        println("inside the  registration api")
        var LessorStates = mutableListOf<LessorContractState>()
        var NotificationDetails = mutableListOf<NotificationDTO>()
        var Notification:NotificationDTO?=null
        var asset_id: String?=""
        var PaymentList = mutableListOf<paymentDetails>()
        var me: Party = rpcOps.nodeInfo().legalIdentities.first()
        println(me)
        val Lessor = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
        val Lessornode = rpcOps.wellKnownPartyFromX500Name(Lessor)
        val Lessee = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyB"))
        val LesseeNode = rpcOps.wellKnownPartyFromX500Name(Lessee)?: return Response.status(BAD_REQUEST).entity("Party named $Lessor cannot be found.\n").build()

        println(me)
        println(ContractDTO)

        for (ContractDTO in ContractDTO) {
            for(PaymentDTO in ContractDTO.paymentDetails)
            {
                var payment = paymentDetails(PaymentDTO.amount,PaymentDTO.duedate)
                PaymentList.add(payment)
            }
            var lesse_id=ContractDTO.lesse_id
            var contract_id=ContractDTO.contract_id
            var notification=NotificationDTO("null",contract_id+"Waiting for Your Review",lesse_id,ApplicationConstants.SAVECONTRACT,ApplicationConstants.FALSE)
            NotificationDetails.add(notification)
            asset_id= ContractDTO.AssetRefID
            var contract = contract(ContractDTO.contract_id,ContractDTO.AssetRefID, ContractDTO.contract_name,ContractDTO.description,ContractDTO.start_date,ContractDTO.end_date,ContractDTO.frequency,ContractDTO.amount,ContractDTO.lessor_id,ContractDTO.lesse_id,ContractDTO.status,ContractDTO.comments,PaymentList,ContractDTO.breachPeriod)
            var LessorState = LessorContractState(contract, me, (LesseeNode),AssetContract())
            println("customerstate" + LessorState)
            LessorStates.add(LessorState)

        }
        var msg: String =""
        return try {
            println("calling flow")
            if(Lessornode == me)
            {
                val result = rpcOps
                        .startTrackedFlow(SaveContractFlow::Initiator, LessorStates.toList(), me,LesseeNode).returnValue
                val notificationDao = NotificationDao()
                Notification=notificationDao.insertNotificationDetails(Lessornode.toString(),NotificationDetails.toList())
                //val result1= rpcOps.startTrackedFlow(ChangeAssetFlow::Initiator,me,lesseenode,AdminNode,asset_id).returnValue

                msg = String.format("%s", result)
                Response.status(CREATED).entity(msg).build()
            }
            else
            {
                msg = String.format("Only Lessor can  Save Contract")
                Response.status(CREATED).entity(msg).build()
            }

        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity(ex.message!!).build()
        }
    }
//
    @POST
    @Path("approve-contract")
    fun approveContract(ContractDTO: List<ContractDTO>): Response {
        println("inside the  registration api")
        var LessorStates = mutableListOf<LessorContractState>()
        var NotificationDetails = mutableListOf<NotificationDTO>()
        var Notification:NotificationDTO?=null
        var asset_id: String?=""
        var PaymentList = mutableListOf<paymentDetails>()
        var me: Party = rpcOps.nodeInfo().legalIdentities.first()
        println(me)
        val Lessor = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
        val Lessornode = rpcOps.wellKnownPartyFromX500Name(Lessor)?: return Response.status(BAD_REQUEST).entity("Party named $Lessor cannot be found.\n").build()
        val Lessee = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyB"))
        val LesseeNode = rpcOps.wellKnownPartyFromX500Name(Lessee)

        println(me)
        println(ContractDTO)

        for (ContractDTO in ContractDTO) {
            for(PaymentDTO in ContractDTO.paymentDetails)
            {
                var payment = paymentDetails(PaymentDTO.amount,PaymentDTO.duedate)
                PaymentList.add(payment)
            }
            var lessor_id=ContractDTO.lessor_id
            var contract_id=ContractDTO.contract_id
            var notification=NotificationDTO("null","Waiting for Your Approval",lessor_id,ApplicationConstants.SIGNCONTRACT,ApplicationConstants.FALSE)
            NotificationDetails.add(notification)
            asset_id= ContractDTO.AssetRefID
            var contract = contract(ContractDTO.contract_id,ContractDTO.AssetRefID, ContractDTO.contract_name,ContractDTO.description,ContractDTO.start_date,ContractDTO.end_date,ContractDTO.frequency,ContractDTO.amount,ContractDTO.lessor_id,ContractDTO.lesse_id,ContractDTO.status,ContractDTO.comments,PaymentList,ContractDTO.breachPeriod)
            var LessorState = LessorContractState(contract, me, (Lessornode),AssetContract())
            println("customerstate" + LessorState)
            LessorStates.add(LessorState)

        }
        var msg: String =""
        return try {
            println("calling flow")
            if(LesseeNode == me)
            {
                val result = rpcOps
                        .startTrackedFlow(ApproveContractFlow::Initiator, LessorStates.toList(),Lessornode, me).returnValue
                val notificationDao = NotificationDao()
                Notification=notificationDao.insertNotificationDetails(Lessornode.toString(),NotificationDetails.toList())
                //val result1= rpcOps.startTrackedFlow(ChangeAssetFlow::Initiator,me,lesseenode,AdminNode,asset_id).returnValue

                msg = String.format("%s", result)
                Response.status(CREATED).entity(msg).build()
            }
            else
            {
                msg = String.format("Only UserDetails have an authority to create Contract")
                Response.status(CREATED).entity(msg).build()
            }

        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity(ex.message!!).build()
        }
    }


//
    @POST
    @Path("counterpartysign")
    fun LessorSignContract(ContractDTO: List<ContractDTO>): Response {
        println("inside the  registration api")
        var LessorStates = mutableListOf<LessorContractState>()
        var NotificationDetails = mutableListOf<NotificationDTO>()
        var Notification:NotificationDTO?=null
        var asset_id: String?=""
        var PaymentList = mutableListOf<paymentDetails>()
        var me: Party = rpcOps.nodeInfo().legalIdentities.first()
        println(me)
        val Lessor = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
        val Lessornode = rpcOps.wellKnownPartyFromX500Name(Lessor)
        val Lessee = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyB"))
        val LesseeNode = rpcOps.wellKnownPartyFromX500Name(Lessee)?: return Response.status(BAD_REQUEST).entity("Party named $Lessor cannot be found.\n").build()

        println(me)
        println(ContractDTO)

        for (ContractDTO in ContractDTO) {
            for(PaymentDTO in ContractDTO.paymentDetails)
            {
                var payment = paymentDetails(PaymentDTO.amount,PaymentDTO.duedate)
                PaymentList.add(payment)
            }
            var lesse_id=ContractDTO.lesse_id
            var contract_id=ContractDTO.contract_id
            var notification=NotificationDTO("null",contract_id+"Active",lesse_id,ApplicationConstants.SAVECONTRACT,ApplicationConstants.FALSE)
            NotificationDetails.add(notification)
            asset_id= ContractDTO.AssetRefID
            var contract = contract(ContractDTO.contract_id,ContractDTO.AssetRefID, ContractDTO.contract_name,ContractDTO.description,ContractDTO.start_date,ContractDTO.end_date,ContractDTO.frequency,ContractDTO.amount,ContractDTO.lessor_id,ContractDTO.lesse_id,ContractDTO.status,ContractDTO.comments,PaymentList,ContractDTO.breachPeriod)
            var LessorState = LessorContractState(contract, me, (LesseeNode),AssetContract())
            println("customerstate" + LessorState)
            LessorStates.add(LessorState)

        }
        var msg: String =""
        return try {
            println("calling flow")
            if(Lessornode == me)
            {
                val result = rpcOps
                        .startTrackedFlow(LessorSignContractFlow::Initiator, LessorStates.toList(), me,LesseeNode).returnValue
                val notificationDao = NotificationDao()
                Notification=notificationDao.insertNotificationDetails(Lessornode.toString(),NotificationDetails.toList())
                //val result1= rpcOps.startTrackedFlow(ChangeAssetFlow::Initiator,me,lesseenode,AdminNode,asset_id).returnValue

                msg = String.format("%s", result)
                Response.status(CREATED).entity(msg).build()
            }
            else
            {
                msg = String.format("Only UserDetails have an authority to create Contract")
                Response.status(CREATED).entity(msg).build()
            }

        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity(ex.message!!).build()
        }
    }

    @POST
 @Path("create-asset")
fun createAsset(AssetDTO: List<AssetDTO>):Response
 {
     var Status: String? ="";
     var customerStates = mutableListOf<AssetState>()
     val me : Party= rpcOps.nodeInfo().legalIdentities.first()
     val lessor: CordaX500Name =CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
     val lessornode = rpcOps.wellKnownPartyFromX500Name(lessor)
     val admin:CordaX500Name = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyD"))
     val adminnode = rpcOps.wellKnownPartyFromX500Name(admin) ?: return Response.status(BAD_REQUEST).entity("Party named $admin cannot be found.\n").build()
         println("calling flow")


     for (AssetDTO in AssetDTO) {
         Status= AssetDTO.status;
         println("Status"+Status)
         var asset = asset(AssetDTO.asset_id,AssetDTO.name, AssetDTO.address,AssetDTO.city,AssetDTO.state,AssetDTO.country,AssetDTO.zipcode,AssetDTO.lessor_id,AssetDTO.currentOccupantID,AssetDTO.status,AssetDTO.approvedBy)
         var AssetState = AssetState(asset, me, (adminnode),AssetContract())
         println("customerstate" + AssetState)
         customerStates.add(AssetState)

     }
     var msg: String =""
     var asset_id:String? =""


     return try {
         println("calling flow")
         if(lessornode == me)
         {
              val result = rpcOps
                         .startTrackedFlow(AssetCreationFlow::Initiator, customerStates.toList(), adminnode).returnValue

                 msg = String.format("%s", result)
                 Response.status(CREATED).entity(msg).build()
              }

             else
             {
                 msg = String.format("Only Lessor can create Asset")
                 Response.status(CREATED).entity(msg).build()
             }


     } catch (ex: Throwable) {
         logger.error(ex.message, ex)
         Response.status(BAD_REQUEST).entity(ex.message!!).build()
     }
 }

    @POST
    @Path("approve-asset")
    fun approveAsset(AssetDTO: List<AssetDTO>):Response
    {
        var customerStates = mutableListOf<AssetState>()
        val me : Party= rpcOps.nodeInfo().legalIdentities.first()
        val admin: CordaX500Name =CordaX500Name.parse(ApplicationUtil.getPartyName("PartyD"))
        val adminnode = rpcOps.wellKnownPartyFromX500Name(admin) ?: return Response.status(BAD_REQUEST).entity("Party named $admin cannot be found.\n").build()
        val Lessor:CordaX500Name = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
        val Lessornode = rpcOps.wellKnownPartyFromX500Name(Lessor) ?: return Response.status(BAD_REQUEST).entity("Party named $Lessor cannot be found.\n").build()
        println("calling flow")


        for (AssetDTO in AssetDTO) {
            var asset = asset(AssetDTO.asset_id,AssetDTO.name, AssetDTO.address,AssetDTO.city,AssetDTO.state,AssetDTO.country,AssetDTO.zipcode,AssetDTO.lessor_id,AssetDTO.currentOccupantID,AssetDTO.status,AssetDTO.approvedBy)
            var AssetState = AssetState(asset, me, (Lessornode),AssetContract())
            println("customerstate" + AssetState)
            customerStates.add(AssetState)

        }
        var msg: String =""
        var asset_id:String?  =""


        return try {
            println("calling flow")
            if(adminnode == me)
            {
                val result = rpcOps
                        .startTrackedFlow(AssetApprovalFlow::Initiator, customerStates.toList(), Lessornode).returnValue

                msg = String.format("%s", result)
                Response.status(CREATED).entity(msg).build()
            }

            else
            {
                msg = String.format("Only Amin can Approve Asset")
                Response.status(CREATED).entity(msg).build()
            }


        } catch (ex: Throwable) {
            logger.error(ex.message, ex)
            Response.status(BAD_REQUEST).entity(ex.message!!).build()
        }
    }

    @POST
    @Path("upload-file")
    fun approveAsset(FileDTO: FileDTO):String {
        var detail_id: String = ""
        var header_id:String =""
        val me: Party = rpcOps.nodeInfo().legalIdentities.first()
        println("calling flow")
            val applicationDao = ApplicationDao()

            var filedetail = filedetail(FileDTO.filename,FileDTO.contract_id, FileDTO.paymentmonth, FileDTO.amount)
            header_id = applicationDao.createPaymentHeader(me.toString(), filedetail)
            //

        return header_id
    }

    @GET
    @Path("File-status")
    @Produces(MediaType.APPLICATION_JSON)
    fun getFilestatus():List<FileStatusDTO>{
        val me: Party = rpcOps.nodeInfo().legalIdentities.first()
        val applicationDao = ApplicationDao()
        var fileStatus = applicationDao.getFileStatus(me.toString())
        return fileStatus
    }


//        for (AssetDTO in AssetDTO) {
//            var asset = asset(AssetDTO.asset_id,AssetDTO.name, AssetDTO.address,AssetDTO.city,AssetDTO.state,AssetDTO.country,AssetDTO.zipcode,AssetDTO.lessor_id,AssetDTO.currentOccupantID,AssetDTO.status,AssetDTO.approvedBy)
//            var AssetState = AssetState(asset, me, (Lessornode),AssetContract())
//            println("customerstate" + AssetState)
//            customerStates.add(AssetState)
//
//        }
//        var msg: String =""
//        var asset_id:String?  =""
//
//
//        return try {
//            println("calling flow")
//            if(adminnode == me)
//            {
//                val result = rpcOps
//                        .startTrackedFlow(AssetApprovalFlow::Initiator, customerStates.toList(), Lessornode).returnValue
//
//                msg = String.format("%s", result)
//                Response.status(CREATED).entity(msg).build()
//            }
//
//            else
//            {
//                msg = String.format("Only Amin have an authority to Approve Asset")
//                Response.status(CREATED).entity(msg).build()
//            }
//
//
//        } catch (ex: Throwable) {
//            logger.error(ex.message, ex)
//            Response.status(BAD_REQUEST).entity(ex.message!!).build()
//        }



//
//    @POST
//    @Path("delete-asset")
//    fun deleteAssetDetails() {
//        val Admin = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyD"))
//        val AdminNode = rpcOps.wellKnownPartyFromX500Name(Admin)
//        val Lessor = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
//        val LessorNode = rpcOps.wellKnownPartyFromX500Name(Lessor)
//        val applicationDao = ApplicationDao()
//        applicationDao.deleteAssetDetails(AdminNode.toString(),LessorNode.toString())
//    }
//
//
//    @POST
//    @Path("delete-contract")
//    fun deleteContractDetails() {
//        val Lessee = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyB"))
//        val LesseeNode = rpcOps.wellKnownPartyFromX500Name(Lessee)
//        val Lessor = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
//        val LessorNode = rpcOps.wellKnownPartyFromX500Name(Lessor)
//        val applicationDao = ApplicationDao()
//        applicationDao.deleteContractDetails(LessorNode.toString(),LesseeNode.toString())
//    }
//
//
//
//
//
//
//
//
//
////    @POST
////    @Path("create-account")
////    fun createUserAccount(UserDTO: List<UserDTO>):String
////    {
////        val me : Party= rpcOps.nodeInfo().legalIdentities.first()
////        val admin: CordaX500Name =CordaX500Name.parse(ApplicationUtil.getPartyName("PartyD"))
////        val adminnode = rpcOps.wellKnownPartyFromX500Name(admin)
////        var msg: String =""
////        if(lessornode == me)
////        {
////            val applicationDao = ApplicationDao()
////            var account_id = applicationDao.createUserAccount(me.toString(),UserDTO.toList())
////            msg = String.format("%s", account_id)
////        }
////        else
////        {
////            msg = String.format("Only Admin have an authority to create user Account")
////
////        }
////        return msg
////
////    }
//
//    @POST
//    @Path("getContractDetails")
//    @Produces(MediaType.APPLICATION_JSON)
//    @Consumes(MediaType.APPLICATION_JSON)
//    fun getContractDetails(UserDTO:UserDTO):List<ContractDTO>{
//        val applicationDao = ApplicationDao()
//        val me : Party= rpcOps.nodeInfo().legalIdentities.first()
//        var contractList: List<ContractDTO> = listOf<ContractDTO>()
////        val repositorynode: CordaX500Name = CordaX500Name.parse(ApplicationUtil.getRegulatoryName())
////        val repository = rpcOps.wellKnownPartyFromX500Name(repositorynode) ?: return contractList
//        println(me)
//        //val otherParty = rpcOps.nodeInfo().legalIdentities.first().name
//        val result = rpcOps
//                .startTrackedFlow(ContractDetailsFlow::Initiator,UserDTO,me).returnValue
//        contractList =  result.get()
//
//    return contractList.toList()
//}

    @POST
    @Path("create-user")
    fun createUser(UserDetailsDTO: List<UserDetailsDTO>):String
    {
        val me : Party= rpcOps.nodeInfo().legalIdentities.first()
        val admin: CordaX500Name =CordaX500Name.parse(ApplicationUtil.getPartyName("PartyD"))
        val adminnode = rpcOps.wellKnownPartyFromX500Name(admin)
        var msg: String =""
        println("calling flow")
        if(adminnode == me)
        {
            val applicationDao = ApplicationDao()
            var user_id = applicationDao.createUser(me.toString(),UserDetailsDTO.toList())
            msg = String.format("%s", user_id)
        }
        else
        {
            msg = String.format("Only Admin can create User")

        }
        return msg

    }

    @POST
    @Path("update-flag")
    fun createUser(UpdateFlagDTO: UpdateFlagDTO):String
    {

        val Lessor: CordaX500Name =CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
        val LessorNode = rpcOps.wellKnownPartyFromX500Name(Lessor)
        var msg: String =""

            val notificationDao = NotificationDao()
            var Status = notificationDao.UpdateFlag(LessorNode.toString(),UpdateFlagDTO)
            msg = String.format("%s", Status)

        return msg

    }
//
//
    @POST
    @Path("user-login")
    fun userLogin(User: List<UserDTO>):String
    {
        val me : Party= rpcOps.nodeInfo().legalIdentities.first()
        val admin: CordaX500Name =CordaX500Name.parse(ApplicationUtil.getPartyName("PartyD"))
        val adminnode = rpcOps.wellKnownPartyFromX500Name(admin)
        var msg: String =""
        println("calling flow")
        if(adminnode == me)
        {
            val applicationDao = ApplicationDao()
            var user_id = applicationDao.userLogin(me.toString(),User.toList())
            msg = String.format("%s", user_id)
        }
        else
        {
            msg = String.format("Only Admin can create User")

        }
        return msg

    }
//
//
//
//
    @GET
    @Path("getAssetDetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    fun getAssetDetails():List<AssetDTO>{
        val applicationDao = ApplicationDao()
        val me : Party= rpcOps.nodeInfo().legalIdentities.first()
        var assetDetails: List<AssetDTO> = listOf<AssetDTO>()
//        val repositorynode: CordaX500Name = CordaX500Name.parse(ApplicationUtil.getRegulatoryName())
//        val repository = rpcOps.wellKnownPartyFromX500Name(repositorynode) ?: return contractList
        println(me)
        //val otherParty = rpcOps.nodeInfo().legalIdentities.first().name
        assetDetails= applicationDao.getAssetDetails(me.toString())
        return assetDetails.toList()
    }

//
//    @POST
//    @Path("getNotificationDetails")
//    @Produces(MediaType.APPLICATION_JSON)
//    @Consumes(MediaType.APPLICATION_JSON)
//    fun getNotification(SearchNotificationDTO:SearchNotificationDTO):List<NotificationDTO>  {
//        println("inside the  notification api")
//        var customerList: List<NotificationDTO> = listOf<NotificationDTO>()
//        val lessor: CordaX500Name = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
//        val lessorNode = rpcOps.wellKnownPartyFromX500Name(lessor)?:return customerList
//        println(lessorNode)
//        println(SearchNotificationDTO)
//        try {
//            println("calling flow")
//            val result = rpcOps
//                    .startTrackedFlow(NotificationFlow::Initiator, SearchNotificationDTO, lessorNode).returnValue
//            customerList = result.get()
//        } catch (ex: Throwable) {
//            logger.error(ex.message, ex)
//        }
//        return customerList
//
//    }
//
//
//
    @GET
    @Path("{asset_id}/getAssetById")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    fun getAssetById(@PathParam("asset_id") asset_id:String):List<AssetDTO>{
        val applicationDao = ApplicationDao()
        val me : Party= rpcOps.nodeInfo().legalIdentities.first()
        var assetDetails: List<AssetDTO> = listOf<AssetDTO>()
//        val repositorynode: CordaX500Name = CordaX500Name.parse(ApplicationUtil.getRegulatoryName())
//        val repository = rpcOps.wellKnownPartyFromX500Name(repositorynode) ?: return contractList
        println(me)
        //val otherParty = rpcOps.nodeInfo().legalIdentities.first().name
        assetDetails= applicationDao.getAssetById(me.toString(),asset_id)

        return assetDetails.toList()
    }
//
//
    @GET
    @Path("{contract_id}/getContractDetailById")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    fun getContractDetailById(@PathParam("contract_id") contract_id:String):List<ContractDTO>{
        val applicationDao = ApplicationDao()
        val me : Party= rpcOps.nodeInfo().legalIdentities.first()
        var ContractDetails: List<ContractDTO> = listOf<ContractDTO>()
//        val repositorynode: CordaX500Name = CordaX500Name.parse(ApplicationUtil.getRegulatoryName())
//        val repository = rpcOps.wellKnownPartyFromX500Name(repositorynode) ?: return contractList
        println(me)
        //val otherParty = rpcOps.nodeInfo().legalIdentities.first().name
        ContractDetails= applicationDao.getContractDetailById(me.toString(),contract_id)
        println("contractdetails"+ContractDetails.toList())
        return ContractDetails.toList()
    }
//
    @GET
    @Path("getContractDetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    fun getContractDetails():List<ContractDTO>{
        val applicationDao = ApplicationDao()
        val me : Party= rpcOps.nodeInfo().legalIdentities.first()
        var ContractDetails: List<ContractDTO> = listOf<ContractDTO>()
//        val repositorynode: CordaX500Name = CordaX500Name.parse(ApplicationUtil.getRegulatoryName())
//        val repository = rpcOps.wellKnownPartyFromX500Name(repositorynode) ?: return contractList
        println(me)
        //val otherParty = rpcOps.nodeInfo().legalIdentities.first().name
        ContractDetails= applicationDao.getContractDetails(me.toString())
        println("ontractlit"+ContractDetails.toList())
        return ContractDetails.toList()
    }


    @GET
    @Path("generateNotification")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    fun generateNotification():String{
        val notificationDao = NotificationDao()
        var status:String=""
        val me : Party= rpcOps.nodeInfo().legalIdentities.first()
        val lessee: CordaX500Name =CordaX500Name.parse(ApplicationUtil.getPartyName("PartyB"))
        val lesseenode = rpcOps.wellKnownPartyFromX500Name(lessee)
        val admin: CordaX500Name =CordaX500Name.parse(ApplicationUtil.getPartyName("PartyD"))
        val adminnode = rpcOps.wellKnownPartyFromX500Name(admin)

//        val repositorynode: CordaX500Name = CordaX500Name.parse(ApplicationUtil.getRegulatoryName())
//        val repository = rpcOps.wellKnownPartyFromX500Name(repositorynode) ?: return contractList
        println(me)
        //val otherParty = rpcOps.nodeInfo().legalIdentities.first().name
        status= notificationDao.generateNotification(me.toString(),lesseenode.toString(),adminnode.toString())
       // println("NotificationDetails"+NotificationDetails.toList())
        return status
    }


    @GET
    @Path("{UserId}/getNotificationById")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    fun getNotificationById(@PathParam("UserId")UserId:String):List<NotificationDTO>{
        val notificationDao = NotificationDao()
        var NotificationDetails: List<NotificationDTO> = listOf<NotificationDTO>()
        val Lessor = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
        val LessorNode = rpcOps.wellKnownPartyFromX500Name(Lessor)
        NotificationDetails= notificationDao.getNotificationById(LessorNode.toString(),UserId)
        return NotificationDetails
    }


    @GET
    @Path("UpdateContract")
    fun UpdateContract():String{
        val notificationDao = NotificationDao()
        //var NotificationDetails: List<NotificationDTO> = listOf<NotificationDTO>()
        val Lessor = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyA"))
        val LessorNode = rpcOps.wellKnownPartyFromX500Name(Lessor)
        val Lessee = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyB"))
        val LesseeNode = rpcOps.wellKnownPartyFromX500Name(Lessee)
        val Admin = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyD"))
        val AdminNode = rpcOps.wellKnownPartyFromX500Name(Admin)
        var ok =notificationDao.UpdateContract(LessorNode.toString(),LesseeNode.toString(),AdminNode.toString())
        return ok
    }
    //
    @GET
    @Path("getLesseeDetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)

    fun getLesseeDetails():List<LesseeDTO>
    {
        var LesseeList: List<LesseeDTO> = listOf<LesseeDTO>()

        var code: String= ""
        val admin: CordaX500Name = CordaX500Name.parse(ApplicationUtil.getPartyName("PartyD"))
        val adminnode = rpcOps.wellKnownPartyFromX500Name(admin) ?: return LesseeList
        println(adminnode)
        //val otherParty = rpcOps.nodeInfo().legalIdentities.first().name
        try {
            println("calling flow")
// The line below blocks and waits for the flow to return.
            val applicationDao = ApplicationDao()
            val result = applicationDao.getLesseeDetails(adminnode.toString())
            LesseeList = result
            println ("LesseeList"+LesseeList)

        } catch (ex: Throwable) {
            logger.error(ex.message, ex)

        }
        return LesseeList
    }

    @POST
    @Path("{id}/getPaymentDetails")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)

    fun getLesseeDetails(@PathParam("id")id:String):List<detailDTO> {
        var DetailList: List<detailDTO> = listOf<detailDTO>()

        val me: Party = rpcOps.nodeInfo().legalIdentities.first()

//        val repositorynode: CordaX500Name = CordaX500Name.parse(ApplicationUtil.getRegulatoryName())
//        val repository = rpcOps.wellKnownPartyFromX500Name(repositorynode) ?: return contractList
        println(me)
        //val otherParty = rpcOps.nodeInfo().legalIdentities.first().name
        val applicationDao =ApplicationDao()
        DetailList = applicationDao.getpaymentDetails(me.toString(),id)
        // println("NotificationDetails"+NotificationDetails.toList())
        return DetailList
    }


    @POST
    @Path("uploadZipFiles")
    @Produces(MediaType.APPLICATION_JSON)
    fun uploadZipFiles(filePath: String): Map<String, String> {
        var pathHashMap : MutableMap<String, String> = mutableMapOf()
        if(null!=filePath){
            // for(filePath in filePaths){
            var file : File = File(filePath)
            println(file)
            try {
                var docHash = rpcOps.uploadAttachment(file.inputStream())
                pathHashMap.put(filePath, docHash.toString())
            } catch (e: Throwable){
                System.out.println(e.toString())
            }
            //}
        }
        return pathHashMap.toMap()
    }


}

