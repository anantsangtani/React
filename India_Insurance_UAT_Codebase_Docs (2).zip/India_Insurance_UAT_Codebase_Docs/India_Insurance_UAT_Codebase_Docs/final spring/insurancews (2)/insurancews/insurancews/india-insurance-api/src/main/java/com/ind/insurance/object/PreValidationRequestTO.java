package com.ind.insurance.object;
 
public class PreValidationRequestTO {
 
      String reqId ;
      String uploadedFileName;
      String uploadedFileHash ;
      String uploadDate;
      String destinationNode ;
      String status;
      String downloadFileName;
      String downloadFileHash ;
     
      public String getReqId() {
            return reqId;
      }
      public void setReqId(String reqId) {
            this.reqId = reqId;
      }
      public String getUploadedFileName() {
            return uploadedFileName;
      }
      public void setUploadedFileName(String uploadedFileName) {
            this.uploadedFileName = uploadedFileName;
      }
      public String getUploadedFileHash() {
            return uploadedFileHash;
      }
      public void setUploadedFileHash(String uploadedFileHash) {
            this.uploadedFileHash = uploadedFileHash;
      }
     
      public String getUploadDate() {
            return uploadDate;
      }
      public void setUploadDate(String uploadDate) {
            this.uploadDate = uploadDate;
      }
      public String getDestinationNode() {
            return destinationNode;
      }
      public void setDestinationNode(String destinationNode) {
            this.destinationNode = destinationNode;
      }
      public String getStatus() {
            return status;
      }
      public void setStatus(String status) {
            this.status = status;
      }
      public String getDownloadFileName() {
            return downloadFileName;
      }
      public void setDownloadFileName(String downloadFileName) {
            this.downloadFileName = downloadFileName;
      }
      public String getDownloadFileHash() {
            return downloadFileHash;
      }
      public void setDownloadFileHash(String downloadFileHash) {
            this.downloadFileHash = downloadFileHash;
      }
     
}
