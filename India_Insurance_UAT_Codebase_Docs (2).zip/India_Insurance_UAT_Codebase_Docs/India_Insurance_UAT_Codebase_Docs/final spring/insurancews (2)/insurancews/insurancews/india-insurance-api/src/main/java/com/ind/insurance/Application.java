package com.ind.insurance;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.ind.insurance.controller.TranscriptProcessingController;

@SpringBootApplication
@EnableScheduling
@EnableCaching
@ComponentScan("com.ind.insurance")
public class Application extends SpringBootServletInitializer {

	public static void main(final String[] args) {

		new Application()
		.configure(new SpringApplicationBuilder(Application.class))
		.run(args);
	}
}
