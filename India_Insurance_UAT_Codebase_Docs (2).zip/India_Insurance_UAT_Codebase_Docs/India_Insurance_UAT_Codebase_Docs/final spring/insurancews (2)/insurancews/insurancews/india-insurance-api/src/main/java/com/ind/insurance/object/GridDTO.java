package com.ind.insurance.object;

import java.util.List;

public class GridDTO {

	public GridDTO() {
		
	}
	private String requestId;
	private String fileName;
	private String status;
	private String uploadDate;
	private List<ErrorDTO> errTO;
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getUploadDate() {
		return uploadDate;
	}
	public void setUploadDate(String uploadDate) {
		this.uploadDate = uploadDate;
	}
	public List<ErrorDTO> getErrTO() {
		return errTO;
	}
	public void setErrTO(List<ErrorDTO> errTO) {
		this.errTO = errTO;
	}

	
	

}
