package com.ind.insurance.service;

import org.apache.activemq.artemis.api.core.ActiveMQException;

import net.corda.core.messaging.CordaRPCOps;

public interface CordaRPCService {

	public CordaRPCOps getRPCServiceByNode(String hostPort) throws ActiveMQException;
}
