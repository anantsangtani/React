package com.ind.insurance.object;

public class GraphLabel {

	String label;

	public GraphLabel(String label) {
		super();
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
	
	
}
