package com.ind.insurance.object;

public class DetailDataGridTO {
	private Long aadharNo;
	private String reqId;
	private String sender;

	private String status;
	public DetailDataGridTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(Long aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getReqId() {
		return reqId;
	}
	public void setReqId(String reqId) {
		this.reqId = reqId;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDocHash() {
		return docHash;
	}
	public void setDocHash(String docHash) {
		this.docHash = docHash;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	private String docHash;
	private String docName;

}
