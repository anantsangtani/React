package com.ind.insurance.object;

public class GraphValue {

	String value;

	public GraphValue(String value) {
		super();
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	
}
