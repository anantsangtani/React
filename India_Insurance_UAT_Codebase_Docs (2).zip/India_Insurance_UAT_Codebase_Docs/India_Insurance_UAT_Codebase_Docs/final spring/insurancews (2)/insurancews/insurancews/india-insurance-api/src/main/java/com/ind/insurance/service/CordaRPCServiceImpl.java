package com.ind.insurance.service;

import org.apache.activemq.artemis.api.core.ActiveMQException;
import org.springframework.stereotype.Service;

import com.google.common.net.HostAndPort;

import net.corda.client.rpc.CordaRPCClient;
import net.corda.client.rpc.CordaRPCClientConfiguration;
import net.corda.core.messaging.CordaRPCOps;

@Service
public class CordaRPCServiceImpl implements CordaRPCService {

	//@Override
	public CordaRPCOps getRPCServiceByNode(String hostPort) throws ActiveMQException {
		// hostPort expected to be in format : "localhost:10006"
		final HostAndPort nodeAddress = HostAndPort.fromString(hostPort);
		final CordaRPCClient client = new CordaRPCClient(nodeAddress, null, CordaRPCClientConfiguration.getDefault());

		final CordaRPCOps proxy = client.start("user1", "test").getProxy();
		return proxy;
	}

}
