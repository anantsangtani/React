package com.ind.insurance.object;

public class NotificationTO {

	Long aadharNo;
	String deathclaimRaiseDate;
	
	public NotificationTO(Long aadharNo, String deathclaimRaiseDate) {
		super();
		this.aadharNo = aadharNo;
		this.deathclaimRaiseDate = deathclaimRaiseDate;
	}

	public Long getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(Long aadharNo) {
		this.aadharNo = aadharNo;
	}

	public String getDeathclaimRaiseDate() {
		return deathclaimRaiseDate;
	}

	public void setDeathclaimRaiseDate(String deathclaimRaiseDate) {
		this.deathclaimRaiseDate = deathclaimRaiseDate;
	}
	
	
	
	
}
