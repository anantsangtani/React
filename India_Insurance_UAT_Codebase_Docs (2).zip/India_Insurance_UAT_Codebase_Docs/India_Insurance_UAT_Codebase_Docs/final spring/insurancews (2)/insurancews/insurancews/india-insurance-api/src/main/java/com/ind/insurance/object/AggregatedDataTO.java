package com.ind.insurance.object;

public class AggregatedDataTO {

	String label;
	String key;
	String value;
	
	public AggregatedDataTO(String label, String key, String value) {
		super();
		this.label = label;
		this.key = key;
		this.value = value;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
}
