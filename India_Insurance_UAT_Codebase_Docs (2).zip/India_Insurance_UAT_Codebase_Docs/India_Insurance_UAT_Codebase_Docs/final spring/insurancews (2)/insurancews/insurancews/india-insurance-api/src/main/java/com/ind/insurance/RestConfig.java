
package com.ind.insurance;

import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.stereotype.Component;

import com.ind.insurance.controller.TranscriptProcessingController;
import com.ind.insurance.dao.ApplicationDAO;




/**
 * @author 549439
 *
 */
@Component
public class RestConfig extends ResourceConfig {
	public RestConfig() {
		this.register(CORSFilter.class);
		this.register(JacksonFeature.class);
		this.register(MultiPartFeature.class);
		this.register(TranscriptProcessingController.class);
		
		
		
	
	}
}
