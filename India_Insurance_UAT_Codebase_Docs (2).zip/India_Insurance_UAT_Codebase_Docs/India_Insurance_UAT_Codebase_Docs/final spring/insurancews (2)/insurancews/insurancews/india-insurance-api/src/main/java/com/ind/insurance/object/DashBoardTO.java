package com.ind.insurance.object;

public class DashBoardTO {

	String memberName ;
	Long noOfRequestMade ;
	Long noOfResponseMade ;
	Long noOfDataContribute ;
	Long pointsEarned ;
	Long pointsDue ;
	Long netPointBalance;
	
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public Long getNoOfRequestMade() {
		return noOfRequestMade;
	}
	public void setNoOfRequestMade(Long noOfRequestMade) {
		this.noOfRequestMade = noOfRequestMade;
	}
	public Long getNoOfResponseMade() {
		return noOfResponseMade;
	}
	public void setNoOfResponseMade(Long noOfResponseMade) {
		this.noOfResponseMade = noOfResponseMade;
	}
	public Long getNoOfDataContribute() {
		return noOfDataContribute;
	}
	public void setNoOfDataContribute(Long noOfDataContribute) {
		this.noOfDataContribute = noOfDataContribute;
	}
	public Long getPointsEarned() {
		return pointsEarned;
	}
	public void setPointsEarned(Long pointsEarned) {
		this.pointsEarned = pointsEarned;
	}
	public Long getPointsDue() {
		return pointsDue;
	}
	public void setPointsDue(Long pointsDue) {
		this.pointsDue = pointsDue;
	}
	public Long getNetPointBalance() {
		return netPointBalance;
	}
	public void setNetPointBalance(Long netPointBalance) {
		this.netPointBalance = netPointBalance;
	}
	

}
