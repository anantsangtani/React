package com.ind.insurance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;

import org.apache.activemq.artemis.api.core.ActiveMQException;
import org.bouncycastle.asn1.x500.X500Name;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.example.flow.MonthlyPointDeductionFlow;
import com.ind.insurance.service.CordaRPCService;

import net.corda.core.identity.Party;
import net.corda.core.messaging.CordaRPCOps;
import net.corda.core.transactions.SignedTransaction;

@Component
public class ScheduledTasks {

	@Autowired
	private CordaRPCService cordaRPCService;
	@Value(value = "${node.insurer.rpc.hostport}")
	private String nodeRpcHostAndPort;
	@Value(value = "${db.connection}")
	private String nodeDbConnection;
	@Value(value = "${debit.point.qry.gt.200}")
	private Long debitPointForQryGt200;
	@Value(value = "${debit.point.qry.gt.30per}")
	private Long debitPointForQryGt30Per;

	/*
	 * @Scheduled(fixedRate = 5000) public void reportCurrentTime() {
	 * log.info("The time is now {}", dateFormat.format(new Date())); }
	 */

	@Scheduled(cron = "${cron.expression}")
	public void deductPoint() throws ActiveMQException {
		System.out.println("**********Inside monthly penalty scheduler *****************");
		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		// LocalDate currDate = LocalDate.parse("31-08-2017",
		// DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		LocalDate currDate = LocalDate.now();
		LocalDate rangeStartDate = currDate.minusMonths(1).atStartOfDay().toLocalDate();
		System.out.println("range start date is :" + rangeStartDate);
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Map<String, Long> partyWiseMonthlyAggrQueryCount = new HashMap<>();
		try {
			conn = getDBConnection();
			// populate member wise current month's aggregate query count
			String currMonthQry = " select P.ACCOUNT_HOLDER ,P.NO_OF_AGGREGATE_QRY from"
					+ " (select account_holder , max(UPDATE_TIMESTAMP) as Maxtime  FROM POINT_STATE_DETAIL where LATEST_AGGREGATE_QRY_DT  is not null and "
					+ " LATEST_AGGREGATE_QRY_DT between ? and ? group by account_holder ) r"
					+ " INNER JOIN POINT_STATE_DETAIL P"
					+ " ON P.UPDATE_TIMESTAMP = r.Maxtime and P.ACCOUNT_HOLDER = r.ACCOUNT_HOLDER ";
			ps = conn.prepareStatement(currMonthQry);
			ps.setDate(1, java.sql.Date.valueOf(rangeStartDate));
			ps.setDate(2, java.sql.Date.valueOf(currDate));
			rs = ps.executeQuery();
			while (rs.next()) {
				partyWiseMonthlyAggrQueryCount.put(rs.getString(1), rs.getLong(2));
			}
			rs.close();
			ps.close();
			// Get previous month's latest aggr. qry count and find difference
			String prevMonthQry = " select P.ACCOUNT_HOLDER ,P.NO_OF_AGGREGATE_QRY from"
					+ " (select account_holder , max(UPDATE_TIMESTAMP) as Maxtime  FROM POINT_STATE_DETAIL where LATEST_AGGREGATE_QRY_DT  is not null and "
					+ " LATEST_AGGREGATE_QRY_DT < ? group by account_holder ) r" + " INNER JOIN POINT_STATE_DETAIL P"
					+ " ON P.UPDATE_TIMESTAMP = r.Maxtime and P.ACCOUNT_HOLDER = r.ACCOUNT_HOLDER ";
			ps = conn.prepareStatement(prevMonthQry);
			ps.setDate(1, java.sql.Date.valueOf(rangeStartDate));
			rs = ps.executeQuery();
			while (rs.next()) {
				String insurer = rs.getString(1);
				if (partyWiseMonthlyAggrQueryCount.containsKey(insurer)) {
					Long latestQryCount = partyWiseMonthlyAggrQueryCount.get(insurer);
					partyWiseMonthlyAggrQueryCount.put(insurer, latestQryCount - rs.getLong(2));
				}
			}

			// calculate total aggregate qry for the month
			Long totalAggregateQryOfMonth = 0L;
			for (Entry<String, Long> entry : partyWiseMonthlyAggrQueryCount.entrySet()) {
				totalAggregateQryOfMonth += entry.getValue();
			}
			for (Entry<String, Long> entry : partyWiseMonthlyAggrQueryCount.entrySet()) {
				String member = entry.getKey();
				Long monthlyAggrQryCount = entry.getValue();
				Long pointToDeduct = 0L;
				if (monthlyAggrQryCount > 200) {
					pointToDeduct += debitPointForQryGt200;
				}
				if (monthlyAggrQryCount > (totalAggregateQryOfMonth * 0.3)) {
					pointToDeduct += debitPointForQryGt30Per;
				}
				// call corda flow for point deduction
				if (pointToDeduct > 0) {
					try {
						System.out.println("Going to deduct " + pointToDeduct + " point for member " + member);
						Party insurer = rpcService.partyFromX500Name(new X500Name(member));
						SignedTransaction stx;
						stx = rpcService
								.startFlowDynamic(MonthlyPointDeductionFlow.Initiator.class, insurer, pointToDeduct)
								.getReturnValue().get();
						System.out.println("Monthly point deduction completed for member :" + member + " with txn id: "
								+ stx.getId().toString());
					} catch (Exception e) {
						System.out.println("Exception in monthly point deduction for member :" + member);
						e.printStackTrace();
					}

				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != rs)
					rs.close();
				if (null != ps)
					ps.close();
				if (null != conn)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	private Connection getDBConnection() throws SQLException {
		try {
			Class.forName("org.h2.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String dbConnectionString = nodeDbConnection;
		Connection dbConn = DriverManager.getConnection(dbConnectionString, "sa", "");

		return dbConn;
	}

}