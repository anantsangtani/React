package com.ind.insurance.object;

import java.util.ArrayList;
import java.util.List;

public class GraphDisplayTO {

	List<GraphLabel> category = new ArrayList<>();
	List<GraphValue> data = new ArrayList<>();
	public GraphDisplayTO() {
		
		/*this.category = category;
		this.data = data;*/
	}
	public List<GraphLabel> getCategory() {
		return category;
	}
	public void setCategory(List<GraphLabel> category) {
		this.category = category;
	}
	public List<GraphValue> getData() {
		return data;
	}
	public void setData(List<GraphValue> data) {
		this.data = data;
	}
	
	
	
}
