package com.ind.insurance.object;

import java.util.Map;

public class AllRequestTO {
	private String reqID;
	private String status;
	private Boolean apprvFlag;
	public Boolean getApprvFlag() {
		return apprvFlag;
	}
	public void setApprvFlag(Boolean apprvFlag) {
		this.apprvFlag = apprvFlag;
	}
	private String queryType;
	public String getReqID() {
		return reqID;
	}
	public void setReqID(String reqID) {
		this.reqID = reqID;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getQueryType() {
		return queryType;
	}
	public void setQueryType(String queryType) {
		this.queryType = queryType;
	}
	public Long getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(Long aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	private Long aadharNo;
	public Map<String, String> getPartyName() {
		return partyName;
	}
	public void setPartyName(Map<String, String> partyName) {
		this.partyName = partyName;
	}
	private String source;
	private Map<String,String> partyName;
		

}
