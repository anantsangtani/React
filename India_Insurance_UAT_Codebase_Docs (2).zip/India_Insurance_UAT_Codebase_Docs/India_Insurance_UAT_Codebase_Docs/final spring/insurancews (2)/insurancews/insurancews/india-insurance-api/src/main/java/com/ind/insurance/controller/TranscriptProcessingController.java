package com.ind.insurance.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.Provider;

import org.apache.activemq.artemis.api.core.ActiveMQException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.style.BCStyle;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.example.flow.AggregateQueryFlow;
import com.example.flow.ApplicationDaoCallFlow;
import com.example.flow.ClaimDetailStorageFlow;
import com.example.flow.ConsortiumAggregateQueryDataFlow;
import com.example.flow.ConsortiumFlow;
import com.example.flow.DeathClaimNotificationFlow;
import com.example.flow.DetailDataRejectFlow;
import com.example.flow.DetailedDataReqFlow;
import com.example.flow.DetailedDataRespFlow;
import com.example.flow.InitialPointAllocationFlow;
import com.example.flow.PolicyDetailStorageFlow;
import com.example.flow.PolicyHolderDetailStorageFlow;
import com.example.flow.PreValidationQueryFlow;
import com.example.model.AggregatedData;
import com.example.model.Claim;
import com.example.model.Policy;
import com.example.model.PolicyHolder;
import com.example.state.DetailedDataReqState;
import com.example.state.NotificationState;
import com.example.state.PointState;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.collect.ImmutableMap;
import com.ind.insurance.dao.ApplicationDAO;
import com.ind.insurance.object.AggregatedDataTO;
import com.ind.insurance.object.AllRequestTO;
import com.ind.insurance.object.DashBoardTO;
import com.ind.insurance.object.DetailDataGridTO;
import com.ind.insurance.object.ErrorDTO;
import com.ind.insurance.object.GraphDisplayTO;
import com.ind.insurance.object.GraphLabel;
import com.ind.insurance.object.GraphValue;
import com.ind.insurance.object.GridDTO;
import com.ind.insurance.object.NotificationTO;
import com.ind.insurance.object.PreValidationRequestTO;
import com.ind.insurance.service.CordaRPCService;

import kotlin.Pair;
import net.corda.core.crypto.SecureHash;
import net.corda.core.identity.Party;
import net.corda.core.messaging.CordaRPCOps;
import net.corda.core.node.NodeInfo;
import net.corda.core.node.ServiceHub;
import net.corda.core.node.services.NetworkMapCache;
import rx.Observable;
import static java.util.stream.Collectors.toList;
import static net.corda.client.rpc.UtilsKt.notUsed;

@Component
@Provider
@Path("/api")
public class TranscriptProcessingController {

	@Autowired
	private CordaRPCService cordaRPCService;
	@Autowired
	private ApplicationDAO applicationDao;

	// @Value(value = "${node.consortium.rpc.hostport}")
	// private String nodeCNSRpcHostAndPort;

	// @Value(value = "${node.insurer1.rpc.hostport}")
	// private String nodeINS1RpcHostAndPort;

	@Value(value = "${node.insurer.rpc.hostport}")
	private String nodeRpcHostAndPort;
	@Value(value = "${db.connection}")
	private String nodeDbConnection;

	/*
	 * @Value(value = "${mandate.field.excel}") private String mandateFields =
	 * "0,1,2,4,5,8"; ArrayList<String> items = new
	 * ArrayList<String>(Arrays.asList(mandateFields.split(",")));
	 */

	// fields for policyHolder

	Long aadhar;
	String pan;
	char gender;
	String firstName;
	String lastName;
	LocalDate dob;
	String address;
	String state;
	char nriStatus;
	String education;
	String employement;
	Integer pinCode;
	String middleName;
	// fields for policy
	char sourcing;
	Long policyAadhar;
	String policyNumber;
	String uinNumber;
	char prodType;
	String nomineeName;
	char policyStatus;
	Double premium;
	Double sumAssured;
	char renewalFreq;
	LocalDate policyStartDate;
	String passportNumber;

	// fields for claim
	Long claimAadhar;
	String claimPolicyNum;
	char claimStatus;
	char claimSubStatus;
	Character fraudStatus;
	char claimType;
	LocalDate claimDate;
	String claimId;
	// rpc
	CordaRPCOps rpcService = null;
	String nodeName = null;
	String fileType;
	String fileName;
	String reqID;
	String uploadDate;
	Response.Status status;
	String msg;
	String inDateFormat = "ddMMyyyy";
	Boolean excelValid = true;

	@POST
	@Path("/upload")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response holderExcelUpload(@FormDataParam("file") InputStream docInputStream,
			@FormDataParam("uploadType") String uploadType, @FormDataParam("fileName") String uploadName,
			@FormDataParam("date") String upDate) throws Exception {

		reqID = "REQ" + String.valueOf(System.currentTimeMillis());
		fileType = uploadType;
		fileName = uploadName;
		uploadDate = upDate;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		org.apache.commons.io.IOUtils.copy(docInputStream, baos);
		byte[] bytes = baos.toByteArray();

		ByteArrayInputStream fileStream = new ByteArrayInputStream(bytes);
		// (IOUtils.toByteArray(docInputStream));

		// ApplicationDAO applDao = new ApplicationDAO();

		try {

			applicationDao.insertGrid(cordaRPCService, reqID, fileName, "UPLOADED", "IN PROGRESS", uploadDate,
					fileType.toUpperCase(), fileStream);
			status = Response.Status.OK;
			msg = "SUCCESS";
			fileStream.reset();
			asyncServiceMethod(fileStream, reqID);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			status = Response.Status.NOT_FOUND;
			msg = "ERROR";
		}
		finally
		{
			docInputStream.close();
					}
		// InputStream parseStream = new
		// ByteArrayInputStream(IOUtils.toByteArray(docInputStream));
		
		return Response.status(status).entity(msg).build();

	}

	@SuppressWarnings("deprecation")
	private void excelUpload(InputStream inputStream, String reqID)   {
		excelValid = true;

		// ApplicationDAO insertDao = new ApplicationDAO();
		try {
			rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
			nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
			// POIFSFileSystem fs = new POIFSFileSystem(new
			// FileInputStream(docInputStream));
			InputStream parseFile = (inputStream);
			XSSFWorkbook wb = new XSSFWorkbook(parseFile);
			XSSFSheet sheet = wb.getSheetAt(0);

			Iterator<Row> iterator = sheet.iterator();
			int rowNumber = 0;
			// initializing variables
			aadhar = null;
			pan = null;
			gender = '\0';
			firstName = null;
			lastName = null;
			dob = null;
			address = null;
			state = null;
			nriStatus = '\0';
			education = null;
			employement = null;
			pinCode = null;
			middleName = null;
			// fields for policy
			sourcing = '\0';
			policyAadhar = null;
			policyNumber = null;
			uinNumber = null;
			prodType = '\0';
			nomineeName = null;
			policyStatus = '\0';
			premium = null;
			sumAssured = null;
			renewalFreq = '\0';
			policyStartDate = null;
			passportNumber = null;

			// fields for claim
			claimAadhar = null;
			claimPolicyNum = null;
			claimStatus = '\0';
			claimSubStatus = '\0';
			fraudStatus = '\0';
			claimType = '\0';
			claimDate = null;
			claimId = null;

			while (iterator.hasNext()) {

				Row currentRow = iterator.next();

				if (rowNumber == 0) {
					rowNumber++;
					continue;
				}
				Boolean emptyRow = Boolean.TRUE;
				for (int c = currentRow.getFirstCellNum(); c < currentRow.getLastCellNum(); c++) {
					Cell cell = currentRow.getCell(c);
					if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK
							&& (cell.toString().trim().length() != 0))
						emptyRow = Boolean.FALSE;
				}
				if (emptyRow) {
					break;
				}
				Iterator<Cell> cellIterator = currentRow.iterator();

				while (cellIterator.hasNext()) {
					ErrorDTO error = null;
					Cell currentCell = cellIterator.next();
					Integer colIndex = currentCell.getColumnIndex();
					Integer rowIndex = currentCell.getRow().getRowNum();

					error = holderValidationService(fileType, currentCell, colIndex, rowIndex);
					if (error != null) {
						error.setRequestID(reqID);
						applicationDao.updateErrorGrid(cordaRPCService, error);
					}

				}

				if (excelValid) {

					if (fileType.equalsIgnoreCase("POLICYHOLDER")) {

						applicationDao.insertHolderStg(cordaRPCService, reqID, aadhar, pan, gender, firstName,
								middleName, lastName, dob, address, state, nriStatus, education, employement, pinCode,
								LocalDateTime.now());

					} else if (fileType.equalsIgnoreCase("POLICY")) {
						applicationDao.insertPolicyStg(cordaRPCService, reqID, policyAadhar, nomineeName, policyNumber,
								policyStartDate, policyStatus, premium, prodType, renewalFreq, sourcing, sumAssured,
								uinNumber, passportNumber, LocalDateTime.now());

					} else {

						applicationDao.insertClaimStg(cordaRPCService, reqID, claimAadhar, claimDate, claimId,
								claimStatus, claimSubStatus, claimType, fraudStatus, claimPolicyNum,
								LocalDateTime.now());

					}
				}

			}
			wb.close();
			if (excelValid) {

				if (fileType.equalsIgnoreCase("POLICYHOLDER")) {
					processPolicyHolderFile(reqID);

				} else if (fileType.equalsIgnoreCase("POLICY")) {

					processPolicyFile(reqID);

				} else {
					processClaimFile(reqID);

				}
			} else {
				applicationDao.updateGrid(cordaRPCService, reqID);
				applicationDao.deleteStg(cordaRPCService, reqID, fileType.toUpperCase());
			}
			inputStream.close();
		} catch (Exception ioe) {
			try {
				applicationDao.updateGrid(cordaRPCService, reqID);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("Error in catch Block while trying to update error in grid details due to system failure");
				e.printStackTrace();
			} catch (ActiveMQException e) {
				// TODO Auto-generated catch block
				System.out.println("Error in catch Block while trying to update error in grid details due to system failure");
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Grid details updated to error status due to system failure");
			ioe.printStackTrace();
			//throw ioe;
		}
		
	}

	private ErrorDTO holderValidationService(String fileType, Cell currentCell, Integer colIndex, Integer rowIndex)
			throws InterruptedException, ExecutionException, ActiveMQException {
		String node = nodeName();
		if (fileType.equalsIgnoreCase("POLICYHOLDER")) {
			// String error = "";
			ErrorDTO errTO = null;
			switch (colIndex) {

			case 0: {
				String adharPattern = "[0-9]+";
				String adharStr = currentCell.toString();
				// String adharStr=String.valueOf(adharNum);
				if ((adharStr.matches(adharPattern)) && (adharStr.length() == 12)) {
					// error = "";
					aadhar = Long.valueOf(adharStr);
					break;
				} else if (adharStr.length() == 0 || adharStr.isEmpty()) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Aadhar Number");
					errTO.setErrorDetails("Blank Aadhar number");
					excelValid = false;
					break;

				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Aadhar Number");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}
			case 1: {
				String panPattern = "[A-Za-z]{5}\\d{4}[A-Za-z]{1}";
				String panStr = currentCell.getStringCellValue();
				if ((panStr.matches(panPattern)) && (panStr.length() == 10)) {
					// error = "";
					pan = panStr;
					break;
				} else if (panStr.length() == 0 || panStr.isEmpty()) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("PAN");
					errTO.setErrorDetails("Blank PAN number");
					excelValid = false;
					break;
				}

				else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("PAN");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}
			case 2: {
				String genderStr = "MFO";
				String gend = currentCell.getStringCellValue();

				if ((genderStr.contains(gend)) && (gend.length() == 1)) {
					// error = "";
					gender = gend.charAt(0);
					break;
				} else if (gend.length() == 0 || gend.isEmpty()) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Gender");
					errTO.setErrorDetails("Blank Gender");
					excelValid = false;
					break;
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Gender");
					errTO.setErrorDetails("Invalid Gender Value");
					excelValid = false;
					break;
				}
			}

			case 3: {
				String namePattern = "^[a-zA-Z.]+$";
				String fName = currentCell.getStringCellValue();

				if ((fName.isEmpty()) || ((fName.matches(namePattern)) && (fName.length() <= 30))) {
					if (fName.isEmpty()) {
						// error = "";
						firstName = "";
						break;
					} else {
						// error = "";
						firstName = fName;
						break;
					}

				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("First Name");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}
			case 4: {
				String namePattern = "^[a-zA-Z.]+$";
				String lName = currentCell.getStringCellValue();

				if ((lName.matches(namePattern)) && (lName.length() <= 30)) {
					// error = "";
					lastName = lName;
					break;
				} else if (lName.length() == 0 || lName.isEmpty()) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Last Name");
					errTO.setErrorDetails("Blank Last Name");
					excelValid = false;
					break;
				}

				else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Last Name");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}
			case 5: {
				// double exlDate=currentCell.getNumericCellValue();
				String bDateString = currentCell.toString();
				if (bDateString.length() == 7) {
					bDateString = "0".concat(bDateString);
				}
				DateFormat df = new SimpleDateFormat(inDateFormat);
				df.setLenient(false);

				try {
					Date birthDt = df.parse(bDateString);
					LocalDate dateInput = birthDt.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
					LocalDate curDate = LocalDate.now();
					if (dateInput.isAfter(curDate)) {
						errTO = new ErrorDTO();
						errTO.setColNum(colIndex);
						errTO.setRowNum(rowIndex);
						errTO.setFieldName("Date of Birth");
						excelValid = false;
						errTO.setErrorDetails("Date of Birth cannot be in future");
					} else {
						dob = dateInput;
					}

					break;

				} catch (ParseException e) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Date of Birth");
					excelValid = false;
					if (bDateString.length() == 0 || bDateString.isEmpty()) {
						errTO.setErrorDetails("Blank Date of Birth");
					} else {
						errTO.setErrorDetails("Invalid Date of Birth");
					}
					break;

				}

			}

			case 6: {
				String addr = currentCell.getStringCellValue();

				if (((addr.isEmpty()) || (addr.length() <= 100))) {
					if (currentCell.getStringCellValue().isEmpty()) {
						// error = "";
						address = "";
						break;
					} else {
						// error = "";
						address = addr;
						break;
					}

				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Address");
					errTO.setErrorDetails("Address length greater than 100 characters");
					excelValid = false;
					break;
				}
			}
			case 7: {
				String stat = currentCell.getStringCellValue();

				if (((stat.isEmpty()) || (stat.length() <= 20))) {
					if (stat.isEmpty()) {
						// error = "";
						state = "";
						break;
					} else {
						// error = "";
						state = stat;
						break;
					}
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("State");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}
			case 8: {
				String nri = currentCell.getStringCellValue();

				if ((nri.length() == 1 && (nri.equalsIgnoreCase("Y") || nri.equalsIgnoreCase("N")))) {
					// error = "";
					nriStatus = nri.charAt(0);
					break;
				} else if (nri.length() == 0 || nri.isEmpty()) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("NRI Status");
					errTO.setErrorDetails("Blank NRI Status");
					excelValid = false;
					break;
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("NRI Status");
					errTO.setErrorDetails("Invalid NRI status");
					excelValid = false;
					break;

				}
			}
			case 9: {
				String edu = currentCell.getStringCellValue();

				if (((edu.isEmpty()) || (edu.length() <= 100))) {
					if (currentCell.getStringCellValue().isEmpty()) {
						// error = "";
						education = "";
						break;
					} else {
						// error = "";
						education = edu;
						break;
					}

				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Education");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;

				}
			}
			case 10: {
				String employ = currentCell.getStringCellValue();

				if (((employ.isEmpty()) || (employ.length() <= 100))) {
					if (employ.isEmpty()) {
						// error = "";
						employement = "";
						break;
					} else {
						// error = "";
						employement = employ;
						break;
					}

				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Employement");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}
			case 11: {
				String pinCodePattern = "[0-9]+";
				// double pinCode=currentCell.getNumericCellValue();
				String pinStr = currentCell.toString();
				if ((pinStr.isEmpty()) || ((pinStr.matches(pinCodePattern)) && (pinStr.length() == 6))) {
					if (pinStr.isEmpty()) {
						// error = "";
						pinCode = null;
						break;
					} else {
						// error = "";
						pinCode = Integer.valueOf(pinStr);
						break;
					}

				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Pin Code");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}

			}

			case 12: {
				String namePattern = "^[a-zA-Z.]+$";

				if (((currentCell.getStringCellValue().isEmpty())
						|| (currentCell.getStringCellValue().matches(namePattern))
								&& (currentCell.getStringCellValue().length() <= 30))) {
					if (currentCell.getStringCellValue().isEmpty()) {
						// error = "";
						middleName = "";
						break;
					} else {
						// error = "";
						middleName = currentCell.getStringCellValue();
						break;
					}

				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Middle name");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;

				}

			}
			}

			return errTO;
		} else if (fileType.equalsIgnoreCase("POLICY")) {
			// String error = "";
			ErrorDTO errTO = null;
			switch (colIndex) {

			case 0: {
				String sourcingrStr = "DP";
				String src = currentCell.getStringCellValue();

				if ((sourcingrStr.contains(src)) && (src.length() == 1)) {
					// error = "";
					sourcing = src.charAt(0);
					break;
				} else if (src.length() == 0 || src.isEmpty()) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Sourcing");
					errTO.setErrorDetails("Blank Sourcing");
					excelValid = false;
					break;
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Sourcing");
					errTO.setErrorDetails("Invalid Sourcing Value");
					excelValid = false;
					break;
				}
			}
			case 1: {
				String adharPattern = "[0-9]+";
				String adharStr = currentCell.toString();
				if ((adharStr.matches(adharPattern)) && (adharStr.length() == 12)) {
					Boolean isAadhar;
					// String node = nodeName();
					isAadhar = rpcService.startFlowDynamic(ApplicationDaoCallFlow.isAadharPresent.class, node,
							Long.valueOf(adharStr)).getReturnValue().get();
					if (isAadhar) {
						policyAadhar = Long.valueOf(adharStr);
					} else {
						errTO = new ErrorDTO();
						errTO.setColNum(colIndex);
						errTO.setRowNum(rowIndex);
						errTO.setFieldName("Aadhar Number");
						errTO.setErrorDetails("Aadhar number not present in System.");
						excelValid = false;
					}

					break;
				} else if (adharStr.length() == 0 || adharStr.isEmpty()) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Aadhar Number");
					errTO.setErrorDetails("Blank Aadhar");
					excelValid = false;
					break;
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Aadhar Number");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}
			case 2: {
				String policyPatter = "^[a-zA-Z0-9]*$";
				String policyStr = currentCell.toString();
				// String adharStr=String.valueOf(adharNum);
				if ((policyStr.matches(policyPatter)) && (policyStr.length() == 10)) {
					// error = "";
					policyNumber = policyStr;
					break;
				} else if (policyStr.length() == 0 || policyStr.isEmpty())

				{
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Policy Number");
					errTO.setErrorDetails("Blank Policy Number");
					excelValid = false;
					break;
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Policy Number");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}
			case 3: {
				String uinPattern = "^[a-zA-Z0-9]*$";
				String uin = currentCell.toString();

				if ((uin.isEmpty()) || (uin.length() == 12 && uin.matches(uinPattern))) {
					if (uin.isEmpty()) {
						// error = "";
						uinNumber = "";
						break;
					} else {
						// error = "";
						uinNumber = currentCell.getStringCellValue();
						break;
					}

				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("UIN Number");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}

			case 4: {
				String prodTypeStr = "TURE";
				String prod = currentCell.getStringCellValue();

				if ((prodTypeStr.contains(prod)) && (prod.length() == 1)) {
					// error = "";
					prodType = prod.charAt(0);
					break;
				} else if (prod.length() == 0 || prod.isEmpty())

				{
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Type of Product");
					errTO.setErrorDetails("Blank Product Type");
					excelValid = false;
					break;
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Type of Product");
					errTO.setErrorDetails("Invalid Product Type");
					excelValid = false;
					break;

				}
			}
			case 5: {
				String nomineeNamePattern = "^[a-zA-Z.]+$";
				String nom = currentCell.getStringCellValue();

				if ((nom.matches(nomineeNamePattern)) && (nom.length() <= 20)) {
					// error = "";
					nomineeName = nom;
					break;
				} else if (nom.length() == 0 || nom.isEmpty()) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Nominee Name");
					errTO.setErrorDetails("Blank Nominee Name");
					excelValid = false;
					break;
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Nominee Name");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}
			case 6: {
				String policyStatusStr = "ILSMD";
				String polStat = currentCell.getStringCellValue();
				if ((polStat.isEmpty()) || (polStat.length() == 1 && policyStatusStr.contains(polStat))) {
					if ((polStat.isEmpty())) {
						policyStatus = Character.MIN_VALUE;
						break;
						// error = "";
					} else {
						policyStatus = polStat.charAt(0);
						break;
						// error = "";
					}
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Policy Status");
					errTO.setErrorDetails("Invalid Policy Status Value");
					excelValid = false;
					break;
				}
			}

			case 7: {
				Double premiumIntVal;
				// String numPattern = " /^[0-9]+([,.][0-9]+)?$";
				if (currentCell.toString().isEmpty()) {

					premium = null;
					break;
					// error = "";
				} else if ((premiumIntVal = Double.valueOf(currentCell.toString())) >= 0) {
					premium = premiumIntVal;
					break;

					// error = "";
				}

				else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Premium");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}
			case 8: {
				Double assuredIntVal;
				// String numPattern = " /^[0-9]+([,.][0-9]+)?$";
				if (!currentCell.toString().isEmpty()
						&& (assuredIntVal = Double.valueOf(currentCell.toString())) >= 0) {
					sumAssured = assuredIntVal;
					break;
					// error = "";
				} else if (currentCell.toString().isEmpty() || currentCell.toString().length() == 0) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Sum Assured");
					errTO.setErrorDetails("Blank Sum Assured");
					excelValid = false;
					break;
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Sum Assured");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}
			case 9: {
				String renewalStr = "SMY";
				String renew = currentCell.getStringCellValue();
				if ((renew.isEmpty()) || (renew.length() == 1 && renewalStr.contains(renew))) {
					if ((renew.isEmpty())) {
						renewalFreq = Character.MIN_VALUE;
						break;
						// error = "";
					} else {
						renewalFreq = renew.charAt(0);
						break;
						// error = "";
					}
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Renewal Frequency");
					errTO.setErrorDetails("Invalid Renewal Frequency Value");
					excelValid = false;
					break;
				}
			}
			case 10: {

				String policyDate = currentCell.toString();
				if (policyDate.length() == 7) {
					policyDate = "0".concat(policyDate);
				}
				DateFormat df = new SimpleDateFormat(inDateFormat);
				df.setLenient(false);
				if (policyDate.isEmpty()) {
					policyStartDate = null;
					break;
					// error = "";
				} else {

					try {
						Date polDate = df.parse(policyDate);
						LocalDate startDate = polDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
						// error = "";
						policyStartDate = startDate;
						break;

					} catch (ParseException e) {
						errTO = new ErrorDTO();
						errTO.setColNum(colIndex);
						errTO.setRowNum(rowIndex);
						errTO.setFieldName("Policy Start Date");
						errTO.setErrorDetails("Error in Policy Start Date");
						excelValid = false;
						break;
					}
				}

			}

			case 11: {
				String passportStr = "^[a-zA-Z0-9]*$";
				String pass = currentCell.toString();

				if (((pass.isEmpty()) || (pass.length() <= 10 && pass.matches(passportStr)))) {
					if (pass.isEmpty()) {
						// error = "";
						passportNumber = "";
						break;
					} else {
						// error = "";
						passportNumber = pass;
						break;
					}

				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Under Passport");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}
			}

			return errTO;

		} else {
			ErrorDTO errTO = null;
			switch (colIndex) {

			case 0: {
				String policyPattern = "^[a-zA-Z0-9]*$";
				String claimPolicyStr = currentCell.toString();
				// String adharStr=String.valueOf(adharNum);
				if ((claimPolicyStr.matches(policyPattern)) && (claimPolicyStr.length() == 10)) {

					String adhr;
					// String node = nodeName();
					adhr = rpcService
							.startFlowDynamic(ApplicationDaoCallFlow.getAadharByPolicy.class, node, claimPolicyStr)
							.getReturnValue().get();

					if (adhr != null && (adhr.length() > 0)) {
						claimPolicyNum = claimPolicyStr;
						claimAadhar = Long.valueOf(adhr);

					} else {
						errTO = new ErrorDTO();
						errTO.setColNum(colIndex);
						errTO.setRowNum(rowIndex);
						errTO.setFieldName("Policy Number");
						errTO.setErrorDetails("Policy Number does not exist in System.");
						excelValid = false;

					}

					break;

				}

				else if (claimPolicyStr.length() == 0 || claimPolicyStr.isEmpty()) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Policy Number");
					errTO.setErrorDetails("Blank Policy Number");
					excelValid = false;
					break;
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Policy Number");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}
			}
			case 1: {
				String claimStatusStr = "PR";
				String claimStat = currentCell.getStringCellValue();
				if ((claimStatusStr.contains(claimStat)) && (claimStat.length() == 1)) {
					// error = "";
					claimStatus = claimStat.charAt(0);
					break;
				} else if (claimStat.length() == 0 || claimStat.isEmpty()) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Claim Status");
					errTO.setErrorDetails("Blank Claim Status");
					excelValid = false;
					break;
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Claim Status");
					errTO.setErrorDetails("Invalid Claim Status");
					excelValid = false;
					break;
				}
			}

			case 2: {
				String claimSubStatusStr = "ARDFN";
				String subStat = currentCell.getStringCellValue();
				if ((subStat.isEmpty()) || ((claimSubStatusStr.contains(subStat)) && (subStat.length() == 1))) {
					if ((subStat.isEmpty())) {
						claimSubStatus = Character.MIN_VALUE;
						break;

					} else {
						claimSubStatus = subStat.charAt(0);
						break;

					}
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Claim Sub Status");
					errTO.setErrorDetails("Invalid Claim Sub Status");
					excelValid = false;
					break;
				}
			}
			case 3: {
				String fraud = currentCell.getStringCellValue();
				if ((fraud.isEmpty()) || (fraud.equalsIgnoreCase("clear"))
						|| (fraud.equalsIgnoreCase("under investigation")) || (fraud.equalsIgnoreCase("declined"))) {
					if ((fraud.isEmpty())) {
						fraudStatus = Character.MIN_VALUE;
						break;

					} else {
						fraudStatus = fraud.charAt(0);
						break;

					}
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Fraud Status");
					errTO.setErrorDetails("Invalid Fraud Status");
					excelValid = false;
					break;
				}

			}
			case 4: {
				String claimTypeStr = "NSO";
				String clmType = currentCell.getStringCellValue();
				if ((clmType.isEmpty()) || ((claimTypeStr.contains(clmType)) && (clmType.length() == 1))) {
					if ((clmType.isEmpty())) {
						claimType = Character.MIN_VALUE;
						break;
						// error = "";
					} else {
						claimType = clmType.charAt(0);
						break;
						// error = "";
					}
				} else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Claim Type");
					errTO.setErrorDetails("Invalid Claim Type");
					excelValid = false;
					break;
				}
			}
			case 5: {

				String claimDateStr = currentCell.toString();
				if (claimDateStr.length() == 7) {
					claimDateStr = "0".concat(claimDateStr);
				}

				DateFormat df = new SimpleDateFormat(inDateFormat);
				df.setLenient(false);
				try {
					Date clmDate = df.parse(claimDateStr);
					LocalDate lClaimDate = clmDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

					claimDate = lClaimDate;
					break;

				} catch (ParseException e) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Claim Date");
					excelValid = false;
					if (claimDateStr.length() == 0) {
						errTO.setErrorDetails("Blank Claim Date");

					} else {
						errTO.setErrorDetails("Error in Claim Date");
					}
					break;

				}
			}
			case 6: {
				String claimIdpattern = "^[a-zA-Z0-9]*$";

				String claimidStr = currentCell.toString();
				// String adharStr=String.valueOf(adharNum);
				if ((claimidStr.matches(claimIdpattern))) {

					claimId = claimidStr;
					break;
				} else if (claimidStr.length() == 0 || claimidStr.isEmpty()) {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Claim ID");
					errTO.setErrorDetails("Blank Claim ID");
					excelValid = false;
					break;
				}

				else {
					errTO = new ErrorDTO();
					errTO.setColNum(colIndex);
					errTO.setRowNum(rowIndex);
					errTO.setFieldName("Claim ID");
					errTO.setErrorDetails("Format Error");
					excelValid = false;
					break;
				}

			}
			}

			return errTO;
		}

	}

	@POST
	@Path("/table-creation")
	public void tableCreation() throws ClassNotFoundException, SQLException {
		// ApplicationDAO appDAO = new ApplicationDAO();
		try {
			applicationDao.createGridTables(cordaRPCService);
		} catch (ActiveMQException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void asyncServiceMethod (final InputStream file, final String fileName) {
		Runnable task = new Runnable() {
			public void run() {

				
				
						excelUpload(file, fileName);
					
				
					// TODO Auto-generated catch block
			

			}

		};
		new Thread(task, "ServiceThread").start();

	}

	@GET
	@Path("/grid-display")
	@Produces(MediaType.APPLICATION_JSON)
	public List<GridDTO> displayGrid()
			throws ActiveMQException, JsonProcessingException, ClassNotFoundException, SQLException {
		// ApplicationDAO appDAO = new ApplicationDAO();

		List<GridDTO> dispList = applicationDao.getGridError(cordaRPCService);

		return dispList;

	}

	@SuppressWarnings("unchecked")
	@GET
	@Path("/vault-display-holder")
	@Produces(MediaType.APPLICATION_JSON)
	public List<PolicyHolder> vaultDisplayHolder()
			throws ActiveMQException, JsonProcessingException, InterruptedException, ExecutionException {

		// ApplicationDao cordaDao = new ApplicationDao();
		String node = nodeName();
		List<PolicyHolder> vaultHolderList = new ArrayList<PolicyHolder>();
		vaultHolderList = (List<PolicyHolder>) rpcService
				.startFlowDynamic(ApplicationDaoCallFlow.SearchPolicyHolder.class, node).getReturnValue().get();

		return vaultHolderList;

	}

	@SuppressWarnings("unchecked")
	@GET
	@Path("/vault-display-policy")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Policy> vaultDisplayPolicy()
			throws ActiveMQException, JsonProcessingException, InterruptedException, ExecutionException {

		// ApplicationDao cordaDao = new ApplicationDao();
		String node = nodeName();
		List<Policy> vaultPolicyList = new ArrayList<Policy>();
		vaultPolicyList = (List<Policy>) rpcService.startFlowDynamic(ApplicationDaoCallFlow.SearchPolicy.class, node)
				.getReturnValue().get();

		return vaultPolicyList;

	}

	@SuppressWarnings("unchecked")
	@GET
	@Path("/vault-display-claim")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Claim> vaultDisplayClaim()
			throws ActiveMQException, JsonProcessingException, InterruptedException, ExecutionException {
		String node = nodeName();
		List<Claim> vaultClaimList = new ArrayList<Claim>();
		vaultClaimList = (List<Claim>) rpcService.startFlowDynamic(ApplicationDaoCallFlow.searchClaim.class, node)
				.getReturnValue().get();

		return vaultClaimList;

	}

	@GET
	@Path("/download-excel/{reqId}/{docName}")
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response excelDownload(@PathParam("reqId") String reqId, @PathParam("docName") String docName)
			throws ActiveMQException, IOException, ClassNotFoundException, SQLException {
		String node = nodeName();
		// ApplicationDAO appDAO = new ApplicationDAO();
		ResponseBuilder responseBuilder = applicationDao.downloadexcel(cordaRPCService, reqId);
		// ResponseBuilder responseBuilder = Response.ok((Object) file);
		responseBuilder.header("Content-Disposition", "attachment; filename=\"" + docName + "\"");

		return responseBuilder.build();
	}

	@POST
	@Path("/login")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response loginService(@FormDataParam("username") String userName, @FormDataParam("password") String password,
			@FormDataParam("ip") String ip) throws ActiveMQException, ClassNotFoundException, SQLException {
		// ApplicationDAO appDAO = new ApplicationDAO();
		Status validStatus;
		String validMsg;

		Boolean isValid = applicationDao.validateLogin(cordaRPCService, userName, password, ip);
		if (isValid) {
			validStatus = Response.Status.OK;
			validMsg = "SUCCESS";
		} else {
			validStatus = Response.Status.NOT_FOUND;
			validMsg = "ERROR";
		}
		return Response.status(validStatus).entity(validMsg).build();

	}

	@POST
	@Path("store-policyholder/{reqId}")
	public void processPolicyHolderFile(@PathParam("reqId") String requestId)
			throws SQLException, ActiveMQException, InterruptedException, ExecutionException, ClassNotFoundException,Exception {

		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		// TODO
		// change
		String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();// TODO
																							// change
		Connection dbConn = getDBConnection();
		ResultSet rs = null;
		PreparedStatement ps = null;
		try {
			// change
			String qry = "SELECT * FROM POLICY_HOLDER_STG where REQ_ID = ?";
			ps = dbConn.prepareStatement(qry);
			ps.setString(1, requestId);
			rs = ps.executeQuery();

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

			while (rs.next()) {

				PolicyHolder policyHolder = new PolicyHolder(rs.getLong("AADHAR_NO"), rs.getString("PAN_NO"),
						rs.getString("GENDER").charAt(0), rs.getString("FIRST_NAME"), rs.getString("MIDDLE_NAME"),
						rs.getString("LAST_NAME"), LocalDate.parse(rs.getString("DOB"), formatter),
						rs.getString("ADDRESS"), rs.getString("STATE"), rs.getString("NRI_STATUS").charAt(0),
						rs.getString("EDUCATION"), rs.getString("EMPLOYMENT"), rs.getInt("PINCODE"),
						rs.getTimestamp("UPLOAD_DATE").toLocalDateTime());

				boolean isPublishSuccess = rpcService
						.startFlowDynamic(PolicyHolderDetailStorageFlow.Initiator.class, policyHolder).getReturnValue()
						.get();

				if (isPublishSuccess) {
					// delete temp file data
					String delQry = "delete from POLICY_HOLDER_STG where REQ_ID = ? and AADHAR_NO = ?";
					PreparedStatement delPs = dbConn.prepareStatement(delQry);
					delPs.setString(1, requestId);
					delPs.setLong(2, policyHolder.getAadhar());
					delPs.executeUpdate();
					delPs.close();
				}
			}

			// update ui status table
			String countQry = "select count(*) from POLICY_HOLDER_STG where REQ_ID = ?";
			PreparedStatement countPs = dbConn.prepareStatement(countQry);
			countPs.setString(1, requestId);
			ResultSet countRs = countPs.executeQuery();
			if (countRs.next() && countRs.getInt(1) == 0) {
				String updQry = "update GRID_DETAILS set status = ?,sys_status =? where req_id = ?";
				PreparedStatement updPs = dbConn.prepareStatement(updQry);
				updPs.setString(1, "Success");
				updPs.setString(2, "Published");
				updPs.setString(3, requestId);
				updPs.executeUpdate();
				updPs.close();
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (ps != null) {
				ps.close();
			}

			dbConn.close();
		}

	}

	@POST
	@Path("store-policy/{reqId}")
	public void processPolicyFile(@PathParam("reqId") String requestId)
			throws SQLException, ActiveMQException, InterruptedException, ExecutionException, ClassNotFoundException,Exception {

		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort); // TODO
																							// change
		String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		Connection dbConn = null;// TODO
									// change
		try {
			dbConn = getDBConnection();// TODO
										// change

			String distinctAadharQry = "SELECT distinct AADHAR_NO from POLICY_STG where REQ_ID = ?";
			PreparedStatement distinctAadharPs = dbConn.prepareStatement(distinctAadharQry);
			distinctAadharPs.setString(1, requestId);
			ResultSet distinctAadharRs = distinctAadharPs.executeQuery();
			while (distinctAadharRs.next()) {

				long aadharNo = distinctAadharRs.getLong(1);
				String policyQry = "SELECT * FROM POLICY_STG where AADHAR_NO =? and REQ_ID = ?";
				PreparedStatement policyPs = dbConn.prepareStatement(policyQry);
				policyPs.setLong(1, aadharNo);
				policyPs.setString(2, requestId);
				ResultSet policyRs = policyPs.executeQuery();

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				List<Policy> aadharSpecificPolicyList = new ArrayList<>();
				while (policyRs.next()) {

					Policy policy = new Policy(policyRs.getString("SOURCE").charAt(0), policyRs.getLong("AADHAR_NO"),
							policyRs.getString("POLICY_NO"), policyRs.getString("UIN_NO"),
							policyRs.getString("PRODUCT_TYPE").charAt(0), policyRs.getString("NOMINEE_NAME"),
							policyRs.getString("POLICY_STATUS").charAt(0), policyRs.getDouble("PREMIUM"),
							policyRs.getBigDecimal("SUM_ASSURED"), policyRs.getString("RENEWAL_FREQUENCY").charAt(0),
							LocalDate.parse(policyRs.getString("POLICY_START_DATE"), formatter),
							policyRs.getString("UNDER_PASSPORT"),
							policyRs.getTimestamp("UPLOAD_DATE").toLocalDateTime());
					aadharSpecificPolicyList.add(policy);
				}
				if(policyRs!=null)
				{
					policyRs.close();
				}
				if(policyPs!=null)
				{
					policyPs.close();
				}
				
				// call corda flow
				boolean isPublishSuccess = rpcService
						.startFlowDynamic(PolicyDetailStorageFlow.Initiator.class, aadharSpecificPolicyList)
						.getReturnValue().get();

				if (isPublishSuccess) {
					// delete temp file data
					String delQry = "delete from POLICY_STG where REQ_ID = ? and AADHAR_NO = ?";
					PreparedStatement delPs = dbConn.prepareStatement(delQry);
					delPs.setString(1, requestId);
					delPs.setLong(2, aadharNo);
					delPs.executeUpdate();
					delPs.close();
				}
			}
			// update ui status table
			String countQry = "select count(*) from POLICY_STG where REQ_ID = ?";
			PreparedStatement countPs = dbConn.prepareStatement(countQry);
			countPs.setString(1, requestId);
			ResultSet countRs = countPs.executeQuery();
			if (countRs.next() && countRs.getInt(1) == 0) {
				String updQry = "update GRID_DETAILS set status = ?,sys_status =? where req_id = ?";
				PreparedStatement updPs = dbConn.prepareStatement(updQry);
				updPs.setString(1, "Success");
				updPs.setString(2, "Published");
				updPs.setString(3, requestId);
				updPs.executeUpdate();
				updPs.close();
			}
			if(countRs!=null)
			{
				countRs.close();
			}
			
			countPs.close();
			distinctAadharRs.close();
			distinctAadharPs.close();
		} finally {
			dbConn.close();
		}

	}

	// process claim file
	@POST
	@Path("store-claim/{reqId}")
	public void processClaimFile(@PathParam("reqId") String requestId)
			throws SQLException, ActiveMQException, InterruptedException, ExecutionException, ClassNotFoundException,Exception {

		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		Connection dbConn = null;
		try {
			dbConn = getDBConnection();

			String distinctAadharQry = "SELECT distinct AADHAR_NO from CLAIM_STG where REQ_ID = ?";
			PreparedStatement distinctAadharPs = dbConn.prepareStatement(distinctAadharQry);
			distinctAadharPs.setString(1, requestId);
			ResultSet distinctAadharRs = distinctAadharPs.executeQuery();
			while (distinctAadharRs.next()) {

				long aadharNo = distinctAadharRs.getLong(1);
				String claimQry = "SELECT * FROM CLAIM_STG where AADHAR_NO =? and REQ_ID = ?";
				PreparedStatement claimPs = dbConn.prepareStatement(claimQry);
				claimPs.setLong(1, aadharNo);
				claimPs.setString(2, requestId);
				ResultSet claimRs = claimPs.executeQuery();

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				List<Claim> aadharSpecificClaimList = new ArrayList<>();
				while (claimRs.next()) {

					Claim claim = new Claim(claimRs.getLong("AADHAR_NO"), claimRs.getString("POLICY_NO"),
							claimRs.getString("CLAIM_ID"), claimRs.getString("CLAIM_STATUS").charAt(0),
							claimRs.getString("CLAIM_SUB_STATUS").charAt(0),
							claimRs.getString("FRAUD_STATUS").charAt(0), claimRs.getString("CLAIM_TYPE").charAt(0),
							LocalDate.parse(claimRs.getString("CLAIM_DATE"), formatter),
							claimRs.getTimestamp("UPLOAD_DATE").toLocalDateTime());
					aadharSpecificClaimList.add(claim);
				}
				if(claimRs!=null)
				{
					claimRs.close();
				}
				
				claimPs.close();
				// call corda flow
				boolean isPublishSuccess = rpcService
						.startFlowDynamic(ClaimDetailStorageFlow.Initiator.class, aadharSpecificClaimList)
						.getReturnValue().get();

				if (isPublishSuccess) {
					// delete temp file data
					String delQry = "delete from CLAIM_STG where REQ_ID = ? and AADHAR_NO = ?";
					PreparedStatement delPs = dbConn.prepareStatement(delQry);
					delPs.setString(1, requestId);
					delPs.setLong(2, aadharNo);
					delPs.executeUpdate();
					delPs.close();
				}
			}
			// update ui status table
			String countQry = "select count(*) from CLAIM_STG where REQ_ID = ?";
			PreparedStatement countPs = dbConn.prepareStatement(countQry);
			countPs.setString(1, requestId);
			ResultSet countRs = countPs.executeQuery();
			if (countRs.next() && countRs.getInt(1) == 0) {
				String updQry = "update GRID_DETAILS set status = ?, sys_status =? where req_id = ?";
				PreparedStatement updPs = dbConn.prepareStatement(updQry);
				updPs.setString(1, "Success");
				updPs.setString(2, "Published");
				updPs.setString(3, requestId);
				updPs.executeUpdate();
				updPs.close();
			}
			if(countRs!=null)
			{
				countRs.close();
			}
			
			countPs.close();
			if(distinctAadharRs!=null)
			{
				distinctAadharRs.close();
			}
			
			distinctAadharPs.close();
		} finally {
			dbConn.close();
		}
	}

	@GET
	@Path("aggregated-data/{aadhar}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Object> queryAggragateData(@PathParam("aadhar") Long aadharNo)
			throws ActiveMQException, InterruptedException, ExecutionException,Exception {

		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		List<Object> fullAggregatedList = new ArrayList<>();
		AggregatedData aggregatedData = rpcService.startFlowDynamic(AggregateQueryFlow.Initiator.class, aadharNo)
				.getReturnValue().get();

		if (null != aggregatedData) {
			// prepare individual data
			List<AggregatedDataTO> dataList = new ArrayList<>();
			dataList.add(new AggregatedDataTO("Last NRI Status", "Last_NRI_Status",
					aggregatedData.getLastNRIStatus().toString()));
			dataList.add(new AggregatedDataTO("Last known employment", "Last_known_employment",
					aggregatedData.getLastKnownEmployment()));
			dataList.add(new AggregatedDataTO("Last-Residence state", "Last_Residence_state",
					aggregatedData.getLastResidenceState()));
			dataList.add(new AggregatedDataTO("Last known pan number", "Last_known_pan_number",
					aggregatedData.getLastKnownPAN()));
			dataList.add(new AggregatedDataTO("No. of traditional policies owned in all insurance companies",
					"No_of_traditional_policies", aggregatedData.getTotalTradPolicy() + ""));
			dataList.add(new AggregatedDataTO("Total sum assured for this policy holder amongst all companies",
					"Total_sum_assured", aggregatedData.getTotalSumAssured() + ""));
			dataList.add(new AggregatedDataTO("No. of ULIP policies for in all insurers", "No_of_ULIP",
					aggregatedData.getTotalULIPPolicy() + ""));
			dataList.add(new AggregatedDataTO("No. of claims in the system in all insurers", "No_of_claims",
					aggregatedData.getTotalClaim() + ""));
			dataList.add(new AggregatedDataTO("No. of claims repudiated in all insurers", "No_of_claims_repudiated",
					aggregatedData.getTotalRepudiatedClaim() + ""));
			dataList.add(new AggregatedDataTO("Number of different PAN numbers in the system in all insurers",
					"No_of_different_PAN", aggregatedData.getTotalPanNo() + ""));
			dataList.add(new AggregatedDataTO("Ratio of claims not approved for all insurers", "Ratio_of_claims",
					aggregatedData.getRatio() + ""));
			dataList.add(new AggregatedDataTO("No. of policies with this same nominee in all insurers",
					"No_of_policies", aggregatedData.getTotalNomineeWisePolicy() + ""));

			fullAggregatedList.add(dataList);
			// prepare graph1 claim trend data
			GraphDisplayTO graph1 = new GraphDisplayTO();
			List<GraphLabel> category = graph1.getCategory();
			List<GraphValue> data = graph1.getData();

			Iterator<Entry<String, Double>> claimCountItr = aggregatedData.getMonthWiseClaimCountMap().entrySet()
					.iterator();
			while (claimCountItr.hasNext()) {
				Entry<String, Double> x = claimCountItr.next();
				category.add(new GraphLabel(x.getKey().substring(0, 3)));
				data.add(new GraphValue(x.getValue().toString()));
			}

			Collections.reverse(category);
			Collections.reverse(data);

			fullAggregatedList.add(graph1);

			// prepare graph2 sum assured data
			GraphDisplayTO graph2 = new GraphDisplayTO();
			List<GraphLabel> category2 = graph2.getCategory();
			List<GraphValue> data2 = graph2.getData();

			Iterator<Entry<String, Double>> sumAssuredItr = aggregatedData.getMonthWiseSumAssuredMap().entrySet()
					.iterator();
			while (sumAssuredItr.hasNext()) {
				Entry<String, Double> x = sumAssuredItr.next();
				category2.add(new GraphLabel(x.getKey().substring(0, 3)));
				data2.add(new GraphValue(x.getValue().toString()));
			}
			Collections.reverse(category2);
			Collections.reverse(data2);
			fullAggregatedList.add(graph2);
		}

		return fullAggregatedList;
	}

	@POST
	@Path("/allocatePoint")
	public void allocateInitialPoint() throws ActiveMQException {

		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		rpcService.startFlowDynamic(InitialPointAllocationFlow.Initiator.class);
	}

	private Connection getDBConnection() throws SQLException, ClassNotFoundException,Exception {

		Class.forName("org.h2.Driver");
		String dbConnectionString = nodeDbConnection;
		Connection dbConn = DriverManager.getConnection(dbConnectionString, "sa", "");

		return dbConn;
	}

	@POST
	@Path("/pre-validation/upload")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadPreValidationFile(@FormDataParam("file") InputStream preValidationInputStream,
			@FormDataParam("file") FormDataContentDisposition preValidationFileDetail)
			throws InterruptedException, ExecutionException {

		CordaRPCOps rpcService;
		Response response = null;
		XSSFWorkbook inputWorkBook = null;
		try {
			rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);

			Party me = rpcService.nodeIdentity().getLegalIdentity();
			Set<Party> priorityMemberSet = rpcService.startFlowDynamic(ConsortiumFlow.PriorityMemberList.class, me)
					.getReturnValue().get();
			if (priorityMemberSet.size() == 0) {
				return Response.status(Status.FORBIDDEN).entity("Insurer not part of any Priority network").build();
			}

			// validate file
			inputWorkBook = new XSSFWorkbook(preValidationInputStream);
			Iterator<Row> itr = inputWorkBook.getSheetAt(0).iterator();
			boolean isFileValid = true;
			while (itr.hasNext()) {
				Row currRow = itr.next();
				if (currRow.getRowNum() == 0) {
					continue;
				}

				String aadharNum = currRow.getCell(0).toString();
				String gender = currRow.getCell(1).toString();
				String dateOfBirth = currRow.getCell(2).toString();
				String nriStatus = currRow.getCell(3).toString();

				String adharPattern = "[0-9]+";
				if (!(aadharNum.matches(adharPattern) && aadharNum.length() == 12)) {
					isFileValid = false;
					break;
				}
				String genderStr = "MFO";
				if (!(genderStr.contains(gender) && gender.length() == 1)) {
					isFileValid = false;
					break;
				}
				if (!(nriStatus.length() == 1
						&& (nriStatus.equalsIgnoreCase("Y") || nriStatus.equalsIgnoreCase("N")))) {
					isFileValid = false;
					break;
				}
				LocalDate dateInput = LocalDate.parse(dateOfBirth, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
				if (dateInput.isAfter(LocalDate.now())) {
					isFileValid = false;
					break;
				}

			}

			if (isFileValid) {

				FileOutputStream fos = new FileOutputStream(preValidationFileDetail.getFileName());
				inputWorkBook.write(fos);
				fos.close();

				preValidationInputStream = new FileInputStream(preValidationFileDetail.getFileName());
				SecureHash documentHash = rpcService.uploadAttachment(
						getZipFileStream(preValidationInputStream, preValidationFileDetail.getFileName()));

				rpcService.startFlowDynamic(PreValidationQueryFlow.Initiator.class, documentHash,
						preValidationFileDetail.getFileName());
				response = Response.status(Status.OK).build();
			} else {
				response = Response.status(Status.BAD_REQUEST).build();
			}
		} catch (ActiveMQException | IOException e) {
			e.printStackTrace();
			response = Response.status(Status.BAD_REQUEST).build();
		} finally {
			try {
				if (null != inputWorkBook)
					inputWorkBook.close();
				if (null != preValidationInputStream)
					preValidationInputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return response;
	}

	@GET
	@Path("/pre-validation/detail")
	@Produces(MediaType.APPLICATION_JSON)
	public List<PreValidationRequestTO> getPreValidationDetail()  {

		List<PreValidationRequestTO> preValidationReqList = new ArrayList<>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = getDBConnection();
			String fetchQry = "SELECT REQ_ID ,UPLOADED_FILENAME ,UPLOADED_FILEHASH ,UPLOAD_TIMESTAMP ,"
					+ "DESTINATION_NODE ,STATUS ,DOWNLOAD_FILENAME ,DOWNLOAD_FILEHASH  FROM PRE_VALIDATION_REQUEST_DETAIL ORDER BY UPLOAD_TIMESTAMP DESC";
			ps = con.prepareStatement(fetchQry);
			rs = ps.executeQuery();
			while (rs.next()) {
				PreValidationRequestTO preValidationRequestTO = new PreValidationRequestTO();
				preValidationRequestTO.setReqId(rs.getString(1));
				preValidationRequestTO.setUploadedFileName(rs.getString(2));
				preValidationRequestTO.setUploadedFileHash(rs.getString(3));
				preValidationRequestTO.setUploadDate(rs.getTimestamp(4).toString());
				preValidationRequestTO.setDestinationNode(rs.getString(5));
				preValidationRequestTO.setStatus(rs.getString(6));
				preValidationRequestTO.setDownloadFileName(rs.getString(7));
				preValidationRequestTO.setDownloadFileHash(rs.getString(8));
				preValidationReqList.add(preValidationRequestTO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != rs)
					rs.close();
				if (null != ps)
					ps.close();
				if (null != con)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return preValidationReqList;
	}

	@GET
	@Path("/file/download")
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response getShipmentDocument(@QueryParam("dochash") String docHash, @QueryParam("docname") String docName)
			throws ActiveMQException, IOException {

		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		InputStream docStream = rpcService.openAttachment(SecureHash.parse(docHash));

		ZipInputStream zipIn = new ZipInputStream(docStream);
		ZipEntry entry = zipIn.getNextEntry();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		if (entry != null && !entry.isDirectory()) {
			byte[] bytesIn = new byte[4096];
			int read = 0;
			while ((read = zipIn.read(bytesIn)) != -1) {
				baos.write(bytesIn, 0, read);
			}
		}
		zipIn.closeEntry();
		zipIn.close();
		if (null != docStream)
			docStream.close();
		ResponseBuilder responseBuilder = Response.ok((Object) baos.toByteArray());
		responseBuilder.header("Content-Disposition", "attachment; filename=\"" + docName + "\"");
		baos.close();
		return responseBuilder.build();
	}

	private InputStream getZipFileStream(InputStream docInputStream, String fileName) throws IOException {

		ByteArrayOutputStream out = new ByteArrayOutputStream();

		ZipOutputStream zout = new ZipOutputStream(out);

		zout.putNextEntry(new ZipEntry(fileName));

		byte[] data = new byte[2048];

		int count;

		while ((count = docInputStream.read(data, 0, 2048)) != -1) {

			zout.write(data, 0, count);

		}

		if (null != docInputStream)

			docInputStream.close();

		zout.closeEntry();

		zout.close();

		return new ByteArrayInputStream(out.toByteArray());

	}

	@GET
	@Path("/createCons")
	public void checkConsortium() throws InterruptedException, ExecutionException, ActiveMQException {
		List<Party> partyList = new ArrayList<>();
		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		partyList.add(rpcService.partyFromName("CN=Insurer2,O=MNO,L=Bangalore,C=IND"));
		partyList.add(rpcService.partyFromName("CN=Insurer1,O=XYZ,L=Pune,C=IND"));
		partyList.add(rpcService.partyFromName("CN=Insurer3,O=DEF,L=Kolkata,C=IND"));

		String node = nodeName();
		// List<Claim> vaultClaimList = new ArrayList<Claim>();
		rpcService.startFlowDynamic(ConsortiumFlow.ConsortiumCreator.class, partyList);

	}

	@SuppressWarnings("unchecked")
	@GET
	@Path("/detailedDataGrid")
	@Produces(MediaType.APPLICATION_JSON)
	public List<DetailDataGridTO> detaildataGrid() throws ActiveMQException, InterruptedException, ExecutionException {

		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		List<DetailedDataReqState> detailDataGrid = new ArrayList<DetailedDataReqState>();
		// detailDataGrid=rpcService.vaultQuery(DetailedDataReqState.class).getStates()

		detailDataGrid = (List<DetailedDataReqState>) rpcService
				.startFlowDynamic(ApplicationDaoCallFlow.detailDataDisplay.class).getReturnValue().get();
		Collections.reverse(detailDataGrid);
		List<DetailDataGridTO> gridList = new ArrayList<DetailDataGridTO>();
		for (DetailedDataReqState drq : detailDataGrid) {
			DetailDataGridTO drTO = new DetailDataGridTO();
			drTO.setAadharNo(drq.getAadharNo());
			drTO.setReqId(drq.getReqId());
			if (drq.getStatus().equalsIgnoreCase("NO DATA")) {
				drTO.setDocName(null);
				drTO.setDocHash(null);
			} else {
				drTO.setDocName(drq.getDocName());
				drTO.setDocHash(drq.getDocHash());
			}

			drTO.setStatus(drq.getStatus());
			if (drq.getStatus().equalsIgnoreCase("COMPLETED") || drq.getStatus().equalsIgnoreCase("REJECTED")
					|| drq.getStatus().equalsIgnoreCase("NO DATA")) {
				drTO.setSender(drq.getSender().getName().toString().split(",")[0].substring(3));
			} else {
				drTO.setSender(drq.getRecipient().getName().toString().toString().split(",")[0].substring(3));
			}
			if (!drTO.getSender().equals(
					rpcService.nodeIdentity().getLegalIdentity().getName().toString().split(",")[0].substring(3))) {
				gridList.add(drTO);
			}

		}
		return gridList;
	}

	@POST
	@Path("/detailedDataReq")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response detaildata(@FormDataParam("aadharNo") Long aadharNo,
			@FormDataParam("destination") String destination) throws ActiveMQException {
		Response response = null;
		String reqId = "REQ" + String.valueOf(System.currentTimeMillis());

		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		Party party = (rpcService.partyFromX500Name(new X500Name(destination)));
		try {
			rpcService.startFlowDynamic(DetailedDataReqFlow.Initiator.class, aadharNo, reqId, party);
			response = Response.status(Status.OK).build();
		} catch (Exception e) {
			response = Response.status(Status.BAD_REQUEST).build();
		}
		return response;
	}

	@POST
	@Path("/detailedDataApprove")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response detaildataApprove(@FormDataParam("aadharNo") Long aadharNo, @FormDataParam("reqID") String reqID,
			@FormDataParam("destination") String destination, @FormDataParam("approve") String approve)
			throws ActiveMQException {

		Response response = null;
		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		if (approve.equalsIgnoreCase("APPROVED")) {
			Party party = (rpcService.partyFromX500Name(new X500Name(destination)));
			try {
				rpcService.startFlowDynamic(DetailedDataRespFlow.Initiator.class, aadharNo, reqID, party);
				response = Response.status(Status.OK).build();
			} catch (Exception e) {
				response = Response.status(Status.BAD_REQUEST).build();
			}
		} else {
			try {
				rpcService.startFlowDynamic(DetailDataRejectFlow.Initiator.class, reqID);
				response = Response.status(Status.OK).build();
			} catch (Exception e) {
				response = Response.status(Status.BAD_REQUEST).build();
			}
		}

		return response;
	}

	@GET
	@Path("peers")
	@Produces(MediaType.APPLICATION_JSON)
	public Map<String, String> getPeers() throws ActiveMQException {
		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		final String notaryName = "CN=Controller,O=R3,OU=corda,L=London,C=UK";
		final String consortiumName = "CN=Consortium,O=ABC,L=Mumbai,C=IND";
		X500Name myLegalName = rpcService.nodeIdentity().getLegalIdentity().getName();
		Pair<List<NodeInfo>, Observable<NetworkMapCache.MapChange>> nodeInfo = rpcService.networkMapUpdates();
		notUsed(nodeInfo.getSecond());
		Map<String, String> nodeMap = new HashMap<>();
		List<String> nodeList = new ArrayList<>();
		/*
		 * return ImmutableMap.of( "peers", nodeInfo.getFirst() .stream()
		 * .map(node -> node.getLegalIdentity().getName()) .filter(name ->
		 * !name.equals(myLegalName) && !(name.toString().equals(notaryName))
		 * &&!(name.toString().equals(consortiumName))) .collect(toList()));
		 */
		nodeList.addAll(nodeInfo.getFirst().stream().map(node -> node.getLegalIdentity().getName().toString())
				.filter(name -> !(name.toString().equals(myLegalName.toString()))
						&& !(name.toString().equals(notaryName)) && !(name.toString().equals(consortiumName)))
				.collect(toList()));
		for (String fullname : nodeList) {
			nodeMap.put(fullname.split(",")[0].substring(3), fullname);
		}
		return nodeMap;
	}

	/*
	 * @GET
	 * 
	 * @Path("/deathNotify") public void sendNotification() throws
	 * ActiveMQException{
	 * 
	 * CordaRPCOps rpcService =
	 * cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
	 * rpcService.startFlowDynamic(DeathClaimNotificationFlow.Initiator.class,
	 * Long.valueOf("111189762134"));
	 * 
	 * }
	 */

	@GET
	@Path("/deathNotification/detail")
	@Produces(MediaType.APPLICATION_JSON)
	public List<NotificationTO> getDeathNotificationDetail() throws ActiveMQException {

		List<NotificationTO> notificationList = new ArrayList<>();
		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		Party me = rpcService.nodeIdentity().getLegalIdentity();

		rpcService.vaultQuery(NotificationState.class).getStates().forEach(stateRef -> {
			if (!me.equals(stateRef.getState().getData().getNotifier())) {
				notificationList.add(new NotificationTO(stateRef.getState().getData().getAadharNo(),
						stateRef.getState().getData().getDeathClaimRaiseDate().toString()));
			}
		});
		return notificationList;
	}

	@GET
	@Path("/dashboard/detail")
	@Produces(MediaType.APPLICATION_JSON)
	public List<DashBoardTO> getDashBoardDetail() throws ActiveMQException {

		List<DashBoardTO> dashBoardValueList = new ArrayList<>();
		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		List<PointState> pointStateList = rpcService.vaultQuery(PointState.class).getStates().stream()
				.map(sf -> sf.getState().getData()).collect(toList());
		final DashBoardTO consDashBoardTO = new DashBoardTO();
		pointStateList.forEach(ptSt -> {
			String memberName = ptSt.getAccountHolder().getName().getRDNs(BCStyle.CN)[0].getTypesAndValues()[0]
					.getValue().toString();
			if ("Consortium".equalsIgnoreCase(memberName)) {
				consDashBoardTO.setMemberName(memberName);
				consDashBoardTO.setNoOfRequestMade(ptSt.getNoOfRequestMade());
				consDashBoardTO.setNoOfResponseMade(ptSt.getNoOfResponseMade());
				consDashBoardTO.setNoOfDataContribute(ptSt.getNoOfDataContribute());
				consDashBoardTO.setPointsEarned(ptSt.getPointsEarned());
				consDashBoardTO.setPointsDue(ptSt.getPointsDue());
				consDashBoardTO.setNetPointBalance(ptSt.getNetPointBalance());
			} else {
				DashBoardTO dashBoardTO = new DashBoardTO();
				dashBoardTO.setMemberName(memberName);
				dashBoardTO.setNoOfRequestMade(ptSt.getNoOfRequestMade());
				dashBoardTO.setNoOfResponseMade(ptSt.getNoOfResponseMade());
				dashBoardTO.setNoOfDataContribute(ptSt.getNoOfDataContribute());
				dashBoardTO.setPointsEarned(ptSt.getPointsEarned());
				dashBoardTO.setPointsDue(ptSt.getPointsDue());
				dashBoardTO.setNetPointBalance(ptSt.getNetPointBalance());
				dashBoardValueList.add(dashBoardTO);
			}

		});
		// add consortium if present, in the end of the list
		if (consDashBoardTO.getMemberName() != null)
			dashBoardValueList.add(consDashBoardTO);

		return dashBoardValueList;
	}

	@POST
	@Path("/consortium/audit")
	@Produces(MediaType.APPLICATION_JSON)
	public AggregatedData getAuditTrail(@FormDataParam("aadharNo") Long aadharNo, @FormDataParam("to") String toD,
			@FormDataParam("from") String fromD) throws ActiveMQException, InterruptedException, ExecutionException {

		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
		AggregatedData ad = rpcService.startFlowDynamic(ConsortiumAggregateQueryDataFlow.getAggregatedView.class,
				aadharNo, Timestamp.valueOf(toD.concat(" 23:59:59.999")).toLocalDateTime(),
				Timestamp.valueOf(fromD.concat(" 00:00:00")).toLocalDateTime()).getReturnValue().get();

		return ad;
	}

	@GET
	@Path("/dashboard/allreq")
	@Produces(MediaType.APPLICATION_JSON)
	public List<AllRequestTO> getAllRequest() throws ActiveMQException, InterruptedException, ExecutionException {

		List<DetailedDataReqState> detailDataGrid = new ArrayList<DetailedDataReqState>();
		List<AllRequestTO> allreqList = new ArrayList<>();
		// detailDataGrid=rpcService.vaultQuery(DetailedDataReqState.class).getStates()
		CordaRPCOps rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);

		detailDataGrid = (List<DetailedDataReqState>) rpcService
				.startFlowDynamic(ApplicationDaoCallFlow.detailDataDisplay.class).getReturnValue().get();
		for (DetailedDataReqState dr : detailDataGrid) {
			AllRequestTO aTO = new AllRequestTO();
			aTO.setReqID(dr.getReqId());
			aTO.setAadharNo(dr.getAadharNo());
			aTO.setStatus(dr.getStatus());
			if (dr.getStatus().equalsIgnoreCase("COMPLETED") || dr.getStatus().equalsIgnoreCase("REJECTED")
					|| dr.getStatus().equalsIgnoreCase("NO DATA")) {
				aTO.setSource(dr.getRecipient().toString().split(",")[0].substring(3));
				Map<String, String> nameMap = new HashMap<>();
				nameMap.put(aTO.getSource(), dr.getRecipient().toString());
				aTO.setPartyName(nameMap);
				aTO.setApprvFlag(Boolean.TRUE);
			} else {
				aTO.setSource(dr.getSender().toString().toString().split(",")[0].substring(3));
				Map<String, String> nameMap = new HashMap<>();
				nameMap.put(aTO.getSource(), dr.getSender().toString());
				aTO.setPartyName(nameMap);
				aTO.setApprvFlag(Boolean.FALSE);
			}
			aTO.setQueryType("DETAILED");
			if (!aTO.getSource().equals(
					rpcService.nodeIdentity().getLegalIdentity().getName().toString().split(",")[0].substring(3))) {
				allreqList.add(aTO);
			}

		}

		return allreqList;

	}

	/*
	 * @POST
	 * 
	 * @Path("/detailedDataReject")
	 * 
	 * @Consumes(MediaType.MULTIPART_FORM_DATA) public Response
	 * detaildataReject(@FormDataParam("reqID")String reqID) throws
	 * ActiveMQException {
	 * 
	 * Response response =null; CordaRPCOps rpcService =
	 * cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
	 * 
	 * try{
	 * rpcService.startFlowDynamic(DetailDataRejectFlow.Initiator.class,reqID);
	 * response = Response.status(Status.OK).build(); } catch(Exception e) {
	 * response = Response.status(Status.BAD_REQUEST).build(); } return
	 * response; }
	 */

	public String nodeName() throws ActiveMQException {
		try {
			rpcService = cordaRPCService.getRPCServiceByNode(nodeRpcHostAndPort);
			nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		} catch (ActiveMQException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return nodeName;
	}



}
