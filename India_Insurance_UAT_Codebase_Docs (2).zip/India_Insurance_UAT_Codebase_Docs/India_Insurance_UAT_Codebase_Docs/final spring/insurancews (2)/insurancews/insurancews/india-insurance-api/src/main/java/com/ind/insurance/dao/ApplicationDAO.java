package com.ind.insurance.dao;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.ext.Provider;

import org.apache.activemq.artemis.api.core.ActiveMQException;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.example.connection.DatabaseConnection;
import com.example.dao.ApplicationDao;
import com.ind.insurance.service.CordaRPCService;

import net.corda.core.messaging.CordaRPCOps;

import com.ind.insurance.Application;
import com.ind.insurance.object.ErrorDTO;
import com.ind.insurance.object.GridDTO;

@Component
//@SpringApplicationConfiguration(classes = Application.class) 
public class ApplicationDAO {
	@Autowired
	private CordaRPCService cordaRPCService;
	@Value(value = "${node.insurer.rpc.hostport}")
	private String nodeRpcHostAndPort;
	@Value(value = "${db.connection}")
	private String nodeDbConnection;
	


	//@Value(value = "${node.insurer1.rpc.hostport}")
	//private String nodeINS1RpcHostAndPort="localhost:2010";

	//@Value(value = "${node.insurer2.rpc.hostport}")
	//private String nodeINS2RpcHostAndPort="localhost:2014";
	//@Value(value = "${db.connection}")
	//private String nodeDbConnection="jdbc:h2:tcp://localhost:2016/node";


	public void createGridTables(CordaRPCService cRpc) throws ActiveMQException, ClassNotFoundException, SQLException {

		CordaRPCOps rpcService = cRpc.getRPCServiceByNode(nodeRpcHostAndPort);
		String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		Statement createTable;
		Statement createSatTable;
		Connection dbConn = null;
		try {
			// create grid details table
			// CHANGE PORT TO DYNAMIC
			String port = DatabaseConnection.INSTANCE.getPort(nodeName);
			try {
				Class.forName("org.h2.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw e;
			}
			String dbConnectionString = nodeDbConnection;
			dbConn = DriverManager.getConnection(dbConnectionString, "sa", "");
			createTable = dbConn.createStatement();
			String sqlCreate = "CREATE TABLE GRID_DETAILS " + "(req_id VARCHAR(255) PRIMARY KEY, "
					+ " filename VARCHAR(255), " + " sys_status VARCHAR(255), " + " status VARCHAR(255),"
					+ " filetype VARCHAR(255)," + " upload_date VARCHAR(255)," + " file BLOB)";

			createTable.executeUpdate(sqlCreate);
			createSatTable = dbConn.createStatement();
			// create error details table;
			String sqlSatCreate = "CREATE TABLE GRID_ERROR " + "(req_id VARCHAR(255), " + " row_num INTEGER, "
					+ " col_num INTEGER, " + " field_name VARCHAR(255), " + " error_details VARCHAR(255))";
			createSatTable.executeUpdate(sqlSatCreate);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw e;
		} finally {
			// finally block used to close resources
			try {
				if(dbConn!=null)
				{
					dbConn.close();
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw e;
			}

		}

	}

	public void insertGrid(CordaRPCService cRpc, String reqID, String fileName, String sys_stat, String stat,
			String upDate, String filetype, InputStream file) throws ActiveMQException, ClassNotFoundException, SQLException {
		//CordaRPCOps rpcService = cRpc.getRPCServiceByNode(nodeINS2RpcHostAndPort);
		//String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		PreparedStatement createTable=null;
		//Statement createSatTable;
		String sqlCreate;
		Connection dbConn = null;
		try {
			// create grid details table
			// CHANGE PORT TO DYNAMIC
			//String port = DatabaseConnection.INSTANCE.getPort(nodeName);
			try {
				Class.forName("org.h2.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw e;
			}
			String dbConnectionString = nodeDbConnection;
			dbConn = DriverManager.getConnection(dbConnectionString, "sa", "");
			 sqlCreate = "INSERT INTO GRID_DETAILS " + "VALUES ('" + reqID + "','" + fileName + "','" + sys_stat
					+ "','" + stat + "','" + filetype + "','" + upDate + "'," + "?)";
			createTable = dbConn.prepareStatement(sqlCreate);
			createTable.setBinaryStream(1, file);

			createTable.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw e;
		} finally {
			// finally block used to close resources
			try {
				if(createTable!=null)
				{
					createTable.close();
				}
				if(dbConn!=null)
				{
					dbConn.close();
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw e;
			}

		}

	}

	public void updateGrid(CordaRPCService cRpc, String reqID) throws ActiveMQException, ClassNotFoundException, SQLException {
		//CordaRPCOps rpcService = cRpc.getRPCServiceByNode(nodeINS2RpcHostAndPort);
		//String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		Statement updateTable=null;
		Connection dbConn = null;
		try {
			// create grid details table
			// CHANGE PORT TO DYNAMIC
			//String port = DatabaseConnection.INSTANCE.getPort(nodeName);
			try {
				Class.forName("org.h2.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw e;
			}
			String dbConnectionString = nodeDbConnection;
			dbConn = DriverManager.getConnection(dbConnectionString, "sa", "");
			String sqlUpdate = "UPDATE GRID_DETAILS SET status ='ERROR',sys_status='FORMAT_ERROR' WHERE req_id ='"
					+ reqID + "'";
			updateTable = dbConn.createStatement();

			updateTable.executeUpdate(sqlUpdate);
			/*
			 * createSatTable = dbConn.createStatement(); // create error
			 * details table; String sqlSatCreate = "CREATE TABLE GRID_ERROR " +
			 * "(req_id INTEGER PRIMARY KEY, " + " row_num INTEGER, " +
			 * " col_num INTEGER, " + " field_name VARCHAR(255), " +
			 * " error_details VARCHAR(255))";
			 * createSatTable.executeUpdate(sqlSatCreate);
			 */

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw e;
		} finally {
			// finally block used to close resources
			try {
				if(updateTable!=null)
				{
					updateTable.close();
				}
				if(dbConn!=null)
				{
					dbConn.close();
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw e;
			}

		}

	}

	public void updateErrorGrid(CordaRPCService cRpc, ErrorDTO err) throws ActiveMQException, ClassNotFoundException, SQLException {
		//CordaRPCOps rpcService = cRpc.getRPCServiceByNode(nodeINS2RpcHostAndPort);
		//String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		Statement createTable=null;
		//Statement createSatTable;
		Connection dbConn = null;
		try {
			// create grid details table
			// CHANGE PORT TO DYNAMIC
			//String port = DatabaseConnection.INSTANCE.getPort(nodeName);
			try {
				Class.forName("org.h2.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw e;
			}
			String dbConnectionString = nodeDbConnection;
			dbConn = DriverManager.getConnection(dbConnectionString, "sa", "");

			String reqID = err.getRequestID();
			Integer rowID = err.getRowNum();
			Integer colID = err.getColNum();
			String fieldName = err.getFieldName();
			String error = err.getErrorDetails();

			String sqlCreate = "INSERT INTO GRID_ERROR " + "VALUES ('" + reqID + "'," + rowID + "," + colID + ",'"
					+ fieldName + "','" + error + "')";
			createTable = dbConn.createStatement();

			createTable.executeUpdate(sqlCreate);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw e;
		} finally {
			// finally block used to close resources
			try {
				if(createTable!=null)
				{
					createTable.close();
				}
				
				if(dbConn!=null)
				{
					dbConn.close();
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw e;
			}

		}

	}

	public List<GridDTO> getGridError(CordaRPCService cRpc) throws ActiveMQException, ClassNotFoundException, SQLException {
		//CordaRPCOps rpcService = cRpc.getRPCServiceByNode(nodeINS2RpcHostAndPort);
		//String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		Statement createTable=null;
		PreparedStatement errStmnt=null;
		Connection dbConn = null;
		List<GridDTO> gridList = null;
		ResultSet errRs=null;
		ResultSet rs=null;
		try {
			// create grid details table
			// CHANGE PORT TO DYNAMIC
			//String port = "2016";
			try {
				Class.forName("org.h2.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw e;
			}
			String dbConnectionString = nodeDbConnection;
			dbConn = DriverManager.getConnection(dbConnectionString, "sa", "");

			String sqlCreate = "SELECT REQ_ID,FILENAME,STATUS,UPLOAD_DATE from GRID_DETAILS";
			createTable = dbConn.createStatement();

			 rs = createTable.executeQuery(sqlCreate);
			gridList = new ArrayList<GridDTO>();
			while (rs.next()) {
				GridDTO gridTO = new GridDTO();
				gridTO.setRequestId(rs.getString("REQ_ID"));
				gridTO.setFileName(rs.getString("FILENAME"));
				gridTO.setStatus(rs.getString("STATUS"));
				gridTO.setUploadDate(rs.getString("UPLOAD_DATE"));
				gridList.add(gridTO);
			}

			String sqlErr = "SELECT ROW_NUM,FIELD_NAME,ERROR_DETAILS from GRID_ERROR where REQ_ID=?";
			errStmnt = dbConn.prepareStatement(sqlErr);
			for (GridDTO grdTO : gridList) {
				List<ErrorDTO> reqErr = new ArrayList<ErrorDTO>();
				errStmnt.setString(1, grdTO.getRequestId());
				 errRs = errStmnt.executeQuery();
				while (errRs.next()) {
					ErrorDTO err = new ErrorDTO();
					err.setRowNum(errRs.getInt("ROW_NUM"));
					err.setFieldName(errRs.getString("FIELD_NAME"));
					err.setErrorDetails(errRs.getString("ERROR_DETAILS"));
					reqErr.add(err);
				}
				grdTO.setErrTO(reqErr);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw e;
		} finally {
			// finally block used to close resources
			try {
				if(createTable!=null)
				{
					createTable.close();	
				}
				if(errStmnt!=null)
				{
					errStmnt.close();
				}
				if(rs!=null)
				{
					rs.close();	
				}
				if(errRs!=null)
				{
					errRs.close();
				}
				if(dbConn!=null)
				{
					dbConn.close();
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw e;
			}

		}

		return gridList;

	}

	public void insertHolderStg(CordaRPCService crpcService, String request_id, Long aadhar, String pan, char gender,
			String firstName, String middleName, String lastName, LocalDate dob, String address, String state,
			char nriStatus, String education, String employement, Integer pinCode, LocalDateTime now)
			throws ActiveMQException, ClassNotFoundException, SQLException {
		//CordaRPCOps rpcService = crpcService.getRPCServiceByNode(nodeINS2RpcHostAndPort);
		//String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		Statement insertHolder=null;
		Connection dbConn = null;
		try {
			// create grid details table
			// CHANGE PORT TO DYNAMIC
			//String port = DatabaseConnection.INSTANCE.getPort(nodeName);
			try {
				Class.forName("org.h2.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw e;
			}
			String dbConnectionString = nodeDbConnection;
			dbConn = DriverManager.getConnection(dbConnectionString, "sa", "");

			String sqlCreate = "INSERT INTO POLICY_HOLDER_STG " + "VALUES ('" + request_id + "'," + aadhar + ",'" + pan
					+ "','" + address + "','" + dob + "','" + education + "','" + employement + "','" + firstName
					+ "','" + gender + "','" + lastName + "','" + middleName + "','" + nriStatus + "','" + pinCode
					+ "','" + state + "','" + now + "')";
			insertHolder = dbConn.createStatement();

			insertHolder.executeUpdate(sqlCreate);

		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			throw e;
		} finally {
			// finally block used to close resources
			try {
				if(insertHolder!=null)
				{
					insertHolder.close();	
				}
				if(dbConn!=null)
				{
					dbConn.close();
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw e;
			}

		}

	}

	public void deleteStg(CordaRPCService crpc, String requestID, String fileType) throws ActiveMQException, SQLException, ClassNotFoundException {
		//CordaRPCOps rpcService = crpc.getRPCServiceByNode(nodeINS2RpcHostAndPort);
		//String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		Statement dltStg=null;
		String tableName = "";
		Connection dbConn = null;
		try {
			// create grid details table
			// CHANGE PORT TO DYNAMIC
			//String port = DatabaseConnection.INSTANCE.getPort(nodeName);
			try {
				Class.forName("org.h2.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw e;
			}
			String dbConnectionString = nodeDbConnection;
			dbConn = DriverManager.getConnection(dbConnectionString, "sa", "");
			if (fileType.equalsIgnoreCase("POLICYHOLDER")) {

				tableName = "POLICY_HOLDER_STG";
			}

			else if (fileType.equalsIgnoreCase("POLICY")) {
				tableName = "POLICY_STG";
			} else {
				tableName = "CLAIM_STG";

			}

			String sqlDelete = "DELETE FROM " + tableName + " WHERE REQ_ID = " + "'" + requestID + "'";
			dltStg = dbConn.createStatement();

			dltStg.executeUpdate(sqlDelete);

		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			throw e;
		} finally {
			// finally block used to close resources
			try {
				dltStg.close();
				dbConn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw e;
			}

		}
	}

	public void insertPolicyStg(CordaRPCService crpcService, String reqID, Long aadhar, String nomineeName,
			String policyNum, LocalDate startDate, char policyStatus, Double premium, char productType,
			char renewalFreq, char source, Double sumAssured, String uinNo, String passport, LocalDateTime now)
			throws ActiveMQException, SQLException, ClassNotFoundException {
		//CordaRPCOps rpcService = crpcService.getRPCServiceByNode(nodeINS2RpcHostAndPort);
		//String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		Statement insertPolicy=null;
		Connection dbConn = null;
		try {
			// create grid details table
			// CHANGE PORT TO DYNAMIC
			//String port = DatabaseConnection.INSTANCE.getPort(nodeName);
			try {
				Class.forName("org.h2.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw e;
			}
			String dbConnectionString = nodeDbConnection;
			dbConn = DriverManager.getConnection(dbConnectionString, "sa", "");

			String sqlCreate = "INSERT INTO POLICY_STG " + "VALUES ('" + reqID + "'," + aadhar + ",'" + nomineeName
					+ "','" + policyNum + "','" + startDate + "','" + policyStatus + "'," + premium + ",'" + productType
					+ "','" + renewalFreq + "','" + source + "'," + sumAssured + ",'" + uinNo + "','" + passport + "','"
					+ now + "')";
			insertPolicy = dbConn.createStatement();

			insertPolicy.executeUpdate(sqlCreate);

		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			throw e;
		} finally {
			// finally block used to close resources
			try {
				insertPolicy.close();
				dbConn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw e;
			}

		}

	}

	public void insertClaimStg(CordaRPCService crpcService, String reqID, Long claimAadhar, LocalDate claimDate,
			String claimId, char claimStatus, char claimSubStatus, char claimType, char fraudStatus, String policyNum,
			LocalDateTime now) throws ActiveMQException, SQLException, ClassNotFoundException {
		//CordaRPCOps rpcService = crpcService.getRPCServiceByNode(nodeINS2RpcHostAndPort);
		//String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		Statement insertClaim=null;
		Connection dbConn = null;
		try {
			// create grid details table
			// CHANGE PORT TO DYNAMIC
			//String port = DatabaseConnection.INSTANCE.getPort(nodeName);
			try {
				Class.forName("org.h2.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw e;
			}
			String dbConnectionString = nodeDbConnection;
			dbConn = DriverManager.getConnection(dbConnectionString, "sa", "");

			String sqlCreate = "INSERT INTO CLAIM_STG " + "VALUES ('" + reqID + "'," + claimAadhar + ",'" + claimDate
					+ "','" + claimId + "','" + claimStatus + "','" + claimSubStatus + "','" + claimType + "','"
					+ fraudStatus + "','" + policyNum + "','" + now + "')";
			insertClaim = dbConn.createStatement();

			insertClaim.executeUpdate(sqlCreate);

		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			throw e;
		} finally {
			// finally block used to close resources
			try {
				insertClaim.close();
				dbConn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw e;
			}

		}

	}

	public ResponseBuilder downloadexcel(CordaRPCService crpcService, String reqId) throws ActiveMQException, IOException, SQLException, ClassNotFoundException {
		//CordaRPCOps rpcService = crpcService.getRPCServiceByNode(nodeINS2RpcHostAndPort);
		//String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		Statement excelDwnload=null;
		Connection dbConn = null;
		InputStream inputExcel = null;
		OutputStream outstream = null;
		ResponseBuilder rspreturn=null;
		ResultSet rs=null;
		try {
			// create grid details table
			// CHANGE PORT TO DYNAMIC
			//String port = DatabaseConnection.INSTANCE.getPort(nodeName);
			try {
				Class.forName("org.h2.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw e;
			}
			String dbConnectionString = nodeDbConnection;
			dbConn = DriverManager.getConnection(dbConnectionString, "sa", "");

			String sqlCreate = "SELECT FILE FROM GRID_DETAILS WHERE REQ_ID='" + reqId + "'";
			excelDwnload = dbConn.createStatement();

			 rs = excelDwnload.executeQuery(sqlCreate);
			while (rs.next()) {
				Blob rsBlob = rs.getBlob(1);
				inputExcel = rsBlob.getBinaryStream();
			}
			InputStream finalStream = new ByteArrayInputStream(IOUtils.toByteArray(inputExcel));
			//rs.close();
			//dbConn.close();
		
			 rspreturn = Response.ok((Object) finalStream); 
		
			
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw e;
		} finally {
			// finally block used to close resources
			try {
				if(rs!=null)
				{
					rs.close();	
				}
				if(excelDwnload!=null)
				{
					excelDwnload.close();
				}
				
				dbConn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw e;
			}

		}

		return rspreturn;
	}

	public Boolean validateLogin(CordaRPCService crpcService,String userName, String password, String ip) throws ActiveMQException, SQLException, ClassNotFoundException {

		//CordaRPCOps rpcService = crpcService.getRPCServiceByNode(nodeINS2RpcHostAndPort);
		//String nodeName = rpcService.nodeIdentity().getLegalIdentity().getName().toString();
		Statement createTable=null;
		//Statement createSatTable;
		Statement insertIP;
		Boolean isValid=Boolean.FALSE;
		Connection dbConn = null;
		ResultSet rs=null;
		try {
			// create grid details table
			// CHANGE PORT TO DYNAMIC
			//String port = DatabaseConnection.INSTANCE.getPort(nodeName);
			try {
				Class.forName("org.h2.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw e;
			}
			String dbConnectionString = nodeDbConnection;
			dbConn = DriverManager.getConnection(dbConnectionString, "sa", "");
			LocalDateTime now =LocalDateTime.now();

			String sqlIP = "INSERT INTO IP_DETAILS VALUES('"+userName+"','"+password+"','"+ip+"','"+now+"')";
			insertIP = dbConn.createStatement();

			insertIP.executeUpdate(sqlIP);

		

			String sqlCreate = "SELECT * FROM APP_LOGIN WHERE USERNAME='"+userName+"' AND PASSWORD='"+password+"'";
			createTable = dbConn.createStatement();

			 rs=createTable.executeQuery(sqlCreate);
			if(rs!=null&&rs.next())
			{
			isValid=Boolean.TRUE;	
			}
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw e;
		} finally {
			// finally block used to close resources
			try {
				if(rs!=null)
				{
					rs.close();
				}
				
				createTable.close();
				dbConn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw e;
			}

		}

	
		
		
		return isValid;
	}

}
