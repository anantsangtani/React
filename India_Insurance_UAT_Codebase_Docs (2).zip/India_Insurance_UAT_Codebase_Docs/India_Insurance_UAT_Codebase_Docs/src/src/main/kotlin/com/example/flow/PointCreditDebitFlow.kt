package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.contract.IOUContract
import com.example.contract.InsuranceContract
import com.example.state.IOUState
import com.example.state.PointState
import com.template.util.ApplicationConstants
import net.corda.core.contracts.*
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatedBy
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.flows.CollectSignaturesFlow
import net.corda.flows.FinalityFlow
import net.corda.flows.SignTransactionFlow

object PointCreditDebitFlow{

    @InitiatingFlow
    @StartableByRPC
    class Initiator(val inputIOUTxnId : String) : FlowLogic<SignedTransaction>() {
        /**
         * The progress tracker checkpoints each stage of the flow and outputs the specified messages when each
         * checkpoint is reached in the code. See the 'progressTracker.currentStep' expressions within the call() function.
         */
        companion object {
            object GENERATING_TRANSACTION : ProgressTracker.Step("Generating transaction based on new IOU.")
            object VERIFYING_TRANSACTION : ProgressTracker.Step("Verifying contract constraints.")
            object SIGNING_TRANSACTION : ProgressTracker.Step("Signing transaction with our private key.")
            object GATHERING_SIGS : ProgressTracker.Step("Gathering the counterparty's signature.") {
                override fun childProgressTracker() = CollectSignaturesFlow.tracker()
            }

            object FINALISING_TRANSACTION : ProgressTracker.Step("Obtaining notary signature and recording transaction.") {
                override fun childProgressTracker() = FinalityFlow.tracker()
            }

            fun tracker() = ProgressTracker(
                    GENERATING_TRANSACTION,
                    VERIFYING_TRANSACTION,
                    SIGNING_TRANSACTION,
                    GATHERING_SIGS,
                    FINALISING_TRANSACTION
            )
        }

        override val progressTracker = tracker()

        /**
         * The flow logic is encapsulated within the call() method.
         */
        @Suspendable
        override fun call(): SignedTransaction {
            val detailQueryCount : Long = 1
            val pointToCredit : Long = ApplicationConstants.DETAIL_QRY_CREDIT_POINT
            val pointToDebit : Long = ApplicationConstants.DETAIL_QRY_DEBIT_POINT
            // Obtain a reference to the notary we want to use.
            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity

            // Stage 1.
            progressTracker.currentStep = GENERATING_TRANSACTION
            // Generate an unsigned transaction.

            val regulatory =serviceHub.myInfo.legalIdentity
            //fetch unconsumed IOUState from vault based on txn id
            val iouStateRef = getUnconsumedIOUState(inputIOUTxnId)
            val iouState =  iouStateRef.state.data
            //prepare participant list
            val creditParty = iouState.sender
            val debitParty = iouState.recipient
            val participantList = mutableListOf<Party>()
            participantList.add(regulatory)
            participantList.add(creditParty)
            participantList.add(debitParty)

            val txBuilder = TransactionBuilder(TransactionType.General, notary)
            val txCommand = Command(InsuranceContract.Commands.ManagePoints(),participantList.map { it.owningKey } )
            val txCommand2 = Command(IOUContract.Commands.Redeem(),participantList.map { it.owningKey } )
            txBuilder.addCommand(txCommand)
            txBuilder.addCommand(txCommand2)

            // add IOU as input state
            txBuilder.addInputState(iouStateRef)

            //add previous point state of credit party as input state
            var unconsumedPointStateRef = getUnconsumedPointState(creditParty)
            txBuilder.addInputState(unconsumedPointStateRef)
            //update the point value in point state of credit party and add as output state
            val prevPointState = unconsumedPointStateRef.state.data
            val prevNoOfResponseMade = prevPointState.noOfResponseMade
            val prevPointsEarned = prevPointState.pointsEarned
            val updatedResponseMadeCount = prevNoOfResponseMade!!.plus(detailQueryCount)
            val updatedPointsEarnedCount = prevPointsEarned!!.plus(pointToCredit)
            val newPointState = prevPointState.copy(noOfResponseMade = updatedResponseMadeCount
                    ,pointsEarned = updatedPointsEarnedCount,netPointBalance = prevPointState.netPointBalance!!.plus(pointToCredit) )
            txBuilder.addOutputState(newPointState)

            //add previous point state of debit party as input state
            var unconsumedPointStateRef2 = getUnconsumedPointState(debitParty)
            txBuilder.addInputState(unconsumedPointStateRef2)
            //update the point value in point state of debit party and add as output state
            val prevPointState2 = unconsumedPointStateRef2.state.data
            val prevNoOfReqMade = prevPointState2.noOfRequestMade
            val prevPointsDue = prevPointState2.pointsDue
            val newPointState2 = prevPointState2.copy(noOfRequestMade = prevNoOfReqMade!!.plus(detailQueryCount),
                    pointsDue = prevPointsDue!!.minus(pointToDebit),netPointBalance = prevPointState2.netPointBalance!!.minus(pointToDebit))
            txBuilder.addOutputState(newPointState2)

            // Stage 2.
            progressTracker.currentStep = VERIFYING_TRANSACTION
            // Verify that the transaction is valid.
            txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()

            // Stage 3.
            progressTracker.currentStep = SIGNING_TRANSACTION
            // Sign the transaction.
            val partSignedTx = serviceHub.signInitialTransaction(txBuilder)

            // Stage 4.
            progressTracker.currentStep = GATHERING_SIGS
            // Send the state to the counterparty, and receive it back with their signature.

            val fullySignedTx = subFlow(CollectSignaturesFlow(partSignedTx, GATHERING_SIGS.childProgressTracker()))

            // Stage 5.
            progressTracker.currentStep = FINALISING_TRANSACTION
            // Notarise and record the transaction in both parties' vaults.
            return subFlow(FinalityFlow(fullySignedTx,FINALISING_TRANSACTION.childProgressTracker())).single()
        }

        private fun getUnconsumedIOUState(inputTxnId : String): StateAndRef<IOUState> {

            val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
            val iouStateRef = serviceHub.vaultQueryService.queryBy<IOUState>(qryCriteriaUnconsumed).states.
                    filter { it.ref.txhash.toString().equals(inputTxnId) }.single()

            return  iouStateRef
        }
        private fun getUnconsumedPointState(owner: Party): StateAndRef<PointState> {

            /*val pointState1 = serviceHub.vaultQueryService.queryBy(PointState::class.java).states.
                     filter { it.state.data.accountHolder.equals(owner) }.single()*/
            val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
            val pointState = serviceHub.vaultQueryService.queryBy<PointState>(qryCriteriaUnconsumed).states.filter { it.state.data.accountHolder.equals(owner) }.single()

            return  pointState
        }
    }

    @InitiatedBy(Initiator::class)
    class Acceptor(val otherParty: Party) : FlowLogic<SignedTransaction>() {
        @Suspendable
        override fun call(): SignedTransaction {
            val signTransactionFlow = object : SignTransactionFlow(otherParty) {
                override fun checkTransaction(stx: SignedTransaction){

                }
            }

            return subFlow(signTransactionFlow)
        }
    }
}