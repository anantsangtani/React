package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.contract.InsuranceContract
import com.example.model.PolicyHolder
import com.example.state.PolicyHolderDetailState
import net.corda.core.contracts.Attachment
import net.corda.core.contracts.Command
import net.corda.core.contracts.TransactionType
import net.corda.core.crypto.SecureHash
import net.corda.core.crypto.commonName
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatedBy
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.node.services.vault.and
import net.corda.core.node.services.vault.builder
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.unwrap
import net.corda.flows.FinalityFlow
import net.corda.flows.ResolveTransactionsFlow
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.jetbrains.exposed.sql.transactions.TransactionManager
import java.io.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object PreValidationResponseFlow{

    @InitiatingFlow
    @StartableByRPC
    class Initiator(val otherParty: Party,val txnHash : SecureHash,val reqId:String,val preValidationFileName :String) : FlowLogic<Unit>() {
        @Suspendable
        override fun call(){

            //resolve the transaction
            val ledgerTransactions = subFlow(ResolveTransactionsFlow(setOf(txnHash),otherParty))
            require(ledgerTransactions.size == 1 && ledgerTransactions.get(0).attachments.size == 1)
            val attachment = ledgerTransactions.get(0).attachments.get(0)
            val generatedFileName= generateResponseFile(attachment)

            //prepare zip and import as attachment
            val outputFileHash :SecureHash = getOutputFileHash(generatedFileName)

            //create transaction and return txn hash
            val responseTxnHash = generateTransaction(outputFileHash)

          //  val preValidationObj = PreValidationRequest(reqId,null,null,null,null,null,generatedFileName,null)
            send(otherParty,Pair(responseTxnHash,reqId))
        }

        private fun generateResponseFile(attachment: Attachment): String {
            val myCommonName = serviceHub.myInfo.legalIdentity.name.commonName
            val outputTo = FileOutputStream("attachments\\"+preValidationFileName)
            attachment.extractFile(preValidationFileName,outputTo)

            val inputWorkBook = XSSFWorkbook(File("attachments\\"+preValidationFileName))

            //prepare output workbook
            val outputWorkBook = XSSFWorkbook()
            val outputSheet = outputWorkBook.createSheet()
            var outputRowNum = 0
            //set header
            val headerRow= outputSheet.createRow(outputRowNum++)
            headerRow.createCell(0).setCellValue("AADHAR_NO")
            headerRow.createCell(1).setCellValue("GENDER CONSISTENCY")
            headerRow.createCell(2).setCellValue("DOB CONSISTENCY")
            headerRow.createCell(3).setCellValue("NRI STATUS CONSISTENCY")
            headerRow.createCell(4).setCellValue("DATA EXIST")


            val itr = inputWorkBook.getSheetAt(0).iterator()
            while(itr.hasNext()){
                val currRow = itr.next();
                if(currRow.rowNum == 0)
                    continue

                val aadharNo = currRow.getCell(0).toString()
                val gender = currRow.getCell(1).toString()
                val dob = currRow.getCell(2).toString()
                val nriSatus = currRow.getCell(3).toString()
                //populate workbook
                //query vault by aadhar no
                val policyHolder = getVaultStateByAadhar(aadharNo.toLong())
                val row= outputSheet.createRow(outputRowNum++)
                if(policyHolder != null){
                    //data exists
                    var genderConsistency = if(gender.elementAt(0).equals(policyHolder.gender)) "Y" else "N"
                    val inputDOB = LocalDate.parse(dob, DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                    var dobConsistency = if(inputDOB.isEqual(policyHolder.dob)) "Y" else "N"
                    var nriStatusConsistency = if(nriSatus.elementAt(0).equals(policyHolder.nriStatus)) "Y" else "N"

                    row.createCell(0).setCellValue(aadharNo)
                    row.createCell(1).setCellValue(genderConsistency)
                    row.createCell(2).setCellValue(dobConsistency)
                    row.createCell(3).setCellValue(nriStatusConsistency)
                    row.createCell(4).setCellValue("Y")
                }else{
                    //data doesn't exist
                    row.createCell(0).setCellValue(aadharNo)
                    row.createCell(4).setCellValue("N")
                }
            }
            val generatedFileName =  reqId+"_"+myCommonName+".xlsx"
            val fout = FileOutputStream("attachments\\"+generatedFileName)
            outputWorkBook.write(fout)
            fout.close()

            return generatedFileName
        }

        private fun  generateTransaction(outputFileHash: SecureHash): SecureHash {
            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity
            val me =serviceHub.myInfo.legalIdentity
            // Stage 1.
            // Generate an unsigned transaction.
            val txBuilder = TransactionBuilder(TransactionType.General, notary)
            txBuilder.addAttachment(outputFileHash)

            val txCommand = Command(InsuranceContract.Commands.ResponsePreValidationQuery(), listOf(me).map { it.owningKey } )
            txBuilder.addCommand(txCommand)
            // Stage 2.
            // Verify that the transaction is valid.
            txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()

            // Stage 3.
            // Sign the transaction.
            val partSignedTx = serviceHub.signInitialTransaction(txBuilder)
            // Stage 5.
            // Notarise and record the transaction in both parties' vaults.
            val signedTxn =  subFlow(FinalityFlow(partSignedTx, PreValidationQueryFlow.Initiator.Companion.FINALISING_TRANSACTION.childProgressTracker())).single()

            return signedTxn.tx.id
        }

        fun  getOutputFileHash(generatedFileName: String): SecureHash {

            val bout = ByteArrayOutputStream()
            val zipOutputStream = ZipOutputStream(bout)
            zipOutputStream.putNextEntry(ZipEntry(generatedFileName))
            val fileInputStream = FileInputStream("attachments\\"+generatedFileName)
            val buffer = ByteArray(4096)
            while (true) {
                val numberOfBytesRead = fileInputStream.read(buffer)
                if (numberOfBytesRead != -1) {
                    zipOutputStream.write(buffer, 0, numberOfBytesRead)
                } else {
                    break
                }
            }
            fileInputStream.close()
            zipOutputStream.closeEntry()
            zipOutputStream.close()

            val byteInputStrm = ByteArrayInputStream(bout.toByteArray())
            val docHash = serviceHub.storageService.attachments.importAttachment(byteInputStrm)
            bout.close()
            byteInputStrm.close()

            return docHash
        }

        private fun getVaultStateByAadhar(aadharNo: Long): PolicyHolder? {

            try {
                val expression1 = builder { PolicyHolderDetailState.PolicyHolderDetailSchemaV1.PolicyHolderEntity::aadhar.equal(aadharNo) }
                val qryCriteriaAadhar = QueryCriteria.VaultCustomQueryCriteria(expression1)
                val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)

                val vaultState = serviceHub.vaultQueryService.queryBy<PolicyHolderDetailState>(qryCriteriaAadhar.and(qryCriteriaUnconsumed)).states.singleOrNull()
                return vaultState?.state?.data?.policyHolder;
            }
            catch(e : Exception){
                System.out.print(e.printStackTrace());
                throw e ;
            }
        }

    }

    @InitiatedBy(Initiator::class)
    class Acceptor(val otherParty: Party) : FlowLogic<Unit>() {
        @Suspendable
        override fun call() {

            receive<Pair<SecureHash,String>>(otherParty).unwrap {
                System.out.println("********** inside receive of the PreValidationResponseFlow ************* when I am :"+serviceHub.myInfo.legalIdentity)

                val txnHash = it.first
                val preValidationReqId = it.second
                //resolve the transaction
                val ledgerTransactions = subFlow(ResolveTransactionsFlow(setOf(txnHash),otherParty))
                require(ledgerTransactions.size == 1 && ledgerTransactions.get(0).attachments.size == 1)
                val attachment = ledgerTransactions.get(0).attachments.get(0)

                //to be removed
                /*val outputTo = FileOutputStream("attachments\\"+it.second)
                attachment.extractFile(it.second.downloadFileName!!,outputTo)*/
                //update request status
                val downloadFileName = preValidationReqId+"_"+otherParty.name.commonName+".xlsx"
                updatePreValidationRequestStatus(preValidationReqId,downloadFileName,attachment.id.toString())
            }
        }

        private fun  updatePreValidationRequestStatus(preValidationReqId: String,downloadFileName:String,downloadDocHash :String) {
            val qry :String = "update PRE_VALIDATION_REQUEST_DETAIL set DOWNLOAD_FILENAME =? , DOWNLOAD_FILEHASH = ? , STATUS =?  where REQ_ID =?"

            val dbTxn = TransactionManager.Companion.current()
            val con = dbTxn.connection

            val ps = con.prepareStatement(qry)
            ps.setString(1,downloadFileName)
            ps.setString(2,downloadDocHash)
            ps.setString(3,"Closed")
            ps.setString(4,preValidationReqId)
            ps.executeUpdate()
            ps.close()
        }
    }

}