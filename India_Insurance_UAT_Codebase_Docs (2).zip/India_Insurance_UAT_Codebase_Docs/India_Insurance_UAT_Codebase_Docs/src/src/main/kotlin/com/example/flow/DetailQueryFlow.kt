package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import net.corda.core.contracts.ContractState
import net.corda.core.contracts.TransactionState
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatedBy
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.utilities.unwrap

object DetailQueryFlow{
    @InitiatingFlow
    @StartableByRPC
    class Initiator(val aadharNo : String,val otherParty : Party) : FlowLogic<Unit>() {
        override fun call(){
            System.out.println("********* inside detail query flow initiator ************")
            send(otherParty,aadharNo)
        }

    }

    @InitiatedBy(Initiator::class)
    class Acceptor(val otherParty: Party) : FlowLogic<Unit>() {
        @Suspendable
        override fun call() {

            receive<Pair<String,List<TransactionState<ContractState>>>>(otherParty).unwrap {
                System.out.println("********** inside receive of the RegulatoryIntimationFlow ************* when I am :"+serviceHub.myInfo.legalIdentity)
                System.out.println("!!!! received data :"+it.first+"----publish state count :"+it.second.size)

                // call aggregator flow with this txn
                //subFlow(AggregateFlow.Initiator(it.first,it.second))
            }
        }
    }

}