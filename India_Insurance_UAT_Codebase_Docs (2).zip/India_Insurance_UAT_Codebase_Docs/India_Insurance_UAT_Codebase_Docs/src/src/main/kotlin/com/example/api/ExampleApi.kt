package com.example.api



import com.example.flow.ClaimDetailStorageFlow
import com.example.flow.MyFlow.Initiator1
import com.example.flow.MyFlow2
import com.example.flow.MyFlow2.Initiator
import com.example.flow.PolicyDetailStorageFlow
import com.example.flow.PolicyHolderDetailStorageFlow
import com.example.model.Claim
import com.example.model.Policy
import com.example.model.PolicyHolder
import com.example.state.IOUState
import net.corda.client.rpc.notUsed
import net.corda.core.contracts.StateAndRef
import net.corda.core.getOrThrow
import net.corda.core.messaging.CordaRPCOps
import net.corda.core.messaging.startTrackedFlow
import net.corda.core.messaging.vaultQueryBy
import net.corda.core.utilities.loggerFor
import org.bouncycastle.asn1.x500.X500Name
import org.slf4j.Logger
import java.time.LocalDate
import java.time.LocalDateTime
import javax.ws.rs.*
import javax.ws.rs.core.MediaType
import javax.ws.rs.core.Response

val NOTARY_NAME = "CN=Controller,O=R3,OU=corda,L=London,C=UK"

// This API is accessible from /api/example. All paths specified below are relative to it.
@Path("example")
class ExampleApi(val services: CordaRPCOps) {
    private val myLegalName: X500Name = services.nodeIdentity().legalIdentity.name

    companion object {
        private val logger: Logger = loggerFor<ExampleApi>()
    }

    /**
     * Returns the node's name.
     */
    @GET
    @Path("me")
    @Produces(MediaType.APPLICATION_JSON)
    fun whoami() = mapOf("me" to myLegalName)

    /**
     * Returns all parties registered with the [NetworkMapService]. These names can be used to look up identities
     * using the [IdentityService].
     */
    @GET
    @Path("peers")
    @Produces(MediaType.APPLICATION_JSON)
    fun getPeers(): Map<String, List<X500Name>> {
        val (nodeInfo, nodeUpdates) = services.networkMapUpdates()
        nodeUpdates.notUsed()
        return mapOf("peers" to nodeInfo
                .map { it.legalIdentity.name }
                .filter { it != myLegalName && it.toString() != NOTARY_NAME })
    }

    /**
     * Displays all IOU states that exist in the node's vault.
     */
    @GET
    @Path("ious")
    @Produces(MediaType.APPLICATION_JSON)
    fun getIOUs(): List<StateAndRef<IOUState>> {
        val vaultStates = services.vaultQueryBy<IOUState>()
        return vaultStates.states
    }

    /**
     * Initiates a flow to agree an IOU between two parties.
     *
     * Once the flow finishes it will have written the IOU to ledger. Both the sender and the recipient will be able to
     * see it when calling /api/example/ious on their respective nodes.
     *
     * This end-point takes a Party name parameter as part of the path. If the serving node can't find the other party
     * in its network map cache, it will return an HTTP bad request.
     *
     * The flow is invoked asynchronously. It returns a future when the flow's call() method returns.
     */
    @PUT
    @Path("create-iou")
    fun createIOU(): Response {
        val otherParty = services.partyFromX500Name(X500Name("CN=Insurer2,O=MNO,L=Bangalore,C=IND")) ?:
                return Response.status(Response.Status.BAD_REQUEST).build()

        var status: Response.Status
        var msg: String
        try {
            val flowHandle = services.startTrackedFlow(::Initiator, 50, otherParty)
            flowHandle.progress.subscribe { println(">> $it") }

            // The line below blocks and waits for the future to resolve.
            val result = flowHandle
                    .returnValue
                    .getOrThrow()

            status = Response.Status.CREATED
            msg = "Transaction id ${result.id} committed to ledger."

        } catch (ex: Throwable) {
            status = Response.Status.BAD_REQUEST
            msg = ex.message!!
            logger.error(msg, ex)
        }

        return Response.status(status).entity(msg).build()
    }

    @PUT
    @Path("create-iou2")
    fun createIOU2(): Response {
        val otherParty = services.partyFromX500Name(X500Name("CN=Insurer2,O=MNO,L=Bangalore,C=IND")) ?:
                return Response.status(Response.Status.BAD_REQUEST).build()

        var status: Response.Status
        var msg: String
        try {
            val flowHandle = services.startTrackedFlow(::Initiator1,24,otherParty)
            flowHandle.progress.subscribe { println(">> $it") }

            // The line below blocks and waits for the future to resolve.
            val result = flowHandle
                    .returnValue
                    .getOrThrow()

            status = Response.Status.CREATED
            msg = "Transaction id ${result.id} committed to ledger."

        } catch (ex: Throwable) {
            status = Response.Status.BAD_REQUEST
            msg = ex.message!!
            logger.error(msg, ex)
        }

        return Response.status(status).entity(msg).build()
    }

  /*  @POST
    @Path("store-policyholder/{a1}")
    fun storePolicyHolderDetail(@PathParam("a1") reqId : String) : Response{

        var status: Response.Status
        var msg: String
        try {


           *//* val policyHolder1 = PolicyHolder(a1,"XRTYF8237",'M',"TOM","K","Hanks", LocalDate.now(),"Greenfield","US",'M',"PG","Govt",787766, LocalDateTime.now())
            val policyHolder2 =PolicyHolder(a2,"ABCDR8237",'F',"Mary2","Kom2","Singh", LocalDate.now(),"20 G.L.Road","WB",'M',"PG","Govt",787766, LocalDateTime.now())
            val policyHolderDetailsList = mutableListOf(policyHolder1,policyHolder2)*//*
            val flowHandle = services.startTrackedFlow(PolicyHolderDetailStorageFlow::Initiator,reqId)

            flowHandle.progress.subscribe { println(">> $it") }
            // The line below blocks and waits for the future to resolve.
            val result = flowHandle
                    .returnValue
                    .getOrThrow()

            status = Response.Status.CREATED
            msg = "Transaction id ${result} committed to ledger."

            *//*System.out.println("***************going to call publish flow for"+result.id)

            val flowHandle2 = services.startTrackedFlow(PolicyHolderPublishFlow::Initiator,result.tx.outputs )

            flowHandle2.progress.subscribe { println(">> $it") }
            // The line below blocks and waits for the future to resolve.
            val result2 = flowHandle2
                    .returnValue
                    .getOrThrow()

            System.out.println("after call to publish flow id is :"+result2.id)*//*



        } catch (ex: Throwable) {
            status = Response.Status.BAD_REQUEST
            msg = ex.message!!
            logger.error(msg, ex)
        }

        return Response.status(status).entity(msg).build()

    }
    @POST
    @Path("store-policy/{a1}")
    fun storePolicyDetail(@PathParam("a1") reqId : String) : Response{

        var status: Response.Status
        var msg: String
        try {

            *//*val policy1 = Policy('E',a1,p1,"UniNo1",'U',"ABCNomin",'A',1200.0,10000.0,'Y', LocalDate.now(),"APassport", LocalDateTime.now())
            val policy2 = Policy('E',a2,p2,"UniNo1",'U',"XYZNomin",'A',2200.0,50000.0,'Y',LocalDate.now(),"BPassport", LocalDateTime.now())
            val listOfPolicy = mutableListOf<Policy>(policy1,policy2)*//*
            val flowHandle = services.startTrackedFlow(PolicyDetailStorageFlow::Initiator,reqId)

            flowHandle.progress.subscribe { println(">> $it") }
            // The line below blocks and waits for the future to resolve.
            val result = flowHandle
                    .returnValue
                    .getOrThrow()

            status = Response.Status.CREATED
            msg = "Transaction id ${result} committed to ledger."

           *//* System.out.println("***************going to call publish flow for"+result.id)

            val flowHandle2 = services.startTrackedFlow(PolicyPublishFlow::Initiator,result.tx.outputs )

            flowHandle2.progress.subscribe { println(">> $it") }
            // The line below blocks and waits for the future to resolve.
            val result2 = flowHandle2
                    .returnValue
                    .getOrThrow()

            System.out.println("after call to publish flow id is :"+result2.id)*//*


        } catch (ex: Throwable) {
            status = Response.Status.BAD_REQUEST
            msg = ex.message!!
            logger.error(msg, ex)
        }

        return Response.status(status).entity(msg).build()

    }

    @POST
    @Path("store-claim/{a1}")
    fun storeClaimDetail(@PathParam("a1") reqId :String) : Response{

        var status: Response.Status
        var msg: String
        try {

            *//*val claim1= Claim(a1,p1,c1,'P','A','C','N', LocalDate.now(),LocalDateTime.now())

            val listOfClaim = mutableListOf<Claim>(claim1)*//*
            val flowHandle = services.startTrackedFlow(ClaimDetailStorageFlow::Initiator,reqId)

            flowHandle.progress.subscribe { println(">> $it") }
            // The line below blocks and waits for the future to resolve.
            val result = flowHandle
                    .returnValue
                    .getOrThrow()


            status = Response.Status.CREATED
            msg = "Transaction id ${result} committed to ledger."
            *//*System.out.println("***************going to call publish flow for"+result.id)

            val flowHandle2 = services.startTrackedFlow(ClaimPublishFlow::Initiator,result.tx.outputs )

            flowHandle2.progress.subscribe { println(">> $it") }
            // The line below blocks and waits for the future to resolve.
            val result2 = flowHandle2
                    .returnValue
                    .getOrThrow()

            System.out.println("after call to publish flow id is :"+result2.id)*//*


        } catch (ex: Throwable) {
            status = Response.Status.BAD_REQUEST
            msg = ex.message!!
            logger.error(msg, ex)
        }

        return Response.status(status).entity(msg).build()

    }

*/
}