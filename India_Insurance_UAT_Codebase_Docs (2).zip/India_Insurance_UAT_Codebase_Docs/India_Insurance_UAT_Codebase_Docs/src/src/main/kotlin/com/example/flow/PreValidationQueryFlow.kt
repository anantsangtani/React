package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.contract.InsuranceContract
import net.corda.core.contracts.Command
import net.corda.core.contracts.TransactionType
import net.corda.core.crypto.SecureHash
import net.corda.core.crypto.commonName
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatedBy
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.node.services.vault.and
import net.corda.core.node.services.vault.builder
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.unwrap
import net.corda.flows.CollectSignaturesFlow
import net.corda.flows.FinalityFlow
import net.corda.flows.ResolveTransactionsFlow
import org.bouncycastle.asn1.x500.X500Name
import org.jetbrains.exposed.sql.transactions.TransactionManager
import java.io.*
import java.sql.Timestamp
import java.time.LocalDateTime
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object PreValidationQueryFlow {
    @InitiatingFlow
    @StartableByRPC
    class Initiator(val preValidationFileHash : SecureHash,val preValidationFileName : String) : FlowLogic<Unit>() {
        /**
         * The progress tracker checkpoints each stage of the flow and outputs the specified messages when each
         * checkpoint is reached in the code. See the 'progressTracker.currentStep' expressions within the call() function.
         */
        companion object {
            object GENERATING_TRANSACTION : ProgressTracker.Step("Generating transaction based on new IOU.")
            object VERIFYING_TRANSACTION : ProgressTracker.Step("Verifying contract constraints.")
            object SIGNING_TRANSACTION : ProgressTracker.Step("Signing transaction with our private key.")
            object GATHERING_SIGS : ProgressTracker.Step("Gathering the counterparty's signature.") {
                override fun childProgressTracker() = CollectSignaturesFlow.tracker()
            }

            object FINALISING_TRANSACTION : ProgressTracker.Step("Obtaining notary signature and recording transaction.") {
                override fun childProgressTracker() = FinalityFlow.tracker()
            }

            fun tracker() = ProgressTracker(
                    GENERATING_TRANSACTION,
                    VERIFYING_TRANSACTION,
                    SIGNING_TRANSACTION,
                    GATHERING_SIGS,
                    FINALISING_TRANSACTION
            )
        }

        override val progressTracker = tracker()

        /**
         * The flow logic is encapsulated within the call() method.
         */
        @Suspendable
        override fun call() {
            // Obtain a reference to the notary we want to use.
            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity
            val me =serviceHub.myInfo.legalIdentity
            // Stage 1.
            progressTracker.currentStep = GENERATING_TRANSACTION
            // Generate an unsigned transaction.
            val txBuilder = TransactionBuilder(TransactionType.General, notary)

            txBuilder.addAttachment(preValidationFileHash)

            val txCommand = Command(InsuranceContract.Commands.RequestPreValidationQuery(), listOf(me).map { it.owningKey } )
            txBuilder.addCommand(txCommand)
            // Stage 2.
            progressTracker.currentStep = VERIFYING_TRANSACTION
            // Verify that the transaction is valid.
            txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()

            // Stage 3.
            progressTracker.currentStep = SIGNING_TRANSACTION
            // Sign the transaction.
            val partSignedTx = serviceHub.signInitialTransaction(txBuilder)
            // Stage 5.
            progressTracker.currentStep = FINALISING_TRANSACTION
            // Notarise and record the transaction in both parties' vaults.
            val x =  subFlow(FinalityFlow(partSignedTx,FINALISING_TRANSACTION.childProgressTracker())).single()

            val txnId = x.tx.id
            val priorityMemberList = subFlow(ConsortiumFlow.PriorityMemberList(me))

            for (member in priorityMemberList){
                val reqId = System.currentTimeMillis().toString()

                send(member,Pair(txnId,Pair(reqId,preValidationFileName)))
                insertRequestStatus(member.name.commonName,preValidationFileName,reqId,preValidationFileHash)
            }

        }

        private fun insertRequestStatus(memberName: String, uploadedFileName :String, reqId :String, preValidationFileHash :SecureHash) {
            val qry :String = "insert into PRE_VALIDATION_REQUEST_DETAIL (REQ_ID ,UPLOADED_FILENAME ,UPLOAD_TIMESTAMP ,DESTINATION_NODE ,STATUS,UPLOADED_FILEHASH  )" +
                    " values (?,?,?,?,?,?)"

            val dbTxn = TransactionManager.Companion.current()
            val con = dbTxn.connection

            val ps = con.prepareStatement(qry)
            ps.setString(1,reqId)
            ps.setString(2,uploadedFileName)
            ps.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()))
            ps.setString(4,memberName)
            ps.setString(5,"Submitted")
            ps.setString(6,preValidationFileHash.toString())
            ps.executeUpdate()
            ps.close()

        }

       /* fun getPriorityMemberList(): List<Party> {
            //TODO change the code to query DB
           *//*  val me = serviceHub.myInfo.legalIdentity
             val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity
             val priorityMemberList = serviceHub.networkMapCache.partyNodes.map { it.legalIdentity }.filter { it != me && it.name != notary.name}*//*
            val priorityMemberList = listOf<Party>(serviceHub.networkMapCache.getNodeByLegalName(X500Name("CN=Insurer1,O=XYZ,L=Pune,C=IND"))!!.legalIdentity)
            return priorityMemberList;
         }*/
    }

    @InitiatedBy(Initiator::class)
    class Acceptor(val otherParty: Party) : FlowLogic<Unit>() {
        @Suspendable
        override fun call() {
           receive<Pair<SecureHash,Pair<String,String>>>(otherParty).unwrap {
               System.out.println("Inside Acceptor of PreValidationQuery")
               val txnHash = it.first
               val reqId = it.second.first
               val preValidationFileName = it.second.second

               subFlow(PreValidationResponseFlow.Initiator(otherParty,txnHash,reqId,preValidationFileName))

           }
        }


    }
}