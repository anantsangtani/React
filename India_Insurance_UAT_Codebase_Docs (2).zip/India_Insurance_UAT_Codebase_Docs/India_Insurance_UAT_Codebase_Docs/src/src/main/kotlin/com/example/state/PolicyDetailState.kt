package com.example.state

import com.example.contract.InsuranceContract
import com.example.model.Policy
import com.example.model.PolicyHolder
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.crypto.entropyToKeyPair
import net.corda.core.crypto.keys
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import org.bouncycastle.asn1.x500.X500Name
import java.math.BigDecimal
import java.math.BigInteger
import java.security.PublicKey
import java.time.LocalDate
import java.time.LocalDateTime
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table
import javax.persistence.UniqueConstraint

/**
 * Created by cordadev on 7/19/2017.
 */

data class PolicyDetailState(val policyDetail: Policy,
                    val sender: Party,
                    val recipient: Party,
                    override val linearId: UniqueIdentifier = UniqueIdentifier()):
        LinearState, QueryableState {
    override val contract get() = InsuranceContract()

    /** The public keys of the involved parties. */
    override val participants: List<AbstractParty> get() = listOf(sender, recipient).distinct()

    /** Tells the vault to track a state if we are one of the parties involved. */
    override fun isRelevant(ourKeys: Set<PublicKey>) = ourKeys.intersect(participants.flatMap { it.owningKey.keys }).isNotEmpty()

    override fun generateMappedObject(schema: MappedSchema) = PolicyDetailSchemaV1.PolicyDetailEntity(this)

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(PolicyDetailSchemaV1)

    object PolicyDetailSchemaV1 : MappedSchema(PolicyDetailState::class.java,1, listOf(PolicyDetailEntity::class.java)){

        @Entity
        @Table(name ="policy_detail",
                uniqueConstraints = arrayOf(UniqueConstraint(columnNames = arrayOf("aadhar_no","policy_no","transaction_id")))
        )
        class PolicyDetailEntity(policyDetailState: PolicyDetailState) : PersistentState(){
            @Column(name = "source",nullable = false,length = 1)
            var source: Char = policyDetailState.policyDetail.source
            @Column(name = "aadhar_no",nullable = false,length = 12)
            var aadhar:Long = policyDetailState.policyDetail.aadhar
            @Column(name = "policy_no",nullable = false,length = 10)
            var policyNo:String= policyDetailState.policyDetail.policyNo
            @Column(name = "uin_no",length = 12)
            var uinNo:String?= policyDetailState.policyDetail.uinNo
            @Column(name = "product_type",nullable = false,length = 1)
            var productType: Char= policyDetailState.policyDetail.productType
            @Column(name = "nominee_name",nullable = false,length = 20)
            var nomineeName:String= policyDetailState.policyDetail.nomineeName
            @Column(name = "policy_status",length = 1)
            var policyStatus: Char?= policyDetailState.policyDetail.policyStatus
            @Column(name = "premium",length = 10)
            var premium:Double?= policyDetailState.policyDetail.premium
            @Column(name = "sum_assured",nullable = false,length = 10)
            var sumAssured:BigDecimal= policyDetailState.policyDetail.sumAssured
            @Column(name = "renewal_frequency",length = 1)
            var renewalFrequency:Char?= policyDetailState.policyDetail.renewalFrequency
            @Column(name = "policy_start_date")
            var policyStartDate: LocalDate? = policyDetailState.policyDetail.policyStartDate
            @Column(name = "under_passport",length = 10)
            var underPassport:String?= policyDetailState.policyDetail.underPassport
            @Column(name="upload_timestamp")
            var uploadTimestamp: LocalDateTime? = policyDetailState.policyDetail.uploadTimestamp

            //dummy constructor
            constructor() : this(PolicyDetailState(Policy('S',45521,"s","s",'s',"ss",'s',100.50,BigDecimal("400.20"),'s', LocalDate.now(),
                    "s", LocalDateTime.now()),Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public),
                    Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public), UniqueIdentifier("45")))
        }
    }
}