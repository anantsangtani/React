package com.example.dao

import com.example.connection.DatabaseConnection
import com.example.model.Claim
import com.example.model.Policy
import com.example.model.PolicyHolder

import java.sql.*

/**
 * Created by cordadev2 on 7/21/2017.
 */

class ApplicationDao{

    fun searchPolicyHolder(nodeName: String, dbConnection: Connection):List<PolicyHolder>{
        val policyHolderDetails : MutableList<PolicyHolder> = mutableListOf()
        var policyHolder :PolicyHolder? = null

        val  connection = dbConnection
        var statement: PreparedStatement? = null
        var rs: ResultSet?=null


        try {

                var finalQuery: String = "SELECT AADHAR_NO,PAN_NO,GENDER,FIRST_NAME,MIDDLE_NAME,LAST_NAME," +
                        " DOB,ADDRESS,STATE,NRI_STATUS,EDUCATION,EMPLOYMENT,PINCODE,UPLOAD_TIMESTAMP " +
                        " FROM  POLICY_HOLDER_DETAIL WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM VAULT_STATES WHERE STATE_STATUS=0 " +
                        " AND CONTRACT_STATE_CLASS_NAME='com.example.state.PolicyHolderDetailState');"
                statement = connection.prepareStatement(finalQuery)



            System.out.println("Statement: "+statement.toString())
            rs = statement.executeQuery()
            while (rs.next()) {
                policyHolder = PolicyHolder(rs.getLong("aadhar_no"),rs.getString("pan_no"),rs.getString("gender").get(0),
                        rs.getString("first_name"),rs.getString("middle_name"),rs.getString("last_name"),
                        rs.getDate("dob").toLocalDate(),
                        rs.getString("address"),rs.getString("state"),
                        rs.getString("nri_status").get(0),rs.getString("education"),rs.getString("employment"),
                        rs.getInt("pincode"),
                        rs.getTimestamp("upload_timestamp").toLocalDateTime()
                )
                policyHolderDetails.add(policyHolder)
            }

        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            rs?.close()
            statement?.close()
        }

        return policyHolderDetails
    }

    fun searchPolicy(nodeName: String, dbConnection: Connection):List<Policy>{

        val  connection = dbConnection
        var statement: PreparedStatement? = null
        var rs: ResultSet?=null
        val policyDetails : MutableList<Policy> = mutableListOf()

        var policy :Policy? = null

        try {


                var finalQuery = "SELECT SOURCE,AADHAR_NO,POLICY_NO,UIN_NO,PRODUCT_TYPE,NOMINEE_NAME,POLICY_STATUS,PREMIUM," +
                        "SUM_ASSURED,RENEWAL_FREQUENCY,POLICY_START_DATE,UNDER_PASSPORT,UPLOAD_TIMESTAMP " +
                        " FROM  POLICY_DETAIL WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM VAULT_STATES WHERE STATE_STATUS=0 " +
                        "AND CONTRACT_STATE_CLASS_NAME='com.example.state.PolicyDetailState');"

                print("AAdharCheck Query String"+finalQuery);
                statement = connection.prepareStatement(finalQuery)

            System.out.println("Statement: "+statement.toString())
            rs = statement.executeQuery()
            while (rs.next()) {

                policy = Policy(rs.getString("source").get(0),rs.getLong("aadhar_no"),rs.getString("policy_no"),
                        rs.getString("uin_no"),rs.getString("product_type").get(0),rs.getString("nominee_name"),
                        rs.getString("policy_status").get(0),rs.getDouble("premium"),rs.getBigDecimal("sum_assured"),
                        rs.getString("renewal_frequency").get(0),
                        rs.getDate("policy_start_date").toLocalDate(),
                        rs.getString("under_passport"),
                        rs.getTimestamp("upload_timestamp").toLocalDateTime()
                )
                policyDetails.add(policy)
            }

        } catch (se: SQLException) {
            System.out.println(se.message)
        } finally {
            rs?.close()
            statement?.close()
        }


        return policyDetails
    }

    fun searchClaim(nodeName: String, dbConnection: Connection):List<Claim>{

        val  connection = dbConnection
        var statement: PreparedStatement? = null
        var rs: ResultSet?=null
        var finalQuery :String =""

        val claimDetails : MutableList<Claim> = mutableListOf()

        var claim :Claim? = null
        try {

                var finalQuery = "SELECT AADHAR_NO,POLICY_NO,CLAIM_ID,CLAIM_STATUS,CLAIM_SUB_STATUS,FRAUD_STATUS, " +
                        " CLAIM_TYPE,CLAIM_DATE,UPLOAD_TIMESTAMP FROM CLAIM_DETAIL WHERE TRANSACTION_ID IN" +
                        " (SELECT TRANSACTION_ID FROM VAULT_STATES WHERE STATE_STATUS=0 AND CONTRACT_STATE_CLASS_NAME='com.example.state.ClaimDetailState');"

                print("AAdharCheck Query String"+finalQuery);
                statement = connection.prepareStatement(finalQuery)



            System.out.println("Statement: "+statement.toString())
            rs = statement.executeQuery()
            if(rs!=null) {
                while (rs.next()) {
                    claim = Claim(rs.getLong("aadhar_no"), rs.getString("policy_no"), rs.getString("claim_id"),
                            rs.getString("claim_status").get(0), rs.getString("claim_sub_status").get(0),
                            rs.getString("fraud_status").get(0),
                            rs.getString("claim_type").get(0),
                            rs.getDate("claim_date").toLocalDate(),
                            rs.getTimestamp("upload_timestamp").toLocalDateTime()
                    )
                    claimDetails.add(claim)
                }
            }

        } catch (se: SQLException) {
            print(se)
        } finally {
            rs?.close()
            statement?.close()
            //closeConnection(connection, statement, rs)
        }

        return claimDetails
    }
    fun isAadharPresent(nodeName: String, aadharNo: Long, dbConnection: Connection):Boolean{
        var boolean :Boolean = false
        val  connection = dbConnection
        var statement: PreparedStatement? = null
        var rs: ResultSet?=null

        try {
            var queryString = "SELECT AADHAR_NO FROM POLICY_HOLDER_DETAIL WHERE AADHAR_NO =? and rownum=1;"
            statement = connection.prepareStatement(queryString)
            if (null != aadharNo) {
                statement.setLong(1, aadharNo)

            }
            rs = statement.executeQuery()
            if (rs != null) {
                while (rs.next()) {
                    if(aadharNo==rs.getLong("aadhar_no")){
                        boolean = true
                    }
                }
            }
        }
        catch (se:SQLException){
            print(se)
        }

        return boolean
    }

    fun getAadharByPolicy(nodeName: String, policyNo: String, dbConnection: Connection):String{
        var aadharNo :String =""
        val  connection = dbConnection
        var statement: PreparedStatement? = null
        var rs: ResultSet?=null

        try {
            var queryString = "SELECT AADHAR_NO FROM POLICY_DETAIL WHERE POLICY_NO =? AND rownum=1;"
            statement = connection.prepareStatement(queryString)
            if (null != policyNo) {
                statement.setString(1, policyNo)

            }
            rs = statement.executeQuery()
            if (rs != null) {
                while (rs.next()) {
                    aadharNo=  rs.getString("aadhar_no")
                }
            }
        }
        catch (se:SQLException){
            print(se)
        }

        return aadharNo
    }



    private fun closeConnection(connection: Connection?, statement: Statement?, rs: ResultSet?) {
        try {
            rs?.close()
            statement?.close()
            connection?.close()
        } catch (e: SQLException) {
            e.printStackTrace()
        }
    }
}
