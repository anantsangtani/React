package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.contract.InsuranceContract
import com.example.model.AggregatedData
import com.example.state.AggregatedState
import com.example.state.PointState
import com.template.util.ApplicationConstants
import net.corda.core.contracts.Command
import net.corda.core.contracts.TransactionType
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatedBy
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.node.services.vault.and
import net.corda.core.node.services.vault.builder
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.unwrap
import net.corda.flows.FinalityFlow
import org.bouncycastle.asn1.x500.X500Name
import org.jetbrains.exposed.sql.transactions.TransactionManager
import java.sql.Connection
import java.sql.Timestamp
import java.time.LocalDate

object AggregateQueryFlow{
    @InitiatingFlow
    @StartableByRPC
    class Initiator(val aadharNo : Long) : FlowLogic<AggregatedData?>() {

        @Suspendable
        override fun call(): AggregatedData? {
            System.out.println("********* inside AggregateQueryFlow initiator ************")
            val regulatory = serviceHub.networkMapCache.getNodeByLegalName(X500Name("CN=Consortium,O=ABC,L=Mumbai,C=IND"))!!.legalIdentity
            val result = sendAndReceive<Any>(regulatory,aadharNo).unwrap {
                it as? AggregatedData
            }
            return result
        }
    }

    @InitiatedBy(Initiator::class)
    class Acceptor(val otherParty: Party) : FlowLogic<Unit>() {
        @Suspendable
        override fun call() {

            val aadharNo = receive<Long>(otherParty).unwrap {
               System.out.println("***** inside receive of the AggregateQueryFlow *** when I am :"+serviceHub.myInfo.legalIdentity)
                it
            }
            System.out.println("**found Aadhar :"+aadharNo)
            //query regualtor's vault based on this aadhar no
            val exp1 = builder { AggregatedState.AggregatedDataSchemaV1.AggregatedDataEntity::aadhar.equal(aadharNo) }
            val aadharCriteria = QueryCriteria.VaultCustomQueryCriteria(exp1)
            val unconsumedCriteria = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)

            val aggregatedStateAndRef = serviceHub.vaultQueryService.queryBy<AggregatedState>(aadharCriteria.and(unconsumedCriteria)).states.singleOrNull()


            if(aggregatedStateAndRef != null){
                aggregatedStateAndRef.state?.data?.aggregatedData?.let {

                    val graphOutput = populateMonthWiseTrandMap(aadharNo)

                    it.monthWiseSumAssuredMap = graphOutput.first
                    it.monthWiseClaimCountMap = graphOutput.second

                    send(otherParty, it)

                    System.out.println("Going to debit point for aggregate query")
                    val queryCount : Long = 1
                    val pointToDebit : Long = ApplicationConstants.AGGREGATE_QRY_DEBIT_POINT
                    val pointToCredit : Long = ApplicationConstants.AGGREGATE_QRY_CREDIT_POINT
                    // Obtain a reference to the notary we want to use.
                    val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity

                    val regulatory = serviceHub.myInfo.legalIdentity
                    val txBuilder = TransactionBuilder(TransactionType.General, notary)
                    val txCommand = Command(InsuranceContract.Commands.DebitPointForAggregateQry(), listOf(regulatory).map { it.owningKey } )
                    txBuilder.addCommand(txCommand)

                    val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)

                    //add previous point state of debit party as input state
                    val unconsumedPointStateRef = serviceHub.vaultQueryService.queryBy<PointState>(qryCriteriaUnconsumed).states
                            .filter { it.state.data.accountHolder.equals(otherParty) }.single()
                    txBuilder.addInputState(unconsumedPointStateRef)
                    //update the point value in point state of debit party and add as output state
                    val prevPointState = unconsumedPointStateRef.state.data
                    val prevNoOfReqMade = prevPointState.noOfRequestMade
                    val prevPointsDue = prevPointState.pointsDue
                    val newPointState = prevPointState.copy(noOfRequestMade = prevNoOfReqMade!!.plus(queryCount),
                            pointsDue = prevPointsDue!!.minus(pointToDebit),netPointBalance = prevPointState.netPointBalance!!.minus(pointToDebit),
                            noOfAggregateQry = prevPointState.noOfAggregateQry.plus(queryCount),latestAggregateQryDate = LocalDate.now())
                    txBuilder.addOutputState(newPointState)

                    //add previous point state of credit party i.e. regulatory as input state
                    val unconsumedPointStateRefOfCreditParty = serviceHub.vaultQueryService.queryBy<PointState>(qryCriteriaUnconsumed).states
                            .filter { it.state.data.accountHolder.equals(regulatory) }.single()
                    txBuilder.addInputState(unconsumedPointStateRefOfCreditParty)
                    //update the point value in point state of debit party and add as output state
                    val prevPointStateOfCreditParty = unconsumedPointStateRefOfCreditParty.state.data
                    val prevNoOfResponseMade = prevPointStateOfCreditParty.noOfResponseMade
                    val prevPointsEarned = prevPointStateOfCreditParty.pointsEarned
                    val newPointStateOfCreditParty = prevPointStateOfCreditParty.copy(noOfResponseMade = prevNoOfResponseMade!!.plus(queryCount),
                            pointsEarned = prevPointsEarned!!.plus(pointToCredit),netPointBalance = prevPointStateOfCreditParty.netPointBalance!!.plus(pointToCredit))
                    txBuilder.addOutputState(newPointStateOfCreditParty)

                    // Verify that the transaction is valid.
                    txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()
                    // Sign the transaction.
                    val partSignedTx = serviceHub.signInitialTransaction(txBuilder)
                    // Notarise and record the transaction in both parties' vaults.
                    subFlow(FinalityFlow(partSignedTx)).single()
                }
            }else{
                send(otherParty, "No record present for the Aadhar")
            }


        }

        private fun populateMonthWiseTrandMap(aadharNo: Long): Pair<MutableMap<String, Double>, MutableMap<String, Double>> {
            val currDate = LocalDate.now()
            val rangeStartDate = currDate.minusMonths(6).atStartOfDay()
            val monthWiseSumAssuredMap: MutableMap<String,Double> = mutableMapOf()
            val monthWiseClaimCountMap: MutableMap<String,Double> = mutableMapOf()

            var monthRange = 6
            var currMonth = currDate.month
            while(monthRange > 0){
                monthWiseSumAssuredMap.put(currMonth.toString(),0.0)
                monthWiseClaimCountMap.put(currMonth.toString(),0.0)
                currMonth = currMonth.minus(1)
                monthRange -= 1
            }

            // query 6 months' sum assured and claim trend
            val trendQuery = "select UPDATE_TIMESTAMP  ,TOTAL_SUMASSURED , TOTAL_CLAIM from AGGREGATED_DATA_DETAIL " +
                    " where AADHAR_NO = ? and UPDATE_TIMESTAMP > ?  order by UPDATE_TIMESTAMP asc"

            val conn = getDbConnection()
            val ps= conn.prepareStatement(trendQuery)
            ps.setLong(1,aadharNo)
            ps.setTimestamp(2, Timestamp.valueOf(rangeStartDate))
            val rs = ps.executeQuery()
            while(rs.next()){
                val mnth = rs.getTimestamp(1).toLocalDateTime().month.toString()
                val sumAssured = rs .getDouble(2)
                val claimCount = rs .getDouble(3)
                if(monthWiseSumAssuredMap.containsKey(mnth)){
                    monthWiseSumAssuredMap.put(mnth,sumAssured)
                }
                if(monthWiseClaimCountMap.containsKey(mnth)){
                    monthWiseClaimCountMap.put(mnth,claimCount)
                }
                /*if(monthWiseSumAssuredMap.containsKey(mnth) && monthWiseSumAssuredMap.get(mnth)!!.equals(0.0)){
                    monthWiseSumAssuredMap.put(mnth,sumAssured)
                }
                if(monthWiseClaimCountMap.containsKey(mnth) && monthWiseClaimCountMap.get(mnth)!!.equals(0.0)){
                    monthWiseClaimCountMap.put(mnth,claimCount)
                }*/
            }
            rs.close()
            ps.close()

            return Pair(monthWiseSumAssuredMap,monthWiseClaimCountMap)
        }

        private fun getDbConnection(): Connection {
            val dbTxn = TransactionManager.Companion.current()
            val con = dbTxn.connection
            return con
        }
    }

}