package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.contract.InsuranceContract
import com.example.state.PointState
import net.corda.core.contracts.Command
import net.corda.core.contracts.TransactionType
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.flows.FinalityFlow

object MonthlyPointDeductionFlow {

    @InitiatingFlow
    @StartableByRPC
    class Initiator(val otherParty : Party,val pointToDebit : Long) : FlowLogic<SignedTransaction>() {

        @Suspendable
        override fun call(): SignedTransaction {

            // Obtain a reference to the notary we want to use.
            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity

            val regulatory = serviceHub.myInfo.legalIdentity
            val txBuilder = TransactionBuilder(TransactionType.General, notary)
            val txCommand = Command(InsuranceContract.Commands.DeductMonthlyPenalty(), listOf(regulatory).map { it.owningKey } )
            txBuilder.addCommand(txCommand)

            val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)

            //add previous point state of debit party as input state
            val unconsumedPointStateRef = serviceHub.vaultQueryService.queryBy<PointState>(qryCriteriaUnconsumed).states
                    .filter { it.state.data.accountHolder.equals(otherParty) }.single()
            txBuilder.addInputState(unconsumedPointStateRef)
            //update the point value in point state of debit party and add as output state
            val prevPointState = unconsumedPointStateRef.state.data
            val prevPointsDue = prevPointState.pointsDue
            val newPointState = prevPointState.copy(pointsDue = prevPointsDue!!.minus(pointToDebit),netPointBalance = prevPointState.netPointBalance!!.minus(pointToDebit))
            txBuilder.addOutputState(newPointState)

            // Verify that the transaction is valid.
            txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()

            // Sign the transaction.
            val partSignedTx = serviceHub.signInitialTransaction(txBuilder)

            // Notarise and record the transaction in both parties' vaults.
           return  subFlow(FinalityFlow(partSignedTx)).single()
        }
    }
}