package com.example.flow

import co.paralleluniverse.fibers.Suspendable

import com.example.contract.ConsortiumContract
import com.example.model.AggregatedData
import com.example.state.*
import com.example.state.ClaimPublishState.ClaimPublishSchemaV1.ClaimPublishEntity

import com.google.common.collect.ImmutableSet

import net.corda.core.contracts.*
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatedBy
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.*
import net.corda.core.node.services.vault.Builder.equal
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.flows.CollectSignaturesFlow
import net.corda.flows.FinalityFlow
import net.corda.flows.SignTransactionFlow
import org.bouncycastle.asn1.x500.X500Name
import java.util.*
import kotlin.collections.HashMap

object ConsortiumFlow {

    @StartableByRPC
    @InitiatingFlow
    class ConsortiumCreator(val listOfParticipants:MutableList<Party>): FlowLogic<Unit>(){
        @Suspendable
        override fun call(): Unit {
            System.out.print("Starting the Consortium Create Flow")


            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity
            val me  = serviceHub.myInfo.legalIdentity
            val name = me.name.toString()
            listOfParticipants.add(me)
            val txBuilder = TransactionBuilder(TransactionType.General, notary)
            val consortiumName = "BlueConsortium"+randomCharGenerator()
            val corsortiumState = ConsortiumState(consortiumName,listOfParticipants,me)
            txBuilder.addOutputState(corsortiumState)
            val txCommand = Command(ConsortiumContract.Commands.CreateConsortium(),listOfParticipants.toSet().map { it.owningKey })
            txBuilder.addCommand(txCommand)
            txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()
            val partSignedTx = serviceHub.signInitialTransaction(txBuilder)
            val fullySignedTx = subFlow(CollectSignaturesFlow(partSignedTx))
            val txn = subFlow(FinalityFlow(fullySignedTx)).single()
            System.out.println("Consortium created with tx id :"+txn.id)
        }
       private fun randomCharGenerator():Char{
           val r = Random()
           var char =(48 +r.nextInt(47)).toChar().toUpperCase()
           return char
        }

    }

    @InitiatedBy(ConsortiumCreator::class)
    class ConsortiumAcceptor(val otherParty: Party) : FlowLogic<SignedTransaction>() {
        @Suspendable
        override fun call(): SignedTransaction {
            val signTransactionFlow = object : SignTransactionFlow(otherParty) {
                override fun checkTransaction(stx: SignedTransaction){
                    require(stx.tx.outputs.single().data is ConsortiumState)
                }
            }
            return subFlow(signTransactionFlow)
        }
    }

    @StartableByRPC
    @InitiatingFlow
    class withinConsortium (val sender : Party,val reciever:Party): FlowLogic<Boolean>(){
        override fun call(): Boolean {
            var isPresent :Boolean = false
            val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
            val vaultStates = serviceHub.vaultQueryService.queryBy<ConsortiumState>(qryCriteriaUnconsumed).states
            for(vaultState in vaultStates){
                val consortiumState =vaultState.state.data
                if (consortiumState.listOfParticipants.contains(sender) && consortiumState.listOfParticipants.contains(reciever))
                    isPresent =true
            }
            return isPresent;
        }

    }

    @StartableByRPC
    class PriorityMemberList (val currentNode : Party): FlowLogic<MutableSet<Party>>(){
        override fun call(): MutableSet<Party> {
            val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
            val vaultStates = serviceHub.vaultQueryService.queryBy<ConsortiumState>(qryCriteriaUnconsumed).states
            var priorityMemberSet = mutableSetOf<Party>()
            for(vaultState in vaultStates){
                val consortiumState = vaultState.state.data
                val memberList = consortiumState.listOfParticipants
                if(memberList.contains(currentNode)){
                    priorityMemberSet.addAll(memberList)
                }
            }
            //exclude the current node
            if(priorityMemberSet.contains(currentNode))
                priorityMemberSet.remove(currentNode)

            return priorityMemberSet
        }
    }



    @StartableByRPC
    @InitiatingFlow
    class deleteConsortium (val consortiumName:String): FlowLogic<Unit>(){
        override fun call(): Unit {
            var isPresent :Boolean = false
            val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
            val vaultStates = serviceHub.vaultQueryService.queryBy<ConsortiumState>(qryCriteriaUnconsumed).states
            for(vaultState in vaultStates) {
                val consortiumState = vaultState.state.data
                if (consortiumState.consortiumName.equals(consortiumName)) {
                    val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity
                    val me = serviceHub.myInfo.legalIdentity


                    val txBuilder = TransactionBuilder(TransactionType.General, notary)
                    txBuilder.addInputState(vaultState)


                    val txCommand = Command(ConsortiumContract.Commands.DeleteConsortium(), setOf<Party>(me).map { it.owningKey })
                    txBuilder.addCommand(txCommand)
                    txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()
                    val signedTx = serviceHub.signInitialTransaction(txBuilder)
                    val x = subFlow(FinalityFlow(signedTx)).single()
                }
            }

        }

    }

}