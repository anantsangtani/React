package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.contract.InsuranceContract
import com.example.state.PolicyHolderDetailState
import com.example.state.PolicyHolderPublishState
import net.corda.core.contracts.*
import net.corda.core.flows.*
import net.corda.core.identity.Party
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.flows.CollectSignaturesFlow
import net.corda.flows.FinalityFlow
import net.corda.flows.SignTransactionFlow
import org.bouncycastle.asn1.x500.X500Name
import java.time.LocalDateTime

/**
 * Created by cordadev on 7/24/2017.
 */

object PolicyHolderPublishFlow {
    @InitiatingFlow
    @StartableByRPC
    class Initiator(val vaultDetailStates: List<TransactionState<ContractState>>) : FlowLogic<Boolean>() {
        /**
         * The progress tracker checkpoints each stage of the flow and outputs the specified messages when each
         * checkpoint is reached in the code. See the 'progressTracker.currentStep' expressions within the call() function.
         */
        companion object {
            object GENERATING_TRANSACTION : ProgressTracker.Step("Generating transaction based on new IOU.")
            object VERIFYING_TRANSACTION : ProgressTracker.Step("Verifying contract constraints.")
            object SIGNING_TRANSACTION : ProgressTracker.Step("Signing transaction with our private key.")
            object GATHERING_SIGS : ProgressTracker.Step("Gathering the counterparty's signature.") {
                override fun childProgressTracker() = CollectSignaturesFlow.tracker()
            }

            object FINALISING_TRANSACTION : ProgressTracker.Step("Obtaining notary signature and recording transaction.") {
                override fun childProgressTracker() = FinalityFlow.tracker()
            }

            fun tracker() = ProgressTracker(
                    GENERATING_TRANSACTION,
                    VERIFYING_TRANSACTION,
                    SIGNING_TRANSACTION,
                    GATHERING_SIGS,
                    FINALISING_TRANSACTION
            )
        }

        override val progressTracker = tracker()

        /**
         * The flow logic is encapsulated within the call() method.
         */
        @Suspendable
        override fun call(): Boolean {
            System.out.println("**** Start of publish flow *****")
            // Obtain a reference to the notary we want to use.
            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity

            // Stage 1.
            progressTracker.currentStep = GENERATING_TRANSACTION
            // Generate an unsigned transaction.
            val txBuilder = TransactionBuilder(TransactionType.General, notary)
            val me = serviceHub.myInfo.legalIdentity
            val regulatory = serviceHub.networkMapCache.getNodeByLegalName(X500Name("CN=Consortium,O=ABC,L=Mumbai,C=IND"))!!.legalIdentity
            //prepare output state
            //val vaultDetailStates = vaultStorageTxn.tx.outputs
            for(vaultDetailState in vaultDetailStates){
                val policyHolderDetail = (vaultDetailState.data as PolicyHolderDetailState).policyHolder
                val publishOutputState = PolicyHolderPublishState(policyHolderDetail.aadhar,policyHolderDetail.pan,policyHolderDetail.nriStatus,
                        policyHolderDetail.employment,policyHolderDetail.state,LocalDateTime.now(),me,regulatory)
                txBuilder.addOutputState(publishOutputState)
            }

            val txCommand = Command(InsuranceContract.Commands.PublishPolicyHolder(), listOf(me,regulatory).map { it.owningKey })
            txBuilder.addCommand(txCommand)

            // Stage 2.
            progressTracker.currentStep = VERIFYING_TRANSACTION
            // Verify that the transaction is valid.
            txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()

            // Stage 3.
            progressTracker.currentStep = SIGNING_TRANSACTION
            // Sign the transaction.
            val partSignedTx = serviceHub.signInitialTransaction(txBuilder)

            // Stage 4.
            progressTracker.currentStep = GATHERING_SIGS
            // Send the state to the counterparty, and receive it back with their signature.
            val fullySignedTx = subFlow(CollectSignaturesFlow(partSignedTx, GATHERING_SIGS.childProgressTracker()))

            // Stage 5.
            progressTracker.currentStep = FINALISING_TRANSACTION
            // Notarise and record the transaction in both parties' vaults.
            val publishedTransaction = subFlow(FinalityFlow(fullySignedTx, FINALISING_TRANSACTION.childProgressTracker())).single()

            System.out.println("------------before RegulatoryIntimationFlow call from publish flow ------------")
            // call to intimate aggregator to credit point -- subFlow
            subFlow(RegulatoryIntimationFlow.Initiator(publishedTransaction.tx.id.toString(),regulatory,"POLICY_HOLDER"))

            System.out.println("------------after RegulatoryIntimationFlow call from publish flow ------------")

            return publishedTransaction.id != null;
        }

      /*  private fun updateStatus( txnId: String) {

            try {
                //update internal table
                val conn = org.jetbrains.exposed.sql.transactions.TransactionManager.current().connection
                val qry = "update file_data_processing_status set publish_status = ?, latest_txn_id = ? ,update_timestamp =? " +
                          " where req_id =? and latest_txn_id = ?"
                val ps = conn.prepareStatement(qry)
                ps.setString(1, "Y")
                ps.setString(2, txnId)
                ps.setTimestamp(3, java.sql.Timestamp.valueOf(LocalDateTime.now()))
                ps.setString(4, reqId)
                ps.setString(5,vaultStorageTxn.id.toString())
                ps.executeUpdate()
                System.out.println("after publish status updated successfully")
                //update ui status table
                val updQry = "update "

            }catch (e : SQLException){
                throw FlowException("Error in update status after publish")
            }
        }*/

    }

    @InitiatedBy(Initiator::class)
    class Acceptor(val otherParty: Party) : FlowLogic<SignedTransaction>() {
        @Suspendable
        override fun call(): SignedTransaction {
            val signTransactionFlow = object : SignTransactionFlow(otherParty) {
                override fun checkTransaction(stx: SignedTransaction)= requireThat {

                   val outputs = stx.tx.outputs
                    for (output in outputs) {
                        "This must be a policy holder publish transaction." using (output.data is PolicyHolderPublishState)
                    }

                }
            }

            return subFlow(signTransactionFlow)
        }
    }
}