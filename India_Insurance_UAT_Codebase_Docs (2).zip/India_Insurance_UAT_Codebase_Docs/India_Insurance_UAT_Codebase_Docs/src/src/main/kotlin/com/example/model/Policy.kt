package com.example.model

import net.corda.core.serialization.CordaSerializable
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * Created by cordadev on 7/19/2017.
 */

@CordaSerializable
data class Policy(val source: Char, val aadhar:Long, val policyNo:String, val uinNo:String?,
                  val productType:Char, val nomineeName:String, val policyStatus:Char?,
                  val premium:Double?, val sumAssured:BigDecimal, val renewalFrequency:Char?,
                  val policyStartDate: LocalDate?, val underPassport :String?, val uploadTimestamp:LocalDateTime?)