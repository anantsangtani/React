package com.example.plugin

import com.example.state.*
import net.corda.core.node.CordaPluginRegistry
import net.corda.core.schemas.MappedSchema

class ExamplePlugin : CordaPluginRegistry() {

    override val requiredSchemas: Set<MappedSchema> = setOf(PolicyHolderDetailState.PolicyHolderDetailSchemaV1,
                                                            PolicyDetailState.PolicyDetailSchemaV1,
                                                            ClaimDetailState.ClaimDetailSchemaV1,
                                                            PolicyHolderPublishState.PolicyHolderPublishSchemaV1,
                                                            PolicyPublishState.PolicyPublishSchemaV1,
                                                            ClaimPublishState.ClaimPublishSchemaV1,
                                                            AggregatedState.AggregatedDataSchemaV1,
                                                            DetailedDataReqState.DetailDataSchemaV1,
                                                            PointState.PointSchemaV1)
}