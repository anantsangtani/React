package com.example.connection

import com.template.util.ApplicationConstants
import com.template.util.ApplicationUtil
import java.net.InetAddress
import java.sql.Connection
import java.sql.DriverManager

/**
 * Created by cordadev2 on 7/21/2017.
 */
object DatabaseConnection {
   fun getConnection(nodeName: String) : Connection {
        var port : String = getPort(nodeName)
        Class.forName("org.h2.Driver")
        val dbConnectionString = "jdbc:h2:tcp://"+getSystemIpAddress()+":$port/node"
        val con = DriverManager.getConnection(
                dbConnectionString, "sa", "")

        return con
    }

    fun getSystemIpAddress() : String {
        try {
            val ipAddr = InetAddress.getLocalHost()
            println(ipAddr.hostAddress)
            return ipAddr.hostAddress
        } catch (ex: Exception) {
            System.out.println(ex.message)
            return "Exeption in getting host address"
        }
    }

    fun getPort(nodeName : String) : String {
       var port = ""
         if((ApplicationConstants.INSURER_1).equals(nodeName)){
            port = ApplicationConstants.INSURER_1_PORT
        } else if((ApplicationConstants.INSURER_2).equals(nodeName)){
            port = ApplicationConstants.INSURER_2_PORT
        } /*else if(ApplicationUtil.getPartyName(ApplicationConstants.ABC_LIFE).toString().equals(nodeName)){
            port = ApplicationConstants.ABC_LIFE_PORT
        }*/ else if((ApplicationConstants.REGULATORY_NODE).equals(nodeName)){
            port = ApplicationConstants.REGULATORY_PORT
        }
        return port
    }
}