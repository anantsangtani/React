package com.example.transaferObject

import com.example.state.AggregatedState
import com.example.state.PointState
import com.example.state.PolicyPublishState

data class ResultComparePolicyState (var isProductTypeSame : Boolean?=false,
                                     var isSumAssuredSame:Boolean?=false,
                                     var isProductType:Boolean?=false,
                                     var isNomineeName:Boolean?=false,
                                     var isUnderPassport:Boolean?=false){


}