package com.example.state

import com.example.contract.InsuranceContract
import com.example.model.PolicyHolder
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.crypto.entropyToKeyPair
import net.corda.core.crypto.keys
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import org.bouncycastle.asn1.x500.X500Name
import java.math.BigInteger
import java.security.PublicKey
import java.time.LocalDate
import java.time.LocalDateTime
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table
import javax.persistence.UniqueConstraint

/**
 * Created by cordadev on 7/21/2017.
 */

data class PolicyHolderDetailState(val policyHolder: PolicyHolder,
                             val sender: Party,
                             val recipient: Party,
                             override val linearId: UniqueIdentifier = UniqueIdentifier()):
        LinearState, QueryableState {
    override val contract get() = InsuranceContract()

    /** The public keys of the involved parties. */
    override val participants: List<AbstractParty> get() = listOf(sender, recipient).distinct()

    /** Tells the vault to track a state if we are one of the parties involved. */
    override fun isRelevant(ourKeys: Set<PublicKey>) = ourKeys.intersect(participants.flatMap { it.owningKey.keys }).isNotEmpty()

    override fun generateMappedObject(schema: MappedSchema) = PolicyHolderDetailSchemaV1.PolicyHolderEntity(this)

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(PolicyHolderDetailSchemaV1)

    object PolicyHolderDetailSchemaV1 : MappedSchema(PolicyHolderDetailState::class.java, 1, listOf(PolicyHolderEntity::class.java)) {

        @Entity
        @Table(name = "policy_holder_detail",
                uniqueConstraints = arrayOf(UniqueConstraint(columnNames = arrayOf("aadhar_no","transaction_id")))
        )
        class PolicyHolderEntity(holderDetailState: PolicyHolderDetailState) : PersistentState(){

            @Column(name = "sender_name")
            var senderName: String = holderDetailState.sender.name.toString()
            @Column(name = "aadhar_no",nullable = false,length = 12)
            var aadhar: Long = holderDetailState.policyHolder.aadhar
            @Column(name = "pan_no",nullable = false,length = 10)
            var pan:String= holderDetailState.policyHolder.pan
            @Column(name = "gender",nullable = false,length = 1)
            var gender:Char= holderDetailState.policyHolder.gender
            @Column(name = "first_name",length = 30)
            var firstName:String?= holderDetailState.policyHolder.firstName
            @Column(name = "middle_name",length = 30)
            var middleName:String?= holderDetailState.policyHolder.middleName
            @Column(name = "last_name",nullable = false,length = 30)
            var lastName:String= holderDetailState.policyHolder.lastName
            @Column(name = "dob",nullable = false)
            var dob:String= holderDetailState.policyHolder.dob.toString()
            @Column(name = "address",length = 100)
            var address:String?= holderDetailState.policyHolder.address
            @Column(name = "state",length = 20)
            var state:String?= holderDetailState.policyHolder.state
            @Column(name = "nri_status",nullable = false,length = 1)
            var nriStatus:Char= holderDetailState.policyHolder.nriStatus
            @Column(name = "education",length = 100)
            var education:String?= holderDetailState.policyHolder.education
            @Column(name = "employment",length = 100)
            var employment:String?= holderDetailState.policyHolder.employment
            @Column(name = "pincode",length = 6)
            var pincode:Int?= holderDetailState.policyHolder.pincode
            @Column(name="upload_timestamp")
            var uploadTimestamp: LocalDateTime? = holderDetailState.policyHolder.uploadTimestamp

            constructor() : this(PolicyHolderDetailState(PolicyHolder(11,"a",'c',"s","d","d", LocalDate.now(),"aa","A0",
                    'N',"dd","e",455, LocalDateTime.now()),Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public),
                    Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public), UniqueIdentifier("45")))

        }



    }


}