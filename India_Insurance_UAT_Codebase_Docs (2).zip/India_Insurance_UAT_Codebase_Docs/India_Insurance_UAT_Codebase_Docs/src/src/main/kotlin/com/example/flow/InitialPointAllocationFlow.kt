package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.contract.InsuranceContract
import com.example.state.PointState
import net.corda.core.contracts.Command
import net.corda.core.contracts.TransactionType
import net.corda.core.contracts.requireThat
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatedBy
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.flows.CollectSignaturesFlow
import net.corda.flows.FinalityFlow
import net.corda.flows.SignTransactionFlow


object InitialPointAllocationFlow{

    @StartableByRPC
    @InitiatingFlow
    class Initiator()  : FlowLogic<Unit>() {

        @Suspendable
        override fun call() {
            val me = serviceHub.myInfo.legalIdentity
            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity
            val allInsurerList = serviceHub.networkMapCache.partyNodes.map { it.legalIdentity }.
                    filter {  !it.name.toString().equals("CN=Controller,O=R3,OU=corda,L=London,C=UK")}

            for (insurer in allInsurerList) {

                val txBuilder = TransactionBuilder(TransactionType.General, notary)
                val pointState = PointState(0, 0, 0, 0, 0, 0, me, insurer)
                txBuilder.addOutputState(pointState)
                val txCommand = Command(InsuranceContract.Commands.AllocatePoint(), pointState.participants.map { it.owningKey })
                txBuilder.addCommand(txCommand)

                // Verify that the transaction is valid.
                txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()

                // Sign the transaction.
                val partSignedTx = serviceHub.signInitialTransaction(txBuilder)

                val fullySignedTx = subFlow(CollectSignaturesFlow(partSignedTx))

                // Notarise and record the transaction in both parties' vaults.
                val vaultStorageTxn = subFlow(FinalityFlow(fullySignedTx)).single()

                System.out.println("** InitialPointAllocationFlow completed with txn id :" + vaultStorageTxn.id)

            }
      }

    }

    @InitiatedBy(Initiator::class)
    class Acceptor(val otherParty: Party) : FlowLogic<SignedTransaction>() {
        @Suspendable
        override fun call(): SignedTransaction {
            val signTransactionFlow = object : SignTransactionFlow(otherParty) {
                override fun checkTransaction(stx: SignedTransaction) = requireThat {

                    val output = stx.tx.outputs.single().data
                    "This must be a point state transaction." using (output is PointState)
                }
            }

            return subFlow(signTransactionFlow)
        }
    }
}