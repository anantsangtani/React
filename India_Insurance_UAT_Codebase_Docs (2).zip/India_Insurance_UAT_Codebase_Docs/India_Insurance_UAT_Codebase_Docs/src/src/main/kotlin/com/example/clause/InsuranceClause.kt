package com.example.clause

import com.example.contract.InsuranceContract.Commands
import com.example.state.*
import net.corda.core.contracts.*
import net.corda.core.contracts.clauses.AnyOf
import net.corda.core.contracts.clauses.Clause
import net.corda.core.contracts.clauses.GroupClauseVerifier

interface InsuranceClause {

    class Group : GroupClauseVerifier<LinearState,Commands,Unit>(
                AnyOf(PolicyHolderSaveClause(), PolicyDetailSaveClause(),ClaimDetailSaveClause(),
                        PolicyHolderPublishClause(),PolicyPublishClause(),ClaimPublishClause(),AggregateClause(),
                        PreValidationRequestClause(),PreValidationResponseClause(),DetailDataReqClause(),
                        DetailDataRespClause(),DeathNotificationClause(), PointAllocationClause(),ManagePointClause(),
                        DetailDataRejectClause(),DebitClauseForAggregateQry(),MonthlyPenaltyClause())){
        override fun groupStates(tx: TransactionForContract): List<TransactionForContract.InOutGroup<LinearState, Unit>> {
           return  tx.groupStates<LinearState,Unit> { }
        }
    }

    class PolicyHolderSaveClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.StorePolicyHolder>()

            requireThat {
                "0 or 1 input state is expected" using (inputs.size == 1 || inputs.size == 0)
                "Only one output state is expected" using (outputs.size == 1)
                val output = outputs.single() as PolicyHolderDetailState
                "All participants should sign the transaction" using (output.participants.containsAll(command.signingParties) )
            }

            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.StorePolicyHolder::class.java)

    }

    class PolicyDetailSaveClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.StorePolicyDetail>()
            requireThat {
                //"0 or 1 input state is expected" using (inputs.size == 1 || inputs.size == 0)
                "minimum one output state is expected" using (outputs.size > 0)
                for(output in outputs){
                    "Output should be a PolicyDetailState" using (output is PolicyDetailState)
                    "All participants should sign the transaction" using (output.participants.containsAll(command.signingParties) )
                }
               /* val output = outputs.get(0) as PolicyDetailState
                "All participants should sign the transaction" using (output.participants.containsAll(command.signingParties) )*/
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.StorePolicyDetail::class.java)

    }

    class ClaimDetailSaveClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.StoreClaimDetail>()
            requireThat {
                //"0 or 1 input state is expected" using (inputs.size == 1 || inputs.size == 0)
                "minimum one output state is expected" using (outputs.size > 0)
                for(output in outputs){
                    "Output should be a ClaimDetailState" using (output is ClaimDetailState)
                    "All participants should sign the transaction" using (output.participants.containsAll(command.signingParties) )
                }
              /*  val output = outputs.get(0) as ClaimDetailState
                "All participants should sign the transaction" using (output.participants.containsAll(command.signingParties) )*/
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.StoreClaimDetail::class.java)
    }

    class PolicyHolderPublishClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.PublishPolicyHolder>()
            requireThat {
                "No input should be consumed" using ( inputs.size == 0)
                "Only one output state is expected" using (outputs.size == 1)
                val output = outputs.single() as PolicyHolderPublishState
                "All participants should sign the transaction" using (output.participants.containsAll(command.signingParties) )
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.PublishPolicyHolder::class.java)
    }

    class PolicyPublishClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.PublishPolicy>()
            requireThat {
                "No input should be consumed" using ( inputs.size == 0)
                "Minimum one output state is expected" using (outputs.size > 0)
                for(output in outputs){
                    "Output should be a PolicyPublishState" using (output is PolicyPublishState)
                    "All participants should sign the transaction" using (output.participants.containsAll(command.signingParties) )
                }
               /* val output = outputs.get(0) as PolicyPublishState
                "All participants should sign the transaction" using (output.participants.containsAll(command.signingParties) )*/
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.PublishPolicy::class.java)
    }

    class ClaimPublishClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.PublishClaim>()
            requireThat {
                "No input should be consumed" using ( inputs.size == 0)
                "Minimum one output state is expected" using (outputs.size > 0)
                for(output in outputs){
                    "Output should be a ClaimPublishState" using (output is ClaimPublishState)
                    "All participants should sign the transaction" using (output.participants.containsAll(command.signingParties) )
                }
               /* val output = outputs.get(0) as ClaimPublishState
                "All participants should sign the transaction" using (output.participants.containsAll(command.signingParties) )*/
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.PublishClaim::class.java)
    }

    class AggregateClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.AggregateData>()
            requireThat {
               /* "No input should be consumed" using ( inputs.size == 0)
                "Only one output state is expected" using (outputs.size == 1)
                val output = outputs.single() as ClaimPublishState
                "All participants should sign the transaction" using (output.participants.containsAll(command.signingParties) )*/
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.AggregateData::class.java)
    }

    class PreValidationRequestClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.RequestPreValidationQuery>()
            requireThat {
                "No input should be consumed" using (inputs.size == 0)
                "No output should be produced" using (outputs.size == 0)
                "Pre-validation request excel should be present as attachment" using (tx.attachments.size == 1)
                "Participants should sign the transaction" using (command.signers.isNotEmpty() )
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.RequestPreValidationQuery::class.java)
    }

    class PreValidationResponseClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.ResponsePreValidationQuery>()
            requireThat {
                "No input should be consumed" using (inputs.size == 0)
                "No output should be produced" using (outputs.size == 0)
                "Pre-validation request excel should be present as attachment" using (tx.attachments.size == 1)
                "Participants should sign the transaction" using (command.signers.isNotEmpty() )
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.ResponsePreValidationQuery::class.java)
    }

    class DetailDataReqClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.RequestDetail>()
            requireThat {
                "No input should be consumed" using ( inputs.size == 0)
                "Only one output state is expected" using (outputs.size == 1)
                val output = outputs.single() as DetailedDataReqState
                "All participants should sign the transaction" using (output.participants.containsAll(command.signingParties) )
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.RequestDetail::class.java)
    }
    class DetailDataRespClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {
            val command1= commands.get(0)
           // val command2= commands.get(1)
            val state1=outputs.get(0)
            val state2=outputs.get(1)


            requireThat {
                "One input should be consumed" using ( inputs.size == 1)
                "Only one output state is expected" using (outputs.size == 2)
                "Attachment must be present" using (tx.attachments.size==1)
                "IOU state should be present" using(outputs.get(0) is IOUState)
                "DetailDataReqState state should be present" using(outputs.get(1) is DetailedDataReqState)
                //val output = outputs as DetailedDataReqState


           //     "All participants should sign the transaction in IOU" using (state1.participants.containsAll(command1.signingParties) )
                "All participants should sign the transaction in DetailDataReqState" using (state2.participants.containsAll(command1.signingParties) )
            }
            return setOf(command1.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.ResponseDetail::class.java)
    }
    class DeathNotificationClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.PublishDeathNotification>()
            requireThat {
                "No input should be consumed" using (inputs.size == 0)
                "One output should be produced" using (outputs.size == 1)
              //  "Signer should be present in the participant list" using (outputs.single().participants.containsAll(command.signingParties))
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.PublishDeathNotification::class.java)
    }
    class PointAllocationClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.AllocatePoint>()
            requireThat {
                "No input should be consumed" using (inputs.size == 0)
                "One output should be produced" using (outputs.size == 1)
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.AllocatePoint::class.java)
    }


    class ManagePointClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.ManagePoints>()
            requireThat {
                "3 inputs should be consumed" using (inputs.size == 3)
                "2 outputs should be produced" using (outputs.size == 2)
                "All signers should be in the participant list" using (inputs.get(0).participants.containsAll(command.signingParties))
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.ManagePoints::class.java)
    }
    class DetailDataRejectClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.ResponseReject>()
            requireThat {
                "One input should be consumed" using ( inputs.size == 1)
                "Only one output state is expected" using (outputs.size == 1)
                "DetailDataReqState state should be present" using(outputs.get(0) is DetailedDataReqState)
                "All participants should sign the transaction" using (outputs.get(0).participants.containsAll(command.signingParties) )
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.ResponseReject::class.java)
    }

    class DebitClauseForAggregateQry :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.DebitPointForAggregateQry>()
            requireThat {
                "2 inputs should be consumed" using (inputs.size == 2)
                "2 outputs should be produced" using (outputs.size == 2)
                "All signers should be in the participant list" using (inputs.get(0).participants.containsAll(command.signingParties))
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.DebitPointForAggregateQry::class.java)
    }

    class MonthlyPenaltyClause :Clause<LinearState,Commands,Unit>(){
        override fun verify(tx: TransactionForContract, inputs: List<LinearState>,
                            outputs: List<LinearState>, commands: List<AuthenticatedObject<Commands>>,
                            groupingKey: Unit?): Set<Commands> {

            val command = commands.requireSingleCommand<Commands.DeductMonthlyPenalty>()
            requireThat {
                "1 inputs should be consumed" using (inputs.size == 1)
                "1 outputs should be produced" using (outputs.size == 1)
                "All signers should be in the participant list" using (inputs.get(0).participants.containsAll(command.signingParties))
            }
            return setOf(command.value)
        }

        override val requiredCommands: Set<Class<out CommandData>>
            get() = setOf(Commands.DeductMonthlyPenalty::class.java)
    }
}