package com.example.transaferObject


import net.corda.core.serialization.CordaSerializable
import java.time.LocalDate
import java.time.LocalDateTime
@CordaSerializable
data class AuditTrail (val attributeName:String, val pastValue:String,val newValue:String, val changedOn: LocalDateTime, val changedBy:String){


}