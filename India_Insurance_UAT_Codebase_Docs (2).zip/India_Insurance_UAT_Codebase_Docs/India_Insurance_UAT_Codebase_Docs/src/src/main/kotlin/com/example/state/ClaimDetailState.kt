package com.example.state

import com.example.contract.InsuranceContract
import com.example.model.Claim
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.crypto.entropyToKeyPair
import net.corda.core.crypto.keys
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import org.bouncycastle.asn1.x500.X500Name
import java.math.BigInteger
import java.security.PublicKey
import java.time.LocalDate
import java.time.LocalDateTime
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table
import javax.persistence.UniqueConstraint

/**
 * Created by cordadev on 7/21/2017.
 */

data class ClaimDetailState(val claimDetail: Claim,
                             val sender: Party,
                             val recipient: Party,
                             override val linearId: UniqueIdentifier = UniqueIdentifier()):
        LinearState, QueryableState {
    override val contract get() = InsuranceContract()

    /** The public keys of the involved parties. */
    override val participants: List<AbstractParty> get() = listOf(sender, recipient).distinct()

    /** Tells the vault to track a state if we are one of the parties involved. */
    override fun isRelevant(ourKeys: Set<PublicKey>) = ourKeys.intersect(participants.flatMap { it.owningKey.keys }).isNotEmpty()

    override fun generateMappedObject(schema: MappedSchema)= ClaimDetailSchemaV1.ClaimDetailEntity(this)

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(ClaimDetailSchemaV1)

    object ClaimDetailSchemaV1 : MappedSchema(ClaimDetailState::class.java,1, listOf(ClaimDetailEntity::class.java)){

        @Entity
        @Table(name ="claim_detail",
                uniqueConstraints = arrayOf(UniqueConstraint(columnNames = arrayOf("policy_no","claim_id","transaction_id")))
        )
        class ClaimDetailEntity(x : ClaimDetailState) : PersistentState() {

            @Column(name = "aadhar_no", nullable = false, length = 12)
            var aadhar: Long = x.claimDetail.aadhar
            @Column(name = "policy_no", nullable = false, length = 10)
            var policyNo: String= x.claimDetail.policyNo
            @Column(name = "claim_id", nullable = false)
            var claimId: String?= x.claimDetail.claimId
            @Column(name = "claim_status", nullable = false, length = 1)
            var claimStatus: Char= x.claimDetail.claimStatus
            @Column(name = "claim_sub_status", length = 1)
            var claimSubStatus: Char?= x.claimDetail.claimSubStatus
            @Column(name = "fraud_status", length = 1)
            var fraudStatus: Char?= x.claimDetail.fraudStatus
            @Column(name = "claim_type", length = 1)
            var claimType: Char?= x.claimDetail.claimType
            @Column(name = "claim_date", nullable = false)
            var claimDate: LocalDate = x.claimDetail.claimDate
            @Column(name="upload_timestamp")
            var uploadTimestamp: LocalDateTime? = x.claimDetail.uploadTimestamp

            constructor() : this(ClaimDetailState(Claim(4455,"p","c",'s','s','s','c', LocalDate.now(), LocalDateTime.now()),Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public),
                    Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public), UniqueIdentifier("45")))

        }

    }
}