package com.example.schema

import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table

object IOUSchema

object IOUSchemaV1 : MappedSchema(
        schemaFamily = IOUSchema.javaClass,
        version = 1,
        mappedTypes = listOf(EntityIOU::class.java)) {
    @Entity
    @Table(name = "iou_states")
    class EntityIOU(
            @Column(name = "sender_name")
            var senderName: String,

            @Column(name = "recipient_name")
            var recipientName: String,

            @Column(name = "regulatory_name")
            var regulatoryName: String?,

            @Column(name = "point_owed")
            var pointOwed: Int

    ) : PersistentState()
}