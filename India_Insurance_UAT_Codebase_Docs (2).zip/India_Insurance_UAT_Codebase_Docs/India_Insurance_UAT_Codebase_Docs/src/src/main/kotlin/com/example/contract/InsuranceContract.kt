package com.example.contract

import com.example.clause.InsuranceClause
import net.corda.core.contracts.CommandData
import net.corda.core.contracts.Contract
import net.corda.core.contracts.TransactionForContract
import net.corda.core.contracts.clauses.verifyClause
import net.corda.core.contracts.select
import net.corda.core.crypto.SecureHash

/**
 * Created by cordadev on 7/19/2017.
 */

open class InsuranceContract : Contract {
    override val legalContractReference: SecureHash
        get() = SecureHash.sha256("Insurance consortium contract")

    override fun verify(tx: TransactionForContract) = verifyClause(tx,InsuranceClause.Group(),tx.commands.select<Commands>())

    interface Commands : CommandData {
       
        class StorePolicyHolder : Commands
        class StorePolicyDetail : Commands
        class StoreClaimDetail : Commands
        class PublishPolicyHolder : Commands
        class PublishPolicy : Commands
        class PublishClaim : Commands
        class OnlyAttach : Commands
        class AggregateData : Commands
        class AllocatePoint : Commands
        class RequestPreValidationQuery : Commands
        class ResponsePreValidationQuery : Commands
        class RequestDetail : Commands
        class ResponseDetail : Commands
        class PublishDeathNotification : Commands
        class ManagePoints :Commands
        class ResponseReject : Commands
        class DebitPointForAggregateQry : Commands
        class DeductMonthlyPenalty : Commands

    }
}