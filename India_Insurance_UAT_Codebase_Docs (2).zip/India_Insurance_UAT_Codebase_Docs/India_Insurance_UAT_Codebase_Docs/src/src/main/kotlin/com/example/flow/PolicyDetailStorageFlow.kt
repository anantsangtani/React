package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.contract.InsuranceContract
import com.example.model.Policy
import com.example.state.PolicyDetailState
import net.corda.core.contracts.Command
import net.corda.core.contracts.StateAndRef
import net.corda.core.contracts.TransactionType
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.node.services.vault.and
import net.corda.core.node.services.vault.builder
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.flows.CollectSignaturesFlow
import net.corda.flows.FinalityFlow
import org.jetbrains.exposed.sql.transactions.TransactionManager
import java.sql.Connection

/**
 * Created by cordadev on 7/20/2017.
 */
object PolicyDetailStorageFlow {

    @InitiatingFlow
    @StartableByRPC
    class Initiator(val policyList : List<Policy>) : FlowLogic<Boolean>() {
        /**
         * The progress tracker checkpoints each stage of the flow and outputs the specified messages when each
         * checkpoint is reached in the code. See the 'progressTracker.currentStep' expressions within the call() function.
         */
        companion object {
            object GENERATING_TRANSACTION : ProgressTracker.Step("Generating transaction based on new IOU.")
            object VERIFYING_TRANSACTION : ProgressTracker.Step("Verifying contract constraints.")
            object SIGNING_TRANSACTION : ProgressTracker.Step("Signing transaction with our private key.")
            object GATHERING_SIGS : ProgressTracker.Step("Gathering the counterparty's signature.") {
                override fun childProgressTracker() = CollectSignaturesFlow.tracker()
            }

            object FINALISING_TRANSACTION : ProgressTracker.Step("Obtaining notary signature and recording transaction.") {
                override fun childProgressTracker() = FinalityFlow.tracker()
            }

            fun tracker() = ProgressTracker(
                    GENERATING_TRANSACTION,
                    VERIFYING_TRANSACTION,
                    SIGNING_TRANSACTION,
                    GATHERING_SIGS,
                    FINALISING_TRANSACTION
            )
        }

        override val progressTracker = tracker()

        /**
         * The flow logic is encapsulated within the call() method.
         */
        @Suspendable
        override fun call(): Boolean {
            System.out.println("=============Inside PolicyDetailStorageFlow ===========")
            // Obtain a reference to the notary we want to use.
            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity
            var isDeathClaimPresent = false








            // Stage 1.
                progressTracker.currentStep = GENERATING_TRANSACTION
                // Generate an unsigned transaction.
                val txBuilder = TransactionBuilder(TransactionType.General, notary)

                for (policy in policyList){
                    // check if state exists with the same aadhar and policy no
                    val vaultState = getVaultStateByPolicyNo(policy.aadhar,policy.policyNo)
                    if(vaultState != null){
                        System.out.println("Record present for policy no "+policy.policyNo)
                        // add the vault state as input state
                        txBuilder.addInputState(vaultState)
                    }
                    //add output state
                    val outputState = PolicyDetailState(policy,serviceHub.myInfo.legalIdentity,serviceHub.myInfo.legalIdentity)
                    txBuilder.addOutputState(outputState)
                    // check policy status for death claim
                    if('D'.equals(policy.policyStatus)) {
                        isDeathClaimPresent = true;
                    }
                }

                val txCommand = Command(InsuranceContract.Commands.StorePolicyDetail(), serviceHub.myInfo.legalIdentity.owningKey)
                txBuilder.addCommand(txCommand)
                // Stage 2.
                progressTracker.currentStep = VERIFYING_TRANSACTION
                // Verify that the transaction is valid.
                txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()
                // Stage 3.
                progressTracker.currentStep = SIGNING_TRANSACTION
                // Sign the transaction.
                val partSignedTx = serviceHub.signInitialTransaction(txBuilder)
                // Stage 5.
                progressTracker.currentStep = FINALISING_TRANSACTION
                // Notarise and record the transaction in both parties' vaults.
                val vaultStorageTxn = subFlow(FinalityFlow(partSignedTx, FINALISING_TRANSACTION.childProgressTracker())).single()
                System.out.println("Record committed to vault " +vaultStorageTxn.id.toString())
                // call publish flow
                val publishStatus = subFlow(PolicyPublishFlow.Initiator(vaultStorageTxn.tx.outputs))
            if(isDeathClaimPresent){
                val aadharNo = policyList.get(0).aadhar
                subFlow(DeathClaimNotificationFlow.Initiator(aadharNo))
            }

                return  publishStatus
        }

        /*private fun deleteTempFileData(reqId: String, aadhar: Long) {
            val conn = getDbConnection()
            val qry = "delete from POLICY_STG where REQ_ID = ? and AADHAR_NO = ?"
            val ps = conn.prepareStatement(qry)
            ps.setString(1,reqId)
            ps.setLong(2,aadhar)
            ps.executeUpdate()
            ps.close()
        }
        private fun updateFileProcessingStatus(reqId: String) {
            val conn = getDbConnection()
            val qry = "select count(*) from POLICY_STG where REQ_ID = ?"
            val ps = conn.prepareStatement(qry)
            ps.setString(1,reqId)
            val rs = ps.executeQuery()
            if(rs.next() && rs.getInt(1) == 0 ){
                val qry2 = "update GRID_DETAILS set status = ?,sys_status =? where req_id = ?"
                val ps2 = conn.prepareStatement(qry2)
                ps2.setString(1,"Success")
                ps2.setString(2,"Published")
                ps2.setString(3,reqId)
                ps2.executeUpdate()
                ps2.close()
            }
            rs.close()
            ps.close()
        }*/

        private fun getVaultStateByPolicyNo(aadharNo: Long, policyNo: String): StateAndRef<PolicyDetailState>? {

            val expression1  = builder { PolicyDetailState.PolicyDetailSchemaV1.PolicyDetailEntity::policyNo.equal(policyNo)}
            val expression2  = builder { PolicyDetailState.PolicyDetailSchemaV1.PolicyDetailEntity::aadhar.equal(aadharNo) }

            val qryCriteriaPolicyNo = QueryCriteria.VaultCustomQueryCriteria(expression1)
            val qryCriteriaAadhar = QueryCriteria.VaultCustomQueryCriteria(expression2)
            val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
            val vaultState = serviceHub.vaultQueryService.queryBy<PolicyDetailState>(qryCriteriaPolicyNo.and(qryCriteriaAadhar).and(qryCriteriaUnconsumed)).states.singleOrNull()

            return vaultState;
        }

        /*private fun updateStatus(policy: Policy) {

            try {
                val conn = org.jetbrains.exposed.sql.transactions.TransactionManager.current().connection
                val qry = "insert into file_data_processing_status values (?,?,?,?,?,?,?)"
                val ps = conn.prepareStatement(qry)
                ps.setString(1, reqId)
                ps.setLong(2, policy.aadhar)
                ps.setString(3, policy.policyNo)
                ps.setString(4, null)
                ps.setString(5, "Y")
                ps.setString(6, null)
                ps.setTimestamp(7, java.sql.Timestamp.valueOf(LocalDateTime.now()))

                ps.executeUpdate()
                System.out.println("status updated successfully")
            }catch (e : SQLException){
                throw FlowException("Error in update status")
            }
        }*/

        private fun getDbConnection(): Connection {
            val dbTxn = TransactionManager.Companion.current()
            val con = dbTxn.connection
            return con
        }
    }
}