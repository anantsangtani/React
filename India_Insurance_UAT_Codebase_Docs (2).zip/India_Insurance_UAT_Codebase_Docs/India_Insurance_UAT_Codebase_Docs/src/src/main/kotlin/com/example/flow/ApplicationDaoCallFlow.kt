package com.example.flow

import com.example.dao.ApplicationDao
import com.example.model.Claim
import com.example.model.Policy
import com.example.model.PolicyHolder
import com.example.state.DetailedDataReqState
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.StartableByRPC
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import org.jetbrains.exposed.sql.transactions.TransactionManager
import java.sql.Connection

object ApplicationDaoCallFlow {
    @StartableByRPC
    class SearchPolicy(val nodeName: String) : FlowLogic<List<Policy>>() {
        override fun call(): List<Policy> {
            val applicationDao = ApplicationDao()

            /* val expression2  = builder { PolicyDetailState.PolicyDetailSchemaV1.PolicyDetailEntity::aadhar.equal(aadharNo) }


            val qryCriteriaAadhar = QueryCriteria.VaultCustomQueryCriteria(expression2)
            val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
            val vaultState = serviceHub.vaultQueryService.queryBy<PolicyDetailState>(qryCriteriaAadhar.and(qryCriteriaUnconsumed)).states.singleOrNull()*/

            return applicationDao.searchPolicy(nodeName, getDbConnection())
        }

    }

    @StartableByRPC
    class SearchPolicyHolder(val nodeName: String) : FlowLogic<List<PolicyHolder>>() {
        override fun call(): List<PolicyHolder> {
            val applicationDao = ApplicationDao()
            return applicationDao.searchPolicyHolder(nodeName,getDbConnection())
        }

    }

    @StartableByRPC
    class searchClaim(val nodeName: String) : FlowLogic<List<Claim>>() {
        override fun call(): List<Claim> {
            val applicationDao = ApplicationDao()
            return applicationDao.searchClaim(nodeName,getDbConnection())
        }

    }

    @StartableByRPC
    class isAadharPresent(val nodeName: String, val aadharNo: Long) : FlowLogic<Boolean>() {
        override fun call(): Boolean {
            val applicationDao = ApplicationDao()
            return applicationDao.isAadharPresent(nodeName, aadharNo,getDbConnection())
        }

    }

    @StartableByRPC
    class getAadharByPolicy(val nodeName: String, val policyNumber: String) : FlowLogic<String>() {
        override fun call(): String {
            val applicationDao = ApplicationDao()
            return applicationDao.getAadharByPolicy(nodeName, policyNumber,getDbConnection())
        }

    }

    @StartableByRPC
    class detailDataDisplay() : FlowLogic<List<DetailedDataReqState>>() {
        override fun call(): List<DetailedDataReqState> {
            val applicationDao = ApplicationDao()

           var detailDataReqList : MutableList<DetailedDataReqState> = mutableListOf()


            // val qryCriteriaAadhar = QueryCriteria.VaultCustomQueryCriteria(expression2)
             val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
             val vaultState = serviceHub.vaultQueryService.queryBy<DetailedDataReqState>((qryCriteriaUnconsumed)).states
            for(stateRef in vaultState){
                detailDataReqList.add(stateRef.state.data)
            }

            return detailDataReqList

        }

    }
    private fun getDbConnection(): Connection {
        val dbTxn = TransactionManager.Companion.current()
        val con = dbTxn.connection
        return con
    }


}