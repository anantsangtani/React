package com.example.state

import com.example.contract.InsuranceContract
import com.example.model.Policy
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.crypto.entropyToKeyPair
import net.corda.core.crypto.keys
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import org.bouncycastle.asn1.x500.X500Name
import java.math.BigDecimal
import java.math.BigInteger
import java.security.PublicKey
import java.time.LocalDate
import java.time.LocalDateTime
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table
import javax.persistence.UniqueConstraint

/**
 * Created by cordadev on 7/24/2017.
 */

data class PolicyPublishState(val aadhar:Long,val policyNo:String,val productType:Char, val nomineeName:String,
                              val sumAssured:BigDecimal,val underPassport :String?,val publishTimeStamp : LocalDateTime,
                              val sender: Party,
                              val recipient: Party,
                              override val linearId: UniqueIdentifier = UniqueIdentifier()): LinearState,QueryableState {
    override val contract get() = InsuranceContract()

    /** The public keys of the involved parties. */
    override val participants: List<AbstractParty> get() = listOf(sender, recipient).distinct()

    /** Tells the vault to track a state if we are one of the parties involved. */
    override fun isRelevant(ourKeys: Set<PublicKey>) = ourKeys.intersect(participants.flatMap { it.owningKey.keys }).isNotEmpty()


    override fun generateMappedObject(schema: MappedSchema) = PolicyPublishSchemaV1.PolicyPublishEntity(this)

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(PolicyPublishSchemaV1)

    object PolicyPublishSchemaV1 : MappedSchema(PolicyPublishState::class.java,1, listOf(PolicyPublishEntity::class.java)){

        @Entity
        @Table(name ="policy_publish_data",
                uniqueConstraints = arrayOf(UniqueConstraint(columnNames = arrayOf("aadhar_no","policy_no","transaction_id")))
        )
        class PolicyPublishEntity(policyPublishState: PolicyPublishState) : PersistentState(){

            @Column(name = "aadhar_no",nullable = false,length = 12)
            var aadhar:Long = policyPublishState.aadhar
            @Column(name = "policy_no",nullable = false,length = 10)
            var policyNo:String= policyPublishState.policyNo
            @Column(name = "product_type",nullable = false,length = 1)
            var productType: Char= policyPublishState.productType
            @Column(name = "nominee_name",nullable = false,length = 20)
            var nomineeName:String= policyPublishState.nomineeName
            @Column(name = "sum_assured",nullable = false,length = 10)
            var sumAssured:BigDecimal= policyPublishState.sumAssured
            @Column(name = "under_passport",length = 10)
            var underPassport:String?= policyPublishState.underPassport
            @Column(name="publish_timestamp")
            var publishTimestamp: LocalDateTime? = policyPublishState.publishTimeStamp
            @Column(name = "sender")
            var sender:String?= policyPublishState.sender.toString()

            //dummy constructor
            constructor() : this(PolicyPublishState(45521,"s",'s',"ss",BigDecimal("0.0"),"s", LocalDateTime.now(),Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public),
                    Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public), UniqueIdentifier("45")))
        }
    }

}