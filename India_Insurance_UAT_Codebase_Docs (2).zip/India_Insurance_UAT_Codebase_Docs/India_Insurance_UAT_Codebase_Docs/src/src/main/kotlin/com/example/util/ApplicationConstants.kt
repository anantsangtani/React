package com.template.util

/**
 * Created by 397947 on 5/24/2017.
 */

object ApplicationConstants {

    var REGULATORY_NODE: String = "CN=Consortium,O=ABC,L=Mumbai,C=IND"

    var INSURER_1: String = "CN=Insurer1,O=XYZ,L=Pune,C=IND"
    var INSURER_2: String = "CN=Insurer2,O=MNO,L=Bangalore,C=IND"


    var REGULATORY_PORT: String = "2008"

    var INSURER_1_PORT: String = "2012"
    var INSURER_2_PORT: String = "2016"

    val SYSTEM: String = "System"
    val CONTROLLER: String = "Controller"

    val AGGREGATE_QRY_CREDIT_POINT :Long = 2
    val AGGREGATE_QRY_DEBIT_POINT :Long = 2
    val DETAIL_QRY_CREDIT_POINT :Long = 1
    val DETAIL_QRY_DEBIT_POINT : Long = 3

}