package com.example.model

import net.corda.core.serialization.CordaSerializable
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * Created by cordadev on 7/19/2017.
 */

@CordaSerializable
data class Claim(val aadhar: Long, val policyNo: String, val claimId :String, val claimStatus:Char, val claimSubStatus:Char?,
                 val fraudStatus:Char?, val claimType:Char?, val claimDate: LocalDate, val uploadTimestamp:LocalDateTime?)