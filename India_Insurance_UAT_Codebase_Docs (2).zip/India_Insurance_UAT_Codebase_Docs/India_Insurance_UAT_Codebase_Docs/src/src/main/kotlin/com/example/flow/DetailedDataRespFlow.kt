package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.contract.IOUContract
import com.example.contract.InsuranceContract
import com.example.model.IOU
import com.example.state.*
import net.corda.core.contracts.Command
import net.corda.core.contracts.TransactionType
import net.corda.core.crypto.SecureHash
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatedBy
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.node.services.vault.and
import net.corda.core.node.services.vault.builder
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.flows.CollectSignaturesFlow
import net.corda.flows.FinalityFlow
import net.corda.flows.SignTransactionFlow
import org.apache.poi.hssf.util.HSSFColor
import org.apache.poi.xssf.usermodel.XSSFColor
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.bouncycastle.asn1.x500.X500Name
import java.awt.Color
import java.awt.Font
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object DetailedDataRespFlow {
@InitiatingFlow
@StartableByRPC
class Initiator(val aadharNo: Long,val reqId: String,val otherParty: Party) : FlowLogic<SignedTransaction>() {
    /**
     * The progress tracker checkpoints each stage of the flow and outputs the specified messages when each
     * checkpoint is reached in the code. See the 'progressTracker.currentStep' expressions within the call() function.
     */
    var dataPresent:Boolean = true
    companion object {
        object GENERATING_TRANSACTION : ProgressTracker.Step("Generating transaction based on new IOU.")
        object VERIFYING_TRANSACTION : ProgressTracker.Step("Verifying contract constraints.")
        object SIGNING_TRANSACTION : ProgressTracker.Step("Signing transaction with our private key.")
        object GATHERING_SIGS : ProgressTracker.Step("Gathering the counterparty's signature.") {
            override fun childProgressTracker() = CollectSignaturesFlow.tracker()
        }

        object FINALISING_TRANSACTION : ProgressTracker.Step("Obtaining notary signature and recording transaction.") {
            override fun childProgressTracker() = FinalityFlow.tracker()
        }

        fun tracker() = ProgressTracker(
                GENERATING_TRANSACTION,
                VERIFYING_TRANSACTION,
                SIGNING_TRANSACTION,
                GATHERING_SIGS,
                FINALISING_TRANSACTION
        )
    }

    override val progressTracker = tracker()

    /**
     * The flow logic is encapsulated within the call() method.
     */
    @Suspendable
    override fun call(): SignedTransaction {
        // Obtain a reference to the notary we want to use.
        val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity

        // Stage 1.
        progressTracker.currentStep = GENERATING_TRANSACTION
        // Generate an unsigned transaction.

        val me = serviceHub.myInfo.legalIdentity
        val regulatory = serviceHub.networkMapCache.getNodeByLegalName(X500Name("CN=Consortium,O=ABC,L=Mumbai,C=IND"))!!.legalIdentity


    /*    val policyDetailState = PolicyHolderDetailState(PolicyHolder(11, "a", 'c', "s", "d", "d", LocalDate.now(), "aa", "A0",
                'N', "dd", "e", 455, LocalDateTime.now()), me, otherParty)*/


        val expression1 = builder { DetailedDataReqState.DetailDataSchemaV1.DetailDataEntity::reqId.equal(reqId) }
        val qryCriteriareq = QueryCriteria.VaultCustomQueryCriteria(expression1)
        val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
        val reqState = serviceHub.vaultQueryService.queryBy<DetailedDataReqState>(qryCriteriareq.and(qryCriteriaUnconsumed)).states.singleOrNull()

        val txBuilder = TransactionBuilder(TransactionType.General, notary)

            txBuilder.addInputState(reqState!!)
            val outData=reqState.state.data
        val iouState = IOUState(IOU(1), me, otherParty, regulatory)
        val txCommand = Command(IOUContract.Commands.Create(), iouState.participants.map { it.owningKey })
        var outputReqState = outData.copy(status="COMPLETED",sender = outData.recipient,recipient = outData.sender)
        txBuilder.addCommand(txCommand)
        txBuilder.addOutputState(iouState)
            //var outputReqState= DetailedDataReqState(outData.aadharNo,outData.reqId,outData.sender,outData.recipient,"COMPLETE",outData.docHash,outData.docHash)

            val txCommand1 = Command(InsuranceContract.Commands.ResponseDetail(), outputReqState.participants.map { it.owningKey })
            txBuilder.addCommand(txCommand1)




        createDetailedWorkbook(aadharNo,txBuilder,outputReqState)

        // Stage 2.
        progressTracker.currentStep = VERIFYING_TRANSACTION
        // Verify that the transaction is valid.
        txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()

        // Stage 3.
        progressTracker.currentStep = SIGNING_TRANSACTION
        // Sign the transaction.
        val partSignedTx = serviceHub.signInitialTransaction(txBuilder)

        // Stage 4.
        progressTracker.currentStep = GATHERING_SIGS
        // Send the state to the counterparty, and receive it back with their signature.

        val fullySignedTx = subFlow(CollectSignaturesFlow(partSignedTx, GATHERING_SIGS.childProgressTracker()))

        // Stage 5.
        progressTracker.currentStep = FINALISING_TRANSACTION
        // Notarise and record the transaction in both parties' vaults.
        val setOfParties = mutableSetOf<Party>(otherParty)
        val signedTxn = subFlow(FinalityFlow(fullySignedTx, FINALISING_TRANSACTION.childProgressTracker())).single()

        if(signedTxn.id != null && dataPresent){
            //intimate consortium to credit point based on IOU

            subFlow(RegulatoryIntimationFlow.Initiator(signedTxn.id.toString(),regulatory,"IOU"))
        }

        return signedTxn
    }

    private fun createDetailedWorkbook(aadharNo: Long, txBuilder: TransactionBuilder, outputReqState: DetailedDataReqState): Unit {


        try {
            val expression1 = builder { PolicyHolderDetailState.PolicyHolderDetailSchemaV1.PolicyHolderEntity::aadhar.equal(aadharNo) }
            val qryCriteriaAadhar = QueryCriteria.VaultCustomQueryCriteria(expression1)
            val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
            val vaultState = serviceHub.vaultQueryService.queryBy<PolicyHolderDetailState>(qryCriteriaAadhar.and(qryCriteriaUnconsumed)).states.singleOrNull()
            val outputWorkBook = XSSFWorkbook()
            val outputSheet = outputWorkBook.createSheet()
            var outputReqStateND :DetailedDataReqState? = null
            var outputRowNum = 0
            if (vaultState != null) {
                dataPresent =true
                var vaultData = vaultState.state.data.policyHolder


                //set header
                val headerTitle = outputSheet.createRow(outputRowNum++)
                headerTitle.createCell(0).setCellValue("POLICY HOLDER")
                //headerTitle.rowStyle.setDataFormat(Font.BOLD)
                val headerRow = outputSheet.createRow(outputRowNum++)
                headerRow.createCell(0).setCellValue("AADHAR_NO")
                headerRow.createCell(1).setCellValue("PAN")
                headerRow.createCell(2).setCellValue("GENDER")
                headerRow.createCell(3).setCellValue("FIRST_NAME")
                headerRow.createCell(4).setCellValue("LAST_NAME")
                headerRow.createCell(5).setCellValue("DATE_OF_BIRTH")
                headerRow.createCell(6).setCellValue("ADDRESS")
                headerRow.createCell(7).setCellValue("STATE")
                headerRow.createCell(8).setCellValue("NRI_STATUS")
                headerRow.createCell(9).setCellValue("EDUCATION")
                headerRow.createCell(10).setCellValue("EMPLOYMENT")
                headerRow.createCell(11).setCellValue("PINCODE")
                headerRow.createCell(12).setCellValue("MIDDLE_NAME")

                val row = outputSheet.createRow(outputRowNum++)



                row.createCell(0).setCellValue(vaultData.aadhar.toString())
                row.createCell(1).setCellValue(vaultData.pan)
                row.createCell(2).setCellValue(vaultData.gender.toString())
                row.createCell(3).setCellValue(vaultData.firstName)
                row.createCell(4).setCellValue(vaultData.lastName)
                row.createCell(5).setCellValue(vaultData.dob.toString())
                row.createCell(6).setCellValue(vaultData.address)
                row.createCell(7).setCellValue(vaultData.state)
                row.createCell(8).setCellValue(vaultData.nriStatus.toString())
                row.createCell(9).setCellValue(vaultData.education)
                row.createCell(10).setCellValue(vaultData.employment)
                row.createCell(11).setCellValue(vaultData.pincode.toString())
                row.createCell(12).setCellValue(vaultData.middleName)

                val blankRow = outputSheet.createRow(outputRowNum++)
                val headerTitlep = outputSheet.createRow(outputRowNum++)
                headerTitlep.createCell(0).setCellValue("POLICY")
                //headerTitlep.rowStyle.setDataFormat(Font.BOLD)
                val policyHeaderRow = outputSheet.createRow(outputRowNum++)
                policyHeaderRow.createCell(0).setCellValue("AADHAR_NO")
                policyHeaderRow.createCell(1).setCellValue("NOMINEE_NAME")
                policyHeaderRow.createCell(2).setCellValue("POLICY_NO")
                policyHeaderRow.createCell(3).setCellValue("POLICY_START_DATE")
                policyHeaderRow.createCell(4).setCellValue("POLICY_STATUS")
                policyHeaderRow.createCell(5).setCellValue("PREMIUM")
                policyHeaderRow.createCell(6).setCellValue("PRODUCT_TYPE")
                policyHeaderRow.createCell(7).setCellValue("RENEWAL_FREQUENCY")
                policyHeaderRow.createCell(8).setCellValue("SOURCE")
                policyHeaderRow.createCell(9).setCellValue("SUM_ASSURED")
                policyHeaderRow.createCell(10).setCellValue("UIN_NO")
                policyHeaderRow.createCell(11).setCellValue("UNDER_PASSPORT")



                val expression2 = builder { PolicyDetailState.PolicyDetailSchemaV1.PolicyDetailEntity::aadhar.equal(aadharNo) }
                val qryCriteriaAadhar = QueryCriteria.VaultCustomQueryCriteria(expression2)
                val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)

                val  policyVaultStates = serviceHub.vaultQueryService.queryBy<PolicyDetailState>(qryCriteriaAadhar.and(qryCriteriaUnconsumed)).states
                if(policyVaultStates!=null)
                {
                    for(pds  in policyVaultStates)
                    {
                        val row = outputSheet.createRow(outputRowNum++)

                        var vaultData = pds.state.data.policyDetail


                        row.createCell(0).setCellValue(vaultData.aadhar.toString())
                        row.createCell(1).setCellValue(vaultData.nomineeName)
                        row.createCell(2).setCellValue(vaultData.policyNo)
                        row.createCell(3).setCellValue(vaultData.policyStartDate.toString())
                        row.createCell(4).setCellValue(vaultData.policyStatus.toString())
                        row.createCell(5).setCellValue(vaultData.premium.toString())
                        row.createCell(6).setCellValue(vaultData.productType.toString())
                        row.createCell(7).setCellValue(vaultData.renewalFrequency.toString())
                        row.createCell(8).setCellValue(vaultData.source.toString())
                        row.createCell(9).setCellValue(vaultData.sumAssured.toString())
                        row.createCell(10).setCellValue(vaultData.uinNo)
                        row.createCell(11).setCellValue(vaultData.underPassport)

                    }
                    val blankRowTwo = outputSheet.createRow(outputRowNum++)
                    val headerTitlec = outputSheet.createRow(outputRowNum++)
                    headerTitlec.createCell(0).setCellValue("CLAIM")
                   // headerTitlec.rowStyle.setDataFormat(Font.BOLD)
                    val claimHeaderRow = outputSheet.createRow(outputRowNum++)
                    claimHeaderRow.createCell(0).setCellValue("AADHAR_NO")
                    claimHeaderRow.createCell(1).setCellValue("CLAIM_DATE")
                    claimHeaderRow.createCell(2).setCellValue("CLAIM_ID")
                    claimHeaderRow.createCell(3).setCellValue("CLAIM_STATUS")
                    claimHeaderRow.createCell(4).setCellValue("CLAIM_SUB_STATUS")
                    claimHeaderRow.createCell(5).setCellValue("CLAIM_TYPE")
                    claimHeaderRow.createCell(6).setCellValue("FRAUD_STATUS")
                    claimHeaderRow.createCell(7).setCellValue("POLICY_NO")

                    val expression3 = builder { ClaimDetailState.ClaimDetailSchemaV1.ClaimDetailEntity::aadhar.equal(aadharNo) }
                    val qryCriteriaAadhar = QueryCriteria.VaultCustomQueryCriteria(expression3)
                    val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
                    val  claimVaultStates = serviceHub.vaultQueryService.queryBy<ClaimDetailState>(qryCriteriaAadhar.and(qryCriteriaUnconsumed)).states
                    if(claimVaultStates!=null) {
                        for (cds in claimVaultStates) {
                            val row = outputSheet.createRow(outputRowNum++)

                            var vaultData = cds.state.data.claimDetail


                            row.createCell(0).setCellValue(vaultData.aadhar.toString())
                            row.createCell(1).setCellValue(vaultData.claimDate.toString())
                            row.createCell(2).setCellValue(vaultData.claimId)
                            row.createCell(3).setCellValue(vaultData.claimStatus.toString())
                            row.createCell(4).setCellValue(vaultData.claimSubStatus.toString())
                            row.createCell(5).setCellValue(vaultData.claimType.toString())
                            row.createCell(6).setCellValue(vaultData.fraudStatus.toString())
                            row.createCell(7).setCellValue(vaultData.policyNo.toString())

                        }
                    }


                }


            }
            else
            {
                dataPresent = false;
                outputReqStateND  = outputReqState.copy(status="NO DATA")

                val errorRow = outputSheet.createRow(outputRowNum++)
                errorRow.createCell(0).setCellValue("NO DATA PRESENT")

            }
            val generatedFileName = "reqID" + "_" + aadharNo+ ".xlsx"
            val fout = FileOutputStream("attachments\\" + generatedFileName)
            outputWorkBook.write(fout)
            fout.close()

            val sHash= getOutputFileHash(generatedFileName)
            if(dataPresent)
            {
                txBuilder.addOutputState(outputReqState.copy(docHash =sHash.toString(),docName = generatedFileName ))
            }
            else
            {
                txBuilder.addOutputState(outputReqStateND!!.copy(docHash =sHash.toString(),docName = generatedFileName ))
            }

            txBuilder.addAttachment(sHash)

        } catch(e: Exception) {
            System.out.print(e.printStackTrace());
            throw e;
        }


    }

    fun  getOutputFileHash(generatedFileName: String): SecureHash {

        val bout = ByteArrayOutputStream()
        val zipOutputStream = ZipOutputStream(bout)
        zipOutputStream.putNextEntry(ZipEntry(generatedFileName))
        val fileInputStream = FileInputStream("attachments\\"+generatedFileName)
        val buffer = ByteArray(4096)
        while (true) {
            val numberOfBytesRead = fileInputStream.read(buffer)
            if (numberOfBytesRead != -1) {
                zipOutputStream.write(buffer, 0, numberOfBytesRead)
            } else {
                break
            }
        }
        fileInputStream.close()
        zipOutputStream.closeEntry()
        zipOutputStream.close()

        val byteInputStrm = ByteArrayInputStream(bout.toByteArray())
        val docHash = serviceHub.storageService.attachments.importAttachment(byteInputStrm)
        bout.close()
        byteInputStrm.close()

        return docHash
    }
}

    @InitiatedBy(Initiator::class)
    class Acceptor(val otherParty: Party) : FlowLogic<SignedTransaction>() {
        @Suspendable
        override fun call(): SignedTransaction {
            val signTransactionFlow = object : SignTransactionFlow(otherParty) {
                override fun checkTransaction(stx: SignedTransaction) {}
            }

            return subFlow(signTransactionFlow)
        }
    }
}
