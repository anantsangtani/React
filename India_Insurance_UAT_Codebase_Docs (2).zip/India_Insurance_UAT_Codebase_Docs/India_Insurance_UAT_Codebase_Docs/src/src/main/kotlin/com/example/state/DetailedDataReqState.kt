package com.example.state

import com.example.contract.InsuranceContract
import com.example.model.Policy
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.crypto.entropyToKeyPair
import net.corda.core.crypto.keys
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import org.bouncycastle.asn1.x500.X500Name
import java.math.BigDecimal
import java.math.BigInteger
import java.security.PublicKey
import java.time.LocalDate
import java.time.LocalDateTime
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table
import javax.persistence.UniqueConstraint

/**
 * Created by cordadev on 7/24/2017.
 */

data class DetailedDataReqState(val aadharNo: Long,
                                val reqId:String,
                                val sender: Party,
                                val recipient: Party,
                                val status:String?,
                                val docHash:String?,
                                val docName :String?,
                                override val linearId: UniqueIdentifier = UniqueIdentifier()): LinearState,QueryableState {

    override val contract get() = InsuranceContract()

    /** The public keys of the involved parties. */
    override val participants: List<AbstractParty> get() = listOf(sender, recipient).distinct()

    /** Tells the vault to track a state if we are one of the parties involved. */
    override fun isRelevant(ourKeys: Set<PublicKey>) = ourKeys.intersect(participants.flatMap { it.owningKey.keys }).isNotEmpty()

    override fun generateMappedObject(schema: MappedSchema) = DetailedDataReqState.DetailDataSchemaV1.DetailDataEntity(this)

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(DetailedDataReqState.DetailDataSchemaV1)

    object DetailDataSchemaV1 : MappedSchema(DetailedDataReqState::class.java,1, listOf(DetailedDataReqState.DetailDataSchemaV1.DetailDataEntity::class.java)){

        @Entity
        @Table(name ="detail_data_req"
                //uniqueConstraints = arrayOf(UniqueConstraint(columnNames = arrayOf("reqid")))
        )
        class DetailDataEntity(detailedDataReqState: DetailedDataReqState) : PersistentState(){

            @Column(name = "aadhar_no",nullable = false,length = 12)
            var aadhar:Long = detailedDataReqState.aadharNo
            @Column(name = "reqId",nullable = false,length = 100)
            var reqId:String= detailedDataReqState.reqId
            @Column(name = "sender",length = 100)
            var sender:String?= detailedDataReqState.sender.name.toString()
            @Column(name = "recepient",nullable = false,length = 100)
            var recepient:String?= detailedDataReqState.recipient.name.toString()
            @Column(name = "status",length = 100)
            var status:String?= detailedDataReqState.status
            @Column(name = "docHash",length = 100)
            var docHash:String?= detailedDataReqState.docHash
            @Column(name = "docName",length = 250)
            var docName:String?= detailedDataReqState.docName



            //dummy constructor
            constructor() : this(DetailedDataReqState(12L,reqId = "A001",sender= Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public), recipient =  Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public),status = "",docHash = "",docName = ""))


        }
    }
}