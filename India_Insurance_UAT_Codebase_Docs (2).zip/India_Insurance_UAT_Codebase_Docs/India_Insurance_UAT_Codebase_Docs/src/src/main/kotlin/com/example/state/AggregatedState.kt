package com.example.state

import com.example.contract.InsuranceContract
import com.example.model.AggregatedData
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.crypto.entropyToKeyPair
import net.corda.core.crypto.keys
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import org.bouncycastle.asn1.x500.X500Name
import java.math.BigDecimal
import java.math.BigInteger
import java.security.PublicKey
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.*
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table
import javax.persistence.UniqueConstraint

/**
 * Created by cordadev2 on 7/26/2017.
 */
data class AggregatedState(val aggregatedData: AggregatedData,
                            val sender: Party,
                            val recipient: Party,
                            override val linearId: UniqueIdentifier = UniqueIdentifier()):
        LinearState, QueryableState {
    override val contract get() = InsuranceContract()

    /** The public keys of the involved parties. */
    override val participants: List<AbstractParty> get() = listOf( recipient).distinct()

    /** Tells the vault to track a state if we are one of the parties involved. */
    override fun isRelevant(ourKeys: Set<PublicKey>) = ourKeys.intersect(participants.flatMap { it.owningKey.keys }).isNotEmpty()

    override fun generateMappedObject(schema: MappedSchema)= AggregatedDataSchemaV1.AggregatedDataEntity(this)

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(AggregatedDataSchemaV1)

    object AggregatedDataSchemaV1 : MappedSchema(AggregatedState::class.java,1, listOf(AggregatedDataEntity::class.java)){

        @Entity
        @Table(name ="aggregated_data_detail",
                uniqueConstraints = arrayOf(UniqueConstraint(columnNames = arrayOf("aadhar_no","transaction_id")))
        )
        class AggregatedDataEntity(x : AggregatedState) : PersistentState() {
            @Column(name = "version")
            var version: Int = x.aggregatedData.version
            @Column(name = "aadhar_no")
            var aadhar: Long = x.aggregatedData.aadhar
            @Column(name = "last_NRIstatus")
            var lastNRIStatus: Char?= x.aggregatedData.lastNRIStatus
            @Column(name = "last_KnownEmployment")
            var lastKnownEmployment: String?= x.aggregatedData.lastKnownEmployment
            @Column(name = "last_ResidenceState")
            var lastResidenceState: String?= x.aggregatedData.lastResidenceState
            @Column(name = "last_KnownPAN")
            var lastKnownPAN: String?= x.aggregatedData.lastKnownPAN
            @Column(name = "total_NomineeWisePolicy")
            var totalNomineeWisePolicy: Long?= x.aggregatedData.totalNomineeWisePolicy
            @Column(name = "total_Claim")
            var totalClaim: Long?= x.aggregatedData.totalClaim
            @Column(name = "totalULIPPolicy")
            var totalULIPPolicy: Long?= x.aggregatedData.totalULIPPolicy
            @Column(name = "total_TradPolicy")
            var totalTradPolicy: Long? = x.aggregatedData.totalTradPolicy
            @Column(name = "total_SumAssured")
            var totalSumAssured: BigDecimal? = x.aggregatedData.totalSumAssured
            @Column(name="total_PanNo")
            var totalPanNo: Long?= x.aggregatedData.totalPanNo
            @Column(name="total_RepudiatedClaim")
            var totalRepudiatedClaim: Long? = x.aggregatedData.totalRepudiatedClaim
            @Column(name="ratio")
            var ratio: Double? = x.aggregatedData.ratio
            @Column(name="update_timestamp")
            var updatetimestamp: LocalDateTime? = LocalDateTime.now()
            @Column(name="sender_party")
            var senderParty: String? = x.sender.name.toString()
            /*constructor() : this(AggregatedState(AggregatedData(1234456788,'N',"CTS","WB",
                    "lastKnownPan",10,10,0,10,
                    10,10,2,2,"Y"),Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public),
                    Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public), UniqueIdentifier("45")))*/
            constructor():this(AggregatedState(AggregatedData(0,1234456788 ,'N',"CTS","WB",
                    "lastKnownPan",10,BigDecimal("0.0"),0,10,
                    10,10,2,1.1,"Y"),Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public),
                    Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public), UniqueIdentifier("45")))
          /*  constructor() : this(ClaimDetailState(Claim(4455,"p","c",'s','s','s','c', LocalDate.now(), LocalDateTime.now()),Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public),
                    Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public), UniqueIdentifier("45")))*/
        }

    }
}