package com.example.flow

import co.paralleluniverse.fibers.Suspendable

import com.example.contract.InsuranceContract
import com.example.flow.ExampleFlow.Acceptor
import com.example.flow.ExampleFlow.Initiator
import com.example.model.AggregatedData
import com.example.state.*
import com.example.transaferObject.CombinedStates
import net.corda.core.contracts.*
import net.corda.core.crypto.SecureHash
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.node.services.vault.and
import net.corda.core.node.services.vault.builder
import net.corda.core.transactions.TransactionBuilder

import net.corda.flows.FinalityFlow


/**
 * This flow allows two parties (the [Initiator] and the [Acceptor]) to come to an agreement about the IOU encapsulated
 * within an [IOUState].
 *
 * In our simple example, the [Acceptor] always accepts a valid IOU.
 *
 * These flows have deliberately been implemented by using only the call() method for ease of understanding. In
 * practice we would recommend splitting up the various stages of the flow into sub-routines.
 *
 * All methods called within the [FlowLogic] sub-class need to be annotated with the @Suspendable annotation.
 */
object PolicyHolderAggregationFlow {

    @InitiatingFlow
    @StartableByRPC
    class PrepareAggregateState (val publishedTxnId: String) : FlowLogic<Unit>(){
        //val regulatory = serviceHub.networkMapCache.getNodeByLegalName(X500Name("CN=Consortium,O=ABC,L=Mumbai,C=IND"))!!.legalIdentity

        val point :Long = 1
        val panNo :MutableSet<String?>? = mutableSetOf()

        @Suspendable
        override fun call(): Unit {
            System.out.print("Starting the Aggregate Flow")

            val regulatory = serviceHub.myInfo.legalIdentity
            // Obtain a reference to the notary we want to use.
            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity


            val txBuilder = TransactionBuilder(TransactionType.General, notary)

            val vaultDetailStates = serviceHub.vaultQueryService.queryBy<PolicyHolderPublishState>().states.filter {
                                                                            it.ref.txhash.equals(SecureHash.parse(publishedTxnId)) }

            val policyHolderPublishState = vaultDetailStates.get(0).state.data
            val sender = policyHolderPublishState.sender

            val prevAggregateState =  getPrevAggregatedState(policyHolderPublishState.aadharNo)

            var combinedState = policyHolderAggregateData(vaultDetailStates, prevAggregateState,txBuilder)
            if(combinedState != null)
            {
                if(null!=prevAggregateState) {
                    txBuilder.addInputState(prevAggregateState)
                }

                txBuilder.addOutputState(combinedState.aggregateState)
                if(combinedState.pointState != null){
                    txBuilder.addOutputState(combinedState.pointState!!)
                }
            }

            txBuilder.addInputState(vaultDetailStates.get(0)) // publish state
            val txCommand = Command(InsuranceContract.Commands.AggregateData(), listOf(regulatory).map { it.owningKey })
            txBuilder.addCommand(txCommand)

            txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()

            val signedTx = serviceHub.signInitialTransaction(txBuilder)

            val x = subFlow(FinalityFlow(signedTx, setOf(regulatory,sender))).single()

        }

        private fun getPrevAggregatedState(aadharNo:Long): StateAndRef<AggregatedState>? {

            try {
                val expression1  = builder { AggregatedState.AggregatedDataSchemaV1.AggregatedDataEntity::aadhar.equal(aadharNo)}
                val qryCriteriaAadhar = QueryCriteria.VaultCustomQueryCriteria(expression1)
                val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
                val vaultState = serviceHub.vaultQueryService.queryBy<AggregatedState>(qryCriteriaAadhar.and(qryCriteriaUnconsumed)).states.singleOrNull()
                return vaultState;
            }
            catch(e : Exception){
                System.out.print(e.printStackTrace());
                throw e ;
            }


        }
        private fun getPrevPointState(accountHolder:Party): StateAndRef<PointState>? {

            try {

                val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
                var pointState :StateAndRef<PointState>? =null
                val vaultStates = serviceHub.vaultQueryService.queryBy<PointState>(qryCriteriaUnconsumed).states
                for(vaultState in vaultStates) {
                    if (vaultState.state.data.accountHolder.equals(accountHolder)) {
                        pointState = vaultState
                        break;
                    }
                }
                return  pointState
            }
            catch(e : Exception){
                System.out.print(e.printStackTrace());
                throw e ;
            }


        }


        private fun policyHolderAggregateData(vaultDetailStates: List<StateAndRef<PolicyHolderPublishState>>,
                                              prevAggregateState: StateAndRef<AggregatedState>?, txBuilder: TransactionBuilder):CombinedStates?{
            val regulatory = serviceHub.myInfo.legalIdentity
            var aggregateState:AggregatedState? = null
            var pointState : PointState?=null
            var combinedStates :CombinedStates?=null
            val diffPan = differentPan(vaultDetailStates.get(0).state.data.aadharNo)

            if(null!=prevAggregateState){
            val prevAggregateData = prevAggregateState?.state?.data.aggregatedData

                for (vaultDetailState in vaultDetailStates) {
                    val policyHolderPublishState = vaultDetailState.state.data

                    if (!equal(prevAggregateData, policyHolderPublishState)!!) {

                        aggregateState = AggregatedState(AggregatedData(version = prevAggregateData.version.plus(1), aadhar = policyHolderPublishState.aadharNo,
                                lastNRIStatus = policyHolderPublishState.nriStatus,
                                lastKnownEmployment = policyHolderPublishState.employment,
                                lastResidenceState = policyHolderPublishState.residenceState,
                                lastKnownPAN = policyHolderPublishState.panNo, totalTradPolicy = prevAggregateData.totalTradPolicy,
                                totalSumAssured = prevAggregateData.totalSumAssured, totalULIPPolicy = prevAggregateData.totalULIPPolicy,
                                totalClaim = prevAggregateData.totalClaim, totalRepudiatedClaim = prevAggregateData.totalRepudiatedClaim,
                                totalNomineeWisePolicy = prevAggregateData.totalNomineeWisePolicy, totalPanNo =diffPan!!,
                                ratio = prevAggregateData.ratio, sender = policyHolderPublishState.sender.name.toString()), policyHolderPublishState.sender, regulatory)
                        val prevPointState = getPrevPointState(policyHolderPublishState.sender)
                        if(prevPointState != null) {
                            txBuilder.addInputState(prevPointState)
                            val prevPointData = prevPointState.state?.data
                            /*pointState = PointState(noOfDataContribute=prevPointData?.noOfDataContribute?.plus(point),
                                    pointsEarned =prevPointData?.pointsEarned?.plus(point),issuer=regulatory,accountHolder = policyHolderPublishState.sender)*/
                           /* pointState = PointState(noOfRequestMade=prevPointData?.noOfRequestMade,noOfResponseMade=prevPointData?.noOfResponseMade,
                                    pointsDue=prevPointData?.pointsDue!!,
                                    noOfDataContribute=prevPointData?.noOfDataContribute?.plus(point),netPointBalance=prevPointData?.netPointBalance?.plus(point),
                                    pointsEarned =prevPointData?.pointsEarned?.plus(point),issuer=regulatory,accountHolder = policyHolderPublishState.sender)*/

                            pointState = prevPointData.copy(noOfDataContribute=prevPointData?.noOfDataContribute?.plus(point),netPointBalance=prevPointData?.netPointBalance?.plus(point),
                                    pointsEarned =prevPointData?.pointsEarned?.plus(point))
                        }


                        combinedStates = CombinedStates(aggregateState, pointState)
                    }
                }
            }
            else {

                for (vaultDetailState in vaultDetailStates) {
                    val policyHolderPublishState = vaultDetailState.state.data
                     aggregateState = AggregatedState(AggregatedData(version=0,aadhar = policyHolderPublishState.aadharNo,
                            lastNRIStatus = policyHolderPublishState.nriStatus,
                            lastKnownEmployment = policyHolderPublishState.employment,
                            lastResidenceState = policyHolderPublishState.residenceState,
                            lastKnownPAN = policyHolderPublishState.panNo,totalPanNo =diffPan!!,sender = policyHolderPublishState.sender.name.toString() ), policyHolderPublishState.sender, regulatory)
                    val prevPointState = getPrevPointState(policyHolderPublishState.sender)
                    if(prevPointState != null) {
                        txBuilder.addInputState(prevPointState)
                    }
                    val prevPointData = prevPointState?.state?.data
                    /*pointState = PointState(noOfRequestMade=prevPointData?.noOfRequestMade,noOfResponseMade=prevPointData?.noOfResponseMade,
                            pointsDue=prevPointData?.pointsDue!!,
                            noOfDataContribute=prevPointData?.noOfDataContribute?.plus(point),netPointBalance=prevPointData?.netPointBalance?.plus(point),
                            pointsEarned =prevPointData?.pointsEarned?.plus(point),issuer=regulatory,accountHolder = policyHolderPublishState.sender)*/

                    pointState = prevPointData?.copy(noOfDataContribute=prevPointData?.noOfDataContribute?.plus(point),netPointBalance=prevPointData?.netPointBalance?.plus(point),
                            pointsEarned =prevPointData?.pointsEarned?.plus(point))
                    combinedStates = CombinedStates(aggregateState,pointState)

                }
            }
            return combinedStates
        }



        private fun equal(prevAggregateData:AggregatedData,policyHolderPublishState:PolicyHolderPublishState):Boolean?{
            var boolean:Boolean=false

            if(prevAggregateData.lastKnownEmployment.equals(policyHolderPublishState.employment)) {
                if (prevAggregateData.lastKnownPAN.equals(policyHolderPublishState.panNo)) {
                    if (prevAggregateData.lastNRIStatus?.equals(policyHolderPublishState.nriStatus)!!) {
                        if (prevAggregateData.lastResidenceState?.equals(policyHolderPublishState.residenceState)!!) {
                            boolean = true
                        }
                    }
                }
            }
            return boolean
        }

//When queried then fetch
    private fun differentPan(aadharNo:Long):Long{
        try {
            var size :Long =0
            val expression1  = builder { PolicyHolderPublishState.PolicyHolderPublishSchemaV1.PolicyHolderPublishEntity::aadhar.equal(aadharNo)}
            val qryCriteriaAadhar = QueryCriteria.VaultCustomQueryCriteria(expression1)
            val vaultStates = serviceHub.vaultQueryService.queryBy<PolicyHolderPublishState>(qryCriteriaAadhar)
            if(null!=vaultStates) {
                for (vaultState in vaultStates.states) {
                    panNo?.add(vaultState.state.data.panNo)
                }
                size = panNo?.size!!.toLong();
            }
            return size;
        }
        catch(e : Exception){
            System.out.print(e.printStackTrace());
            throw e ;
        }

    }



    }
}