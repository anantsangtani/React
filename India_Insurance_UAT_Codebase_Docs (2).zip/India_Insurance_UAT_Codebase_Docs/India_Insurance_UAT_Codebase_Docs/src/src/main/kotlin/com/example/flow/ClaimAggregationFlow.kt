package com.example.flow

import co.paralleluniverse.fibers.Suspendable

import com.example.contract.InsuranceContract
import com.example.model.AggregatedData
import com.example.state.*
import com.example.state.ClaimPublishState.ClaimPublishSchemaV1.ClaimPublishEntity
import com.example.transaferObject.CombinedStates
import com.google.common.collect.ImmutableSet

import net.corda.core.contracts.*
import net.corda.core.crypto.SecureHash
import net.corda.core.flows.FlowLogic
import net.corda.core.identity.Party
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.*
import net.corda.core.node.services.vault.Builder.equal
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.flows.FinalityFlow
import org.bouncycastle.asn1.x500.X500Name

object ClaimAggregationFlow {
    class PrepareAggregateState (val publishedTxnId: String): FlowLogic<Unit>(){

        val point :Long =1
        val panNo :MutableSet<String?>? = mutableSetOf()
        @Suspendable
        override fun call(): Unit {
            System.out.print("Starting the Aggregate Flow")
            // Obtain a reference to the notary we want to use.
            val regulatory = serviceHub.myInfo.legalIdentity

            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity
            val txBuilder = TransactionBuilder(TransactionType.General, notary)

            val vaultDetailStates = serviceHub.vaultQueryService.queryBy<ClaimPublishState>().states.filter {
                it.ref.txhash.equals(SecureHash.parse(publishedTxnId)) }
            val claimPublishState = vaultDetailStates.get(0).state.data

            val sender = claimPublishState.sender

            val prevAggregateState =  getPrevAggregatedState(claimPublishState.aadhar)
            var prevAggregateData = prevAggregateState?.state?.data?.aggregatedData
            var aggregateState = claimAggregationState(vaultDetailStates, prevAggregateData!!,txBuilder,regulatory)

            if(null!=prevAggregateState) {
                txBuilder.addInputState(prevAggregateState)
            }

            vaultDetailStates.forEach { txBuilder.addInputState(it) }
            txBuilder.addOutputState(aggregateState)


            val txCommand = Command(InsuranceContract.Commands.AggregateData(), listOf(regulatory).map { it.owningKey })
            txBuilder.addCommand(txCommand)

            txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()

            val signedTx = serviceHub.signInitialTransaction(txBuilder)

            val x = subFlow(FinalityFlow(signedTx, setOf(regulatory,sender))).single()



        }

        private fun getPrevAggregatedState(aadharNo:Long): StateAndRef<AggregatedState>? {

            try {
                val expression1  = builder { AggregatedState.AggregatedDataSchemaV1.AggregatedDataEntity::aadhar.equal(aadharNo)}
                val qryCriteriaAadhar = QueryCriteria.VaultCustomQueryCriteria(expression1)
                val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
                val vaultState = serviceHub.vaultQueryService.queryBy<AggregatedState>(qryCriteriaAadhar.and(qryCriteriaUnconsumed)).states.singleOrNull()
                return vaultState;
            }
            catch(e : Exception){
                System.out.print(e.printStackTrace());
                throw e ;
            }
        }

        private fun claimAggregationState(vaultDetailStates: List<StateAndRef<ClaimPublishState>>,
                                          prevAggregateData: AggregatedData,txBuilder :TransactionBuilder,regulatory :Party):AggregatedState{
            var aggregateState: AggregatedState? = null
            var combinedStates: CombinedStates? = null
            var sender: Party? = null
            var totalClaim = prevAggregateData.totalClaim
            var pointToBeAdded :Long = 0L
            var totalRepudiatedClaim = prevAggregateData.totalRepudiatedClaim
            var pointState: PointState? = null
            for(vaultDetailState in vaultDetailStates) {

                var newClaimPublishState = vaultDetailState.state.data
                var oldClaimPublishStateAndRef = getPrevClaimPublishedState(newClaimPublishState.claimId)
                var oldClaimPublishState : ClaimPublishState

                // txBuilder.inputStates()
                sender = newClaimPublishState.sender
                if (null == oldClaimPublishStateAndRef) {
                    totalClaim = totalClaim.plus(1)
                    pointToBeAdded = pointToBeAdded.plus(point)
                    if (newClaimPublishState.claimStatus.equals('R'))
                        totalRepudiatedClaim = totalRepudiatedClaim.plus(1)

                }else{
                    oldClaimPublishState = oldClaimPublishStateAndRef?.state?.data
                    if(!newClaimPublishState.claimStatus.equals(oldClaimPublishState.claimStatus)){
                        pointToBeAdded = pointToBeAdded.plus(point)
                        if (newClaimPublishState.claimStatus.equals('R')){
                            totalRepudiatedClaim = totalRepudiatedClaim.plus(1)
                        }

                    }else if(!newClaimPublishState.claimSubStatus?.equals(oldClaimPublishState.claimSubStatus)!!
                            || !newClaimPublishState.fraudStatus?.equals(oldClaimPublishState.fraudStatus)!!
                            || !newClaimPublishState.claimDate?.equals(oldClaimPublishState.claimDate)!!){
                                pointToBeAdded = pointToBeAdded.plus(point)
                    }
                }
            }
            val ratio : Double = if(totalClaim>(totalRepudiatedClaim))
                          totalRepudiatedClaim.toDouble().div(totalClaim.toDouble().minus(totalRepudiatedClaim.toDouble()))
                          else prevAggregateData.ratio
            aggregateState = AggregatedState(AggregatedData(version =prevAggregateData.version.plus(1), aadhar = prevAggregateData.aadhar,
                    lastNRIStatus = prevAggregateData.lastNRIStatus,
                    lastKnownEmployment = prevAggregateData.lastKnownEmployment,
                    lastResidenceState = prevAggregateData.lastResidenceState,
                    lastKnownPAN = prevAggregateData.lastKnownPAN, totalTradPolicy = prevAggregateData.totalTradPolicy,
                    totalSumAssured = prevAggregateData.totalSumAssured, totalULIPPolicy = prevAggregateData.totalULIPPolicy,
                    totalClaim = totalClaim, totalRepudiatedClaim = totalRepudiatedClaim,
                    totalNomineeWisePolicy = prevAggregateData.totalNomineeWisePolicy, totalPanNo = prevAggregateData.totalPanNo ,
                    ratio = ratio, sender = sender.toString()), sender!!, regulatory)
            if(pointToBeAdded>0L){
                val prevPointState = getPrevPointState(sender)
                val prevPointData = prevPointState?.state?.data
                //Number of data contributed == Number of points added (Since points for every data contribution is 1)
               /* pointState = PointState(noOfRequestMade=prevPointData?.noOfRequestMade,noOfResponseMade=prevPointData?.noOfResponseMade,
                        pointsDue=prevPointData?.pointsDue!!,
                        noOfDataContribute=prevPointData?.noOfDataContribute?.plus(pointToBeAdded),netPointBalance=prevPointData?.netPointBalance?.plus(pointToBeAdded),
                        pointsEarned =prevPointData?.pointsEarned.plus(pointToBeAdded),issuer=regulatory,accountHolder = sender)*/

                pointState = prevPointData!!.copy(noOfDataContribute=prevPointData?.noOfDataContribute?.plus(pointToBeAdded),netPointBalance=prevPointData?.netPointBalance?.plus(pointToBeAdded),
                        pointsEarned =prevPointData?.pointsEarned.plus(pointToBeAdded))

                txBuilder.addInputState(prevPointState)
                txBuilder.addOutputState(pointState)
            }

            return aggregateState

        }



        private fun getPrevPointState(accountHolder:Party): StateAndRef<PointState>? {

            try {
                val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
                var pointState :StateAndRef<PointState>? =null
                val vaultStates = serviceHub.vaultQueryService.queryBy<PointState>(qryCriteriaUnconsumed).states
                for(vaultState in vaultStates) {
                    if (vaultState.state.data.accountHolder.equals(accountHolder)) {
                        pointState = vaultState
                        break;
                    }
                }
                return  pointState
            }
            catch(e : Exception){
                System.out.print(e.printStackTrace());
                throw e ;
            }
        }

        private fun getPrevClaimPublishedState(claimId:String):StateAndRef<ClaimPublishState>?{

            val expression1  = builder { ClaimPublishState.ClaimPublishSchemaV1.ClaimPublishEntity::claimId.equal(claimId)}
            val sort = Sort.SortColumn(SortAttribute.Custom( ClaimPublishState.ClaimPublishSchemaV1.ClaimPublishEntity::class.java
                    ,"publishTimestamp"),Sort.Direction.DESC)
            val qryCriteriaAadhar = QueryCriteria.VaultCustomQueryCriteria(expression1)
            val qryCriteriaConsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.CONSUMED)
            val vaultStateList = serviceHub.vaultQueryService.queryBy(ClaimPublishState::class.java,qryCriteriaAadhar.and(qryCriteriaConsumed),
                    Sort(ImmutableSet.of(sort)))?.states

            return if(vaultStateList.isNotEmpty()) vaultStateList.get(0) else null;

        }
    }
}