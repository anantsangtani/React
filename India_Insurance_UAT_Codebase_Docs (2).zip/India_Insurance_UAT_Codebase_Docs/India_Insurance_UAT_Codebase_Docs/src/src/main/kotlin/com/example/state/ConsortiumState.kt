package com.example.state

import com.example.contract.ConsortiumContract
import com.example.contract.InsuranceContract
import com.example.model.Claim
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.crypto.entropyToKeyPair
import net.corda.core.crypto.keys
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import org.bouncycastle.asn1.x500.X500Name
import java.math.BigInteger
import java.security.PublicKey
import java.time.LocalDate
import java.time.LocalDateTime
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table
import javax.persistence.UniqueConstraint

/**
 * Created by cordadev on 7/21/2017.
 */

data class ConsortiumState( val consortiumName: String,
                             val listOfParticipants:List<Party>,
                             val creator: Party,
                             override val linearId: UniqueIdentifier = UniqueIdentifier()): LinearState {
    override val contract get() = ConsortiumContract()

    /** The public keys of the involved parties. */
    override val participants: List<AbstractParty> get() = listOfParticipants

    /** Tells the vault to track a state if we are one of the parties involved. */
    override fun isRelevant(ourKeys: Set<PublicKey>) = ourKeys.intersect(participants.flatMap { it.owningKey.keys }).isNotEmpty()



}
