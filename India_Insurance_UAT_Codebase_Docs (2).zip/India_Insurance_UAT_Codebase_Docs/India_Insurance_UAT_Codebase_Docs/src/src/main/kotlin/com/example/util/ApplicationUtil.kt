package com.template.util

import net.corda.core.crypto.X509Utilities
import org.bouncycastle.asn1.x500.X500Name


/**
 * Created by cordadev1 on 6/3/2017.
 */
object ApplicationUtil {

    fun getCommaSeparatedStringFromCollection(collection: Collection<String>?) : String{
        var result = StringBuilder()
        if(null == collection) return result.toString()
        for(item in collection){
            result.append(item).append(",")
        }
        if(result.length > 0){
            result.deleteCharAt(result.length-1)
        }

        return result.toString()
    }

    fun getHyphenSeparatedStringFromCollection(collection: Collection<String>?) : String{
        var result = StringBuilder()
        if(null == collection) return result.toString()
        for(item in collection){
            result.append(item).append("-")
        }
        if(result.length > 0){
            result.deleteCharAt(result.length-1)
        }

        return result.toString()
    }

    fun getRegulatoryName() : X500Name {
        return X509Utilities.getX509Name(ApplicationConstants.REGULATORY_NODE, "Paris", "root@city.fr.example")
    }

    fun  getPartyName(nodeName: String): X500Name {
        var partyName : X500Name = X509Utilities.getX509Name("", "", "")
        if(ApplicationConstants.REGULATORY_NODE.equals(nodeName)){
            partyName = getRegulatoryName()
        } else if(ApplicationConstants.INSURER_1.equals(nodeName)){
            partyName = X509Utilities.getX509Name(ApplicationConstants.INSURER_1, "Rome", "root@city.it.example")
        } else if(ApplicationConstants.INSURER_2.equals(nodeName)){
            partyName = X509Utilities.getX509Name(ApplicationConstants.INSURER_2, "New York", "root@city.us.example")
        } /*else if(ApplicationConstants.ABC_LIFE.equals(nodeName)){
            partyName = X509Utilities.getX509Name(ApplicationConstants.ABC_LIFE, "London", "root@city.uk.example")
        }*/ else if(ApplicationConstants.CONTROLLER.equals(nodeName)){
            partyName = X509Utilities.getX509Name(ApplicationConstants.CONTROLLER, "India", "root@city.in.example")
        }

        return partyName
    }
}