package com.example.state

import com.example.contract.InsuranceContract
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.crypto.entropyToKeyPair
import net.corda.core.crypto.keys
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import org.bouncycastle.asn1.x500.X500Name
import java.math.BigInteger
import java.security.PublicKey
import java.time.LocalDateTime
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table
import javax.persistence.UniqueConstraint

/**
 * Created by cordadev on 7/24/2017.
 */

data class PolicyHolderPublishState(val aadharNo: Long, val panNo:String,
                                    val nriStatus :Char, val employment:String?,
                                    val residenceState :String?,val publishTimeStamp : LocalDateTime,
                                    val sender: Party,
                                    val recipient: Party,
                                    override val linearId: UniqueIdentifier = UniqueIdentifier()): LinearState,QueryableState {

    override val contract get() = InsuranceContract()

    /** The public keys of the involved parties. */
    override val participants: List<AbstractParty> get() = listOf(sender, recipient).distinct()

    /** Tells the vault to track a state if we are one of the parties involved. */
    override fun isRelevant(ourKeys: Set<PublicKey>) = ourKeys.intersect(participants.flatMap { it.owningKey.keys }).isNotEmpty()

    override fun generateMappedObject(schema: MappedSchema) = PolicyHolderPublishSchemaV1.PolicyHolderPublishEntity(this)

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(PolicyHolderPublishSchemaV1)

    object PolicyHolderPublishSchemaV1 : MappedSchema(PolicyHolderPublishState::class.java, 1, listOf(PolicyHolderPublishEntity::class.java)) {

        @Entity
        @Table(name = "policy_holder_publish_data",
                uniqueConstraints = arrayOf(UniqueConstraint(columnNames = arrayOf("aadhar_no","transaction_id")))
        )
        class PolicyHolderPublishEntity(holderPublishState: PolicyHolderPublishState) : PersistentState(){

            @Column(name = "sender_name")
            var senderName: String = holderPublishState.sender.name.toString()
            @Column(name = "aadhar_no",nullable = false,length = 12)
            var aadhar: Long = holderPublishState.aadharNo
            @Column(name = "pan_no",nullable = false,length = 10)
            var pan:String= holderPublishState.panNo
            @Column(name = "residence_state",length = 20)
            var state:String?= holderPublishState.residenceState
            @Column(name = "nri_status",nullable = false,length = 1)
            var nriStatus:Char= holderPublishState.nriStatus
            @Column(name = "employment",length = 100)
            var employment:String?= holderPublishState.employment
            @Column(name="publish_timestamp")
            var publishTimestamp: LocalDateTime? = holderPublishState.publishTimeStamp

            constructor() : this(PolicyHolderPublishState(11,"a",'c',"s","d", LocalDateTime.now(),Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public),
                    Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public), UniqueIdentifier("45")))

        }



    }




}