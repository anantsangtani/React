package com.example.flow

import co.paralleluniverse.fibers.Suspendable

import com.example.contract.InsuranceContract
import com.example.model.AggregatedData
import com.example.state.*
import com.example.transaferObject.CombinedStates
import com.example.transaferObject.ResultComparePolicyState
import com.google.common.collect.ImmutableSet
import net.corda.core.contracts.*
import net.corda.core.crypto.SecureHash
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.*
import net.corda.core.transactions.TransactionBuilder
import net.corda.flows.FinalityFlow
import java.math.BigDecimal
import java.util.*

object PolicyAggregationFlow {
    @InitiatingFlow
    @StartableByRPC
    class PrepareAggregateState (val publishedTxnId: String): FlowLogic<Unit>() {

        val point : Long = 1
        @Suspendable
        override fun call(): Unit {
            System.out.print("Starting the Aggregate Flow for Policy")
            //val regulatory = serviceHub.networkMapCache.getNodeByLegalName(X500Name("CN=Consortium,O=ABC,L=Mumbai,C=IND"))!!.legalIdentity
            val regulatory = serviceHub.myInfo.legalIdentity

            // Obtain a reference to the notary we want to use.
            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity
            val txBuilder = TransactionBuilder(TransactionType.General, notary)

            val vaultDetailStates = serviceHub.vaultQueryService.queryBy<PolicyPublishState>().states.filter {
                it.ref.txhash.equals(SecureHash.parse(publishedTxnId)) }

           // val vaultDetailStates = vaultStorageTxn.tx.outputs
            val policyPublishState = vaultDetailStates.get(0).state.data
            val sender = policyPublishState.sender

            val prevAggregateState =  getPrevAggregatedState(policyPublishState.aadhar)
            var prevAggregateData  = prevAggregateState?.state?.data?.aggregatedData
            var aggregateState = policyAggregateData(vaultDetailStates, prevAggregateData!!,txBuilder,regulatory)
            if(null!=prevAggregateState) {
                txBuilder.addInputState(prevAggregateState)
            }
            //add all the incoming published states in the input
            vaultDetailStates.forEach { txBuilder.addInputState(it) }

            // add point input and output state //TODO
            //

            txBuilder.addOutputState(aggregateState)

            val txCommand = Command(InsuranceContract.Commands.AggregateData(), listOf(regulatory).map { it.owningKey })
            txBuilder.addCommand(txCommand)

            txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()

            val signedTx = serviceHub.signInitialTransaction(txBuilder)

            val x = subFlow(FinalityFlow(signedTx, setOf(regulatory,sender))).single()

            System.out.print("Policy Aggregate Flow completed with tx id :"+x.id)
        }


        private fun getPrevAggregatedState(aadharNo:Long): StateAndRef<AggregatedState>? {

            try {
                val expression1  = builder { AggregatedState.AggregatedDataSchemaV1.AggregatedDataEntity::aadhar.equal(aadharNo)}
                val qryCriteriaAadhar = QueryCriteria.VaultCustomQueryCriteria(expression1)
                val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
                val vaultState = serviceHub.vaultQueryService.queryBy<AggregatedState>(qryCriteriaAadhar.and(qryCriteriaUnconsumed)).states.singleOrNull()
                return vaultState;
            }
            catch(e : Exception){
                System.out.print(e.printStackTrace());
                throw e ;
            }


        }


        private fun getPrevPointState(accountHolder:Party): StateAndRef<PointState>? {

            try {

                val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
                var pointState :StateAndRef<PointState>? =null
                val vaultStates = serviceHub.vaultQueryService.queryBy<PointState>(qryCriteriaUnconsumed).states
                for(vaultState in vaultStates) {
                    if (vaultState.state.data.accountHolder.equals(accountHolder)) {
                        pointState = vaultState
                        break;
                    }
                }
                return  pointState
            }
            catch(e : Exception){
                System.out.print(e.printStackTrace());
                throw e ;
            }


        }


        private fun policyAggregateData(vaultDetailStates: List<StateAndRef<PolicyPublishState>>, prevAggregateData: AggregatedData,
                                        txbuilder:TransactionBuilder, regulatory:Party): AggregatedState {
            var aggregateState: AggregatedState? = null

            var combinedStates: CombinedStates? = null
            var noOfTradPolicy: Long = prevAggregateData.totalTradPolicy
            var noOfULIPPolicy: Long = prevAggregateData.totalULIPPolicy
            var sumAssured: BigDecimal = prevAggregateData.totalSumAssured
            var aadharNo: Long = 0
            var sender: Party = (vaultDetailStates.get(0).state.data.sender)
            var pointToBeAdded :Long = 0L

            var pointState: PointState? = null
            val hashMap: MutableMap<String, Long> = mutableMapOf<String, Long>()
            hashMap.put("TRAD", noOfTradPolicy)
            hashMap.put("ULIP", noOfULIPPolicy)

            if (null != prevAggregateData) {

                for (vaultDetailState in vaultDetailStates) {

                    val newPolicyPublishData = (vaultDetailState.state.data)
                    val oldPolicyPublishedState = getPolicyPublishedState(policyNo = newPolicyPublishData.policyNo)
                    aadharNo = newPolicyPublishData.aadhar


                    if(null==oldPolicyPublishedState) {
                        pointToBeAdded = pointToBeAdded.plus(point)
                        if (newPolicyPublishData.productType.equals('T')) {
                            noOfTradPolicy=noOfTradPolicy!!.plus(1)
                            hashMap.put("TRAD", noOfTradPolicy)

                        }
                        else if (newPolicyPublishData.productType.equals('U')) {
                            noOfULIPPolicy=noOfULIPPolicy!!.plus(1)
                            hashMap.put("ULIP", noOfULIPPolicy)

                        }
                        sumAssured = sumAssured?.plus(newPolicyPublishData.sumAssured)
                    }
                    else{
                        var diffSumAssured :BigDecimal=BigDecimal("0.0")
                        var oldPolicyPublishedData = oldPolicyPublishedState?.state?.data!!
                        var resultComparePolicyState=  equal(oldPolicyPublishedData,newPolicyPublishData)
                        if(!resultComparePolicyState?.isSumAssuredSame!! || !resultComparePolicyState?.isProductType!! ||
                                !resultComparePolicyState?.isNomineeName!! || !resultComparePolicyState?.isUnderPassport!!){
                            pointToBeAdded = pointToBeAdded.plus(1)

                            diffSumAssured=newPolicyPublishData.sumAssured.minus(oldPolicyPublishedData.sumAssured)
                        }

                        if(newPolicyPublishData.sumAssured>oldPolicyPublishedData.sumAssured)
                            sumAssured = sumAssured.plus(diffSumAssured.abs())
                        else if(newPolicyPublishData.sumAssured<oldPolicyPublishedData.sumAssured)
                            sumAssured = sumAssured.minus(diffSumAssured.abs())
                    }
                }
                val nomineeWisePolicy = policyCalculation(aadharNo)
                aggregateState = AggregatedState(AggregatedData(version =prevAggregateData.version.plus(1), aadhar = prevAggregateData.aadhar,
                        lastNRIStatus = prevAggregateData.lastNRIStatus,
                        lastKnownEmployment = prevAggregateData.lastKnownEmployment,
                        lastResidenceState = prevAggregateData.lastResidenceState,
                        lastKnownPAN = prevAggregateData.lastKnownPAN, totalTradPolicy = hashMap.get("TRAD")!!,
                        totalSumAssured = sumAssured, totalULIPPolicy = hashMap.get("ULIP")!!,
                        totalClaim = prevAggregateData.totalClaim, totalRepudiatedClaim = prevAggregateData.totalRepudiatedClaim,
                        totalNomineeWisePolicy = nomineeWisePolicy, totalPanNo = prevAggregateData.totalPanNo ,
                        ratio = prevAggregateData.ratio, sender = sender.toString()), sender!!, regulatory)
                if(pointToBeAdded>0L){
                    val prevPointState = getPrevPointState(sender)
                    val prevPointData = prevPointState?.state?.data
                    txbuilder.addInputState(prevPointState!!)
                    //Number of data contributed == Number of points added (Since points for every data contribution is 1)
                   /* pointState = PointState(noOfRequestMade=prevPointData?.noOfRequestMade,noOfResponseMade=prevPointData?.noOfResponseMade,
                            pointsDue=prevPointData?.pointsDue!!,
                            noOfDataContribute=prevPointData?.noOfDataContribute?.plus(pointToBeAdded),netPointBalance=prevPointData?.netPointBalance?.plus(pointToBeAdded),
                            pointsEarned =prevPointData?.pointsEarned?.plus(pointToBeAdded),issuer=regulatory,accountHolder = sender)*/

                    pointState = prevPointData!!.copy(noOfDataContribute=prevPointData?.noOfDataContribute?.plus(pointToBeAdded),netPointBalance=prevPointData?.netPointBalance?.plus(pointToBeAdded),
                            pointsEarned =prevPointData?.pointsEarned?.plus(pointToBeAdded))

                    txbuilder.addOutputState(pointState)
                }

            }
            return aggregateState!!
        }


        //policy type ki change hbe jodi hoi then ki hbe
        //aadhar attached to policy ki change hbe hole ki hbe
        private fun equal(oldPolicyPublishData: PolicyPublishState,newPolicyPublishData: PolicyPublishState):ResultComparePolicyState?{

            var resultComparePolicyState  = ResultComparePolicyState ()
            if(oldPolicyPublishData.sumAssured ==(newPolicyPublishData.sumAssured))
                resultComparePolicyState.isSumAssuredSame = true
            if(oldPolicyPublishData.productType.equals(newPolicyPublishData.productType))
                resultComparePolicyState.isProductType = true
             if(oldPolicyPublishData.nomineeName.equals(newPolicyPublishData.nomineeName))
                resultComparePolicyState.isNomineeName = true
             if(oldPolicyPublishData.underPassport.equals(newPolicyPublishData.underPassport))
                resultComparePolicyState.isUnderPassport = true
            return resultComparePolicyState
        }

        private fun getPolicyPublishedState(policyNo:String):StateAndRef<PolicyPublishState>?{

            val expression1  = builder { PolicyPublishState.PolicyPublishSchemaV1.PolicyPublishEntity::policyNo.equal(policyNo)}
            val sort = Sort.SortColumn(SortAttribute.Custom(PolicyPublishState.PolicyPublishSchemaV1.PolicyPublishEntity::class.java
                    ,"publishTimestamp"),Sort.Direction.DESC)
            val qryCriteriaAadhar = QueryCriteria.VaultCustomQueryCriteria(expression1)
            val qryCriteriaConsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.CONSUMED)
            val vaultStateList = serviceHub.vaultQueryService.queryBy(PolicyPublishState::class.java,qryCriteriaAadhar.and(qryCriteriaConsumed),
                                                                                                    Sort(ImmutableSet.of(sort)))?.states

            return if(vaultStateList.isNotEmpty()) vaultStateList.get(0) else null;
        }

        private fun policyCalculation(aadharNo: Long):Long {

            var policyMap: MutableMap<String, Long> = mutableMapOf()
            var totalNomineeWisePolicy: Long = 0

            val policyStates = serviceHub.vaultQueryService.queryBy<PolicyPublishState>()
            val policyStateList = policyStates.states

            for (policyStateAndRef in policyStateList) {
                val policyStateData = policyStateAndRef.state.data
                if (policyStateData.aadhar.equals(aadharNo) ) {
                    val nomineeWisePolicyCount = 1L
                    if(policyMap.containsKey(policyStateData.nomineeName)){
                        policyMap.put(policyStateData.nomineeName, policyMap.get(policyStateData.nomineeName)!!.plus(nomineeWisePolicyCount))
                    }else{
                        policyMap.put(policyStateData.nomineeName, nomineeWisePolicyCount)
                    }

                }

            }
            val valueSet = policyMap.values.toList()
            Collections.sort(valueSet, Collections.reverseOrder())




            return valueSet.get(0)
        }
    }
}