package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.model.AggregatedData
import com.example.state.AggregatedState
import com.example.transaferObject.AuditTrail
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.StartableByRPC
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.node.services.vault.and
import net.corda.core.node.services.vault.builder
import org.jetbrains.exposed.sql.transactions.TransactionManager
import java.sql.Connection
import java.sql.Timestamp
import java.time.LocalDateTime

object ConsortiumAggregateQueryDataFlow{

    @StartableByRPC
    class getAggregatedView(val aadharNo : Long,val toDate:LocalDateTime,val fromDate: LocalDateTime) : FlowLogic<AggregatedData?>() {

        @Suspendable
        override fun call(): AggregatedData? {
            System.out.println("********* inside AggregateQueryFlow initiator ************")

            val exp1 = builder { AggregatedState.AggregatedDataSchemaV1.AggregatedDataEntity::aadhar.equal(aadharNo) }
            val aadharCriteria = QueryCriteria.VaultCustomQueryCriteria(exp1)
            val unconsumedCriteria = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
            val aggregatedStateAndRef = serviceHub.vaultQueryService.queryBy<AggregatedState>(aadharCriteria.and(unconsumedCriteria)).states.singleOrNull()

            var result :AggregatedData? = null
            if(aggregatedStateAndRef != null){
             result = aggregatedStateAndRef.state?.data?.aggregatedData?.let {
                    val listOfAggregateData = getAggregateData(aadharNo,toDate,fromDate)
                    var auditTrails = compareAggregateDataChange(listOfAggregateData)
                    it.aggregateAuditTrail = auditTrails
                    it as AggregatedData
                }
            }
            return result
        }
    }


        private fun getAggregateData( aadharNo : Long,toDate:LocalDateTime,fromDate: LocalDateTime):List<AggregatedData> {
            var listOfAggregateData = mutableListOf<AggregatedData>()
            var aggregateData : AggregatedData? = null
            val listOfAggregatedData = "select VERSION,AADHAR_NO,LAST_NRISTATUS,LAST_KNOWNEMPLOYMENT,LAST_RESIDENCESTATE,LAST_KNOWNPAN,TOTAL_NOMINEEWISEPOLICY," +
                    "TOTAL_CLAIM,TOTALULIPPOLICY,TOTAL_TRADPOLICY,TOTAL_SUMASSURED,TOTAL_PANNO,TOTAL_REPUDIATEDCLAIM,RATIO,UPDATE_TIMESTAMP,SENDER_PARTY from AGGREGATED_DATA_DETAIL " +
                    " where AADHAR_NO = ? and UPDATE_TIMESTAMP > ? and UPDATE_TIMESTAMP < ?  order by VERSION"

            val conn = getDbConnection()
            val ps = conn.prepareStatement(listOfAggregatedData)
            ps.setLong(1, aadharNo)
            val parsedToDate = toDate
            val parsedFromDate = fromDate

            ps.setTimestamp(2,Timestamp.valueOf(fromDate))
            ps.setTimestamp(3, Timestamp.valueOf(toDate))
            val rs = ps.executeQuery()
            while (rs.next()) {

                aggregateData = AggregatedData(rs.getInt("version"),rs.getLong("aadhar_no"),
                                               rs.getString("last_nristatus").get(0),rs.getString("last_knownemployment"),
                                               rs.getString("last_residencestate") ,rs.getString("last_knownpan")  ,
                                               rs.getLong("total_tradpolicy"),rs.getBigDecimal("total_sumassured"),
                                               rs.getLong("totalulippolicy"), rs.getLong("total_claim"),rs.getLong("total_repudiatedclaim"),
                                               rs.getLong("total_nomineewisepolicy"),rs.getLong("total_panno"),
                        rs.getDouble("ratio"),rs.getString("sender_party"),rs.getTimestamp("UPDATE_TIMESTAMP").toLocalDateTime())


                listOfAggregateData.add(aggregateData)
            }
         return listOfAggregateData
        }


    private fun compareAggregateDataChange( listOfAggregateData : List<AggregatedData>) :MutableList<AuditTrail>{
        var listOfAuditTrail = mutableListOf<AuditTrail>()
        var allListOfAuditTrail = mutableListOf<AuditTrail>()

        var counter = 0

        if(!listOfAggregateData.isEmpty()) {
            for (i in 0..listOfAggregateData.size - 2) {
                var j = i + 1
                listOfAuditTrail = compare(listOfAggregateData.get(i), listOfAggregateData.get(j),listOfAuditTrail)
            }
        }
            allListOfAuditTrail.addAll(listOfAuditTrail)
            return allListOfAuditTrail
        }

    private fun compare(firstAggregateState: AggregatedData, secondAggregatedData: AggregatedData, listOfAuditTrail: MutableList<AuditTrail>):MutableList<AuditTrail> {
        var auditTrail : AuditTrail? = null

        if(!firstAggregateState.aadhar.equals(secondAggregatedData.aadhar)) {
            auditTrail = AuditTrail("Aadhar No",firstAggregateState.aadhar.toString(),secondAggregatedData.aadhar.toString(),secondAggregatedData.updatedTimeStamp!!,secondAggregatedData.sender.split(",")[0].substring(3))
            listOfAuditTrail.add(auditTrail)
        }

        if(!firstAggregateState.lastNRIStatus?.equals(secondAggregatedData.lastNRIStatus)!!) {
            auditTrail = AuditTrail("NRI Status",firstAggregateState.lastNRIStatus.toString(),secondAggregatedData.lastNRIStatus.toString(),secondAggregatedData.updatedTimeStamp!!,secondAggregatedData.sender.split(",")[0].substring(3))
            listOfAuditTrail.add(auditTrail)
        }
        if(!firstAggregateState.lastResidenceState?.equals(secondAggregatedData.lastResidenceState)!!) {
            auditTrail = AuditTrail("Residence State",firstAggregateState.lastResidenceState.toString(),secondAggregatedData.lastResidenceState.toString(),secondAggregatedData.updatedTimeStamp!!,secondAggregatedData.sender.split(",")[0].substring(3))
            listOfAuditTrail.add(auditTrail)
        }
        if(!firstAggregateState.lastKnownPAN.equals(secondAggregatedData.lastKnownPAN)) {
            auditTrail = AuditTrail("Pan No",firstAggregateState.lastKnownPAN.toString(),secondAggregatedData.lastKnownPAN.toString(),secondAggregatedData.updatedTimeStamp!!,secondAggregatedData.sender.split(",")[0].substring(3))
            listOfAuditTrail.add(auditTrail)
        }
        if(!firstAggregateState.lastKnownEmployment.equals(secondAggregatedData.lastKnownEmployment)) {
            auditTrail = AuditTrail("Employment",firstAggregateState.lastKnownEmployment.toString(),secondAggregatedData.lastKnownEmployment.toString(),secondAggregatedData.updatedTimeStamp!!,secondAggregatedData.sender.split(",")[0].substring(3))
            listOfAuditTrail.add(auditTrail)
        }
        if(!firstAggregateState.totalNomineeWisePolicy.equals(secondAggregatedData.totalNomineeWisePolicy)) {
            auditTrail = AuditTrail("NomineeWisePolicy",firstAggregateState.totalNomineeWisePolicy.toString(),secondAggregatedData.totalNomineeWisePolicy.toString(),secondAggregatedData.updatedTimeStamp!!,secondAggregatedData.sender.split(",")[0].substring(3))
            listOfAuditTrail.add(auditTrail)
        }
        if(!firstAggregateState.totalTradPolicy.equals(secondAggregatedData.totalTradPolicy)) {
            auditTrail = AuditTrail("TradePolicies",firstAggregateState.totalTradPolicy.toString(),secondAggregatedData.totalTradPolicy.toString(),secondAggregatedData.updatedTimeStamp!!,secondAggregatedData.sender.split(",")[0].substring(3))
            listOfAuditTrail.add(auditTrail)
        }
        if(!firstAggregateState.totalULIPPolicy.equals(secondAggregatedData.totalULIPPolicy)) {
            auditTrail = AuditTrail("UlipPolicies",firstAggregateState.totalULIPPolicy.toString(),secondAggregatedData.totalULIPPolicy.toString(),secondAggregatedData.updatedTimeStamp!!,secondAggregatedData.sender.split(",")[0].substring(3))
            listOfAuditTrail.add(auditTrail)
        }
        if(firstAggregateState.totalSumAssured!=(secondAggregatedData.totalSumAssured)) {
            auditTrail = AuditTrail("Sum Assured",firstAggregateState.totalSumAssured.toString(),secondAggregatedData.totalSumAssured.toString(),secondAggregatedData.updatedTimeStamp!!,secondAggregatedData.sender.split(",")[0].substring(3))
            listOfAuditTrail.add(auditTrail)
        }
        if(!firstAggregateState.totalClaim.equals(secondAggregatedData.totalClaim)) {
            auditTrail = AuditTrail("TotalClaims",firstAggregateState.totalClaim.toString(),secondAggregatedData.totalClaim.toString(),secondAggregatedData.updatedTimeStamp!!,secondAggregatedData.sender.split(",")[0].substring(3))
            listOfAuditTrail.add(auditTrail)
        }
        if(firstAggregateState.totalRepudiatedClaim!=(secondAggregatedData.totalRepudiatedClaim)) {
            auditTrail = AuditTrail("Repudiated Claim",firstAggregateState.totalRepudiatedClaim.toString(),secondAggregatedData.totalRepudiatedClaim.toString(),secondAggregatedData.updatedTimeStamp!!,secondAggregatedData.sender.split(",")[0].substring(3))
            listOfAuditTrail.add(auditTrail)
        }
        if(firstAggregateState.ratio!=(secondAggregatedData.ratio)) {
            auditTrail = AuditTrail("Ratio",firstAggregateState.ratio.toString(),secondAggregatedData.ratio.toString(),secondAggregatedData.updatedTimeStamp!!,secondAggregatedData.sender.split(",")[0].substring(3))
            listOfAuditTrail.add(auditTrail)
        }
        return listOfAuditTrail

    }

        private fun getDbConnection(): Connection {
            val dbTxn = TransactionManager.Companion.current()
            val con = dbTxn.connection
            return con
        }

}