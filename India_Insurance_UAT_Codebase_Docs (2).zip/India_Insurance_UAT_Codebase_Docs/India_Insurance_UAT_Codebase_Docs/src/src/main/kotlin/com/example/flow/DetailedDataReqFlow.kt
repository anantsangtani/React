package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.contract.IOUContract
import com.example.contract.InsuranceContract
import com.example.model.IOU
import com.example.model.PolicyHolder
import com.example.state.DetailedDataReqState
import com.example.state.IOUState
import com.example.state.PolicyHolderDetailState
import com.example.state.PolicyPublishState
import net.corda.core.contracts.Command
import net.corda.core.contracts.TransactionType
import net.corda.core.crypto.SecureHash
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatedBy
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.node.services.queryBy
import net.corda.core.transactions.SignedTransaction
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.core.utilities.unwrap
import net.corda.flows.CollectSignaturesFlow
import net.corda.flows.FinalityFlow
import net.corda.flows.SignTransactionFlow
import org.bouncycastle.asn1.x500.X500Name
import java.time.LocalDate
import java.time.LocalDateTime

object DetailedDataReqFlow {

    @InitiatingFlow
    @StartableByRPC
    class Initiator(val aadharNo: Long, val reqId:String, val recipient: Party) : FlowLogic<Unit>()    {
        /**
         * The progress tracker checkpoints each stage of the flow and outputs the specified messages when each
         * checkpoint is reached in the code. See the 'progressTracker.currentStep' expressions within the call() function.
         */
        companion object {
            object GENERATING_TRANSACTION : ProgressTracker.Step("Generating transaction based on new IOU.")
            object VERIFYING_TRANSACTION : ProgressTracker.Step("Verifying contract constraints.")
            object SIGNING_TRANSACTION : ProgressTracker.Step("Signing transaction with our private key.")
            object GATHERING_SIGS : ProgressTracker.Step("Gathering the counterparty's signature.") {
                override fun childProgressTracker() = CollectSignaturesFlow.tracker()
            }

            object FINALISING_TRANSACTION : ProgressTracker.Step("Obtaining notary signature and recording transaction.") {
                override fun childProgressTracker() = FinalityFlow.tracker()
            }

            fun tracker() = ProgressTracker(
                    GENERATING_TRANSACTION,
                    VERIFYING_TRANSACTION,
                    SIGNING_TRANSACTION,
                    GATHERING_SIGS,
                    FINALISING_TRANSACTION
            )
        }

        override val progressTracker = tracker()

        /**
         * The flow logic is encapsulated within the call() method.
         */
        @Suspendable
        override fun call(): Unit {
            // Obtain a reference to the notary we want to use.
            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity

            // Stage 1.
            progressTracker.currentStep = GENERATING_TRANSACTION
            // Generate an unsigned transaction.

            val me =serviceHub.myInfo.legalIdentity
            val regulatory = serviceHub.networkMapCache.getNodeByLegalName(X500Name("CN=Consortium,O=ABC,L=Mumbai,C=IND"))!!.legalIdentity
             var  withinConsortium= subFlow(ConsortiumFlow.withinConsortium(me,recipient))
            var status=""
            if(withinConsortium)
            {
                 status="REQUESTED"
            }
            else
            {
                status="PENDING APPROVAL"
            }

            val detailedDataReqState = DetailedDataReqState(aadharNo,reqId,me,recipient,status,null,null)


            val txCommand = Command(InsuranceContract.Commands.RequestDetail(),detailedDataReqState.participants.map { it.owningKey } )
           // val txCommand1 = Command(InsuranceContract.Commands.StorePolicyHolder(),policyDetailState.participants.map { it.owningKey } )
            val txBuilder = TransactionBuilder(TransactionType.General, notary).withItems(detailedDataReqState, txCommand)

            // Stage 2.
            progressTracker.currentStep = VERIFYING_TRANSACTION
            // Verify that the transaction is valid.
            txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()

            // Stage 3.
            progressTracker.currentStep = SIGNING_TRANSACTION
            // Sign the transaction.
            val partSignedTx = serviceHub.signInitialTransaction(txBuilder)

            // Stage 4.
           // progressTracker.currentStep = GATHERING_SIGS
            // Send the state to the counterparty, and receive it back with their signature.

           // val fullySignedTx = subFlow(CollectSignaturesFlow(partSignedTx, GATHERING_SIGS.childProgressTracker()))

            // Stage 5.
            //progressTracker.currentStep = FINALISING_TRANSACTION
            // Notarise and record the transaction in both parties' vaults.
            //val setOfParties = mutableSetOf<Party>(otherParty)
           // return subFlow(FinalityFlow(fullySignedTx,FINALISING_TRANSACTION.childProgressTracker())).single()
            send(recipient,partSignedTx)
        }
    }

    @InitiatedBy(Initiator::class)
    class Acceptor(val otherParty: Party) : FlowLogic<Unit>() {
        @Suspendable
        override fun call(): Unit {
            // Prep.
            // Obtain a reference to our public key.
            val publicKey = serviceHub.legalIdentityKey
            // Obtain a reference to the notary we want to use and its public key.
            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity
            val notaryPubKey = notary.owningKey


            // All messages come off the wire as UntrustworthyData. You need to 'unwrap' them. This is where you
            // validate what you have just received.

            val partSignedTx = receive<SignedTransaction>(otherParty).unwrap { partSignedTxn ->
                               val wireTx = partSignedTxn.verifySignatures(publicKey, notaryPubKey)
                               // Run the contract's verify function.
                               // We want to be sure that the agreed-upon IOU is valid under the rules of the contract.
                               // To do this we need to run the contract's verify() function.
                               wireTx.toLedgerTransaction(serviceHub).verify()
                               partSignedTxn
                           }

            val fullySignedTx = serviceHub.addSignature(partSignedTx)

            val finalTxn = subFlow(FinalityFlow(fullySignedTx)).single()
            System.out.print("transaction id for detail query"+finalTxn)

            val vaultDetailStates = serviceHub.vaultQueryService.queryBy<DetailedDataReqState>().states.filter {
                it.ref.txhash.equals((finalTxn.tx.id)) }

for(vaultDetailState in vaultDetailStates) {
  if (vaultDetailState.state.data.status.equals("REQUESTED"))
  {
    subFlow(DetailedDataRespFlow.Initiator(vaultDetailState.state.data.aadharNo,vaultDetailState.state.data.reqId,otherParty))
  }
}



        }
    }
}