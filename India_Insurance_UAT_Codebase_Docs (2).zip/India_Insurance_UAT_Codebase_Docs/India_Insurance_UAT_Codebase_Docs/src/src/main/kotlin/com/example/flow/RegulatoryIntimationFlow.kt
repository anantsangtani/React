package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import net.corda.core.contracts.StateRef
import net.corda.core.crypto.SecureHash
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatedBy
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.utilities.unwrap

object RegulatoryIntimationFlow {
    @InitiatingFlow
    @StartableByRPC
    class Initiator(val publishedTxnId: String, val regulatory:Party,val publishDataType :String) : FlowLogic<Unit>() {
        @Suspendable
        override fun call(){
            val data = Pair(publishedTxnId,publishDataType)
            send(regulatory,data)
        }

    }

    @InitiatedBy(Initiator::class)
    class Acceptor(val otherParty: Party) : FlowLogic<Unit>() {
        @Suspendable
        override fun call() {

             receive<Pair<String,String>>(otherParty).unwrap {
                System.out.println("********** inside receive of the RegulatoryIntimationFlow ************* when I am :"+serviceHub.myInfo.legalIdentity)
               // System.out.println("!!!! received data :"+it.first+"----publish state count :"+it.second.size)
                val publishedTxnId = it.first
                val publishDataType = it.second
                 if("POLICY_HOLDER".equals(publishDataType))
                     subFlow(PolicyHolderAggregationFlow.PrepareAggregateState(publishedTxnId))
                 else if("POLICY".equals(publishDataType))
                     subFlow(PolicyAggregationFlow.PrepareAggregateState(publishedTxnId))
                 else if("CLAIM".equals(publishDataType))
                     subFlow(ClaimAggregationFlow.PrepareAggregateState(publishedTxnId))
                 else if("IOU".equals(publishDataType))
                     subFlow(PointCreditDebitFlow.Initiator(publishedTxnId))
            }
        }
    }

}