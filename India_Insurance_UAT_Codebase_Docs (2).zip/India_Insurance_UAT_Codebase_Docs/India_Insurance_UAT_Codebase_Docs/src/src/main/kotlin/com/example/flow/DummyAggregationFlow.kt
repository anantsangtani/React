package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.contract.InsuranceContract
import com.example.model.AggregatedData
import com.example.model.Policy
import com.example.state.AggregatedState
import com.example.state.PolicyHolderPublishState
import net.corda.core.contracts.Command
import net.corda.core.contracts.TransactionType
import net.corda.core.crypto.SecureHash
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.flows.StateMachineRunId
import net.corda.core.node.services.queryBy
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.flows.CollectSignaturesFlow
import net.corda.flows.FinalityFlow
import java.math.BigDecimal

object DummyAggregationFlow {

    @InitiatingFlow
    @StartableByRPC
    class Initiator(val publishedTxnId: String) : FlowLogic<Unit>() {
        /**
         * The progress tracker checkpoints each stage of the flow and outputs the specified messages when each
         * checkpoint is reached in the code. See the 'progressTracker.currentStep' expressions within the call() function.
         */
        companion object {
            object GENERATING_TRANSACTION : ProgressTracker.Step("Generating transaction based on new IOU.")
            object VERIFYING_TRANSACTION : ProgressTracker.Step("Verifying contract constraints.")
            object SIGNING_TRANSACTION : ProgressTracker.Step("Signing transaction with our private key.")
            object GATHERING_SIGS : ProgressTracker.Step("Gathering the counterparty's signature.") {
                override fun childProgressTracker() = CollectSignaturesFlow.tracker()
            }

            object FINALISING_TRANSACTION : ProgressTracker.Step("Obtaining notary signature and recording transaction.") {
                override fun childProgressTracker() = FinalityFlow.tracker()
            }

            fun tracker() = ProgressTracker(
                    GENERATING_TRANSACTION,
                    VERIFYING_TRANSACTION,
                    SIGNING_TRANSACTION,
                    GATHERING_SIGS,
                    FINALISING_TRANSACTION
            )
        }

        override val progressTracker = tracker()

        /**
         * The flow logic is encapsulated within the call() method.
         */
        @Suspendable
        override fun call() {

            System.out.println("=============Inside DummyAggregationFlow ===========")

            val vaultStates = serviceHub.vaultQueryService.queryBy<PolicyHolderPublishState>().states.filter {
                it.ref.txhash.equals(SecureHash.parse(publishedTxnId)) }


            // Obtain a reference to the notary we want to use.
            val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity

            // Stage 1.
            progressTracker.currentStep = GENERATING_TRANSACTION
            // Generate an unsigned transaction.
            val txBuilder = TransactionBuilder(TransactionType.General, notary)

           // val x = vaultStates.get(0).data as PolicyHolderPublishState
            val me = serviceHub.myInfo.legalIdentity
            for (vaultState in vaultStates) {
               val x = vaultState.state.data
                //add output state
                val phOutputState = AggregatedState(AggregatedData(1, x.aadharNo, x.nriStatus, x.employment, x.residenceState, x.panNo,
                        12, BigDecimal("10000.0"), 22, 50, 12,
                        10, 10, 10.5, me.toString()), me, me)
                txBuilder.addOutputState(phOutputState)
            }
            val txCommand = Command(InsuranceContract.Commands.AggregateData(), me.owningKey)
            txBuilder.addCommand(txCommand)

            // Stage 2.
            progressTracker.currentStep = VERIFYING_TRANSACTION
            // Verify that the transaction is valid.
            txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()

            // Stage 3.
            progressTracker.currentStep = SIGNING_TRANSACTION
            // Sign the transaction.
            val partSignedTx = serviceHub.signInitialTransaction(txBuilder)

            // Stage 5.
            progressTracker.currentStep = FINALISING_TRANSACTION
            // Notarise and record the transaction in both parties' vaults.
            val vaultStorageTxn = subFlow(FinalityFlow(partSignedTx, FINALISING_TRANSACTION.childProgressTracker())).single()

            System.out.println("Aggegated Record committed to vault with id " + vaultStorageTxn.id.toString())

        }

    }
}