package com.example.model

import net.corda.core.serialization.CordaSerializable

/**
 * Created by cordadev on 7/19/2017.
 */
@CordaSerializable
data class PolicyHolder(val aadhar: Long,val pan:String,val gender:Char,val firstName :String?,val middleName:String?,
                        val lastName :String,val dob :java.time.LocalDate,val address :String?,val state :String?,
                        val nriStatus :Char, val education :String?,val employment:String?,val pincode:Int?,val uploadTimestamp:java.time.LocalDateTime?)

