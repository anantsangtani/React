package com.example.state

import com.example.contract.InsuranceContract
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.crypto.entropyToKeyPair
import net.corda.core.crypto.keys
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import org.bouncycastle.asn1.x500.X500Name
import java.math.BigInteger
import java.security.PublicKey
import java.time.LocalDate
import java.time.LocalDateTime
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table
import javax.persistence.UniqueConstraint

/**
 * Created by cordadev on 7/26/2017.
 */

data class PointState(val noOfRequestMade: Long?=0,
                      val noOfResponseMade: Long?=0,
                      val noOfDataContribute: Long?=0,
                      val pointsEarned: Long = 0,
                      val pointsDue: Long = 0,
                      val netPointBalance: Long ?= pointsEarned.minus(pointsDue),
                      val issuer: Party, val accountHolder: Party,
                      override val linearId: UniqueIdentifier = UniqueIdentifier(),
                      val noOfAggregateQry :Long = 0,
                      val latestAggregateQryDate : LocalDate? = null) : LinearState, QueryableState {

    override val contract get() = InsuranceContract()

    /** The public keys of the involved parties. */
    override val participants: List<AbstractParty> get() = listOf(accountHolder,issuer)

    /** Tells the vault to track a state if we are one of the parties involved. */
    override fun isRelevant(ourKeys: Set<PublicKey>) = ourKeys.intersect(participants.flatMap { it.owningKey.keys }).isNotEmpty()


    override fun generateMappedObject(schema: MappedSchema) = PointSchemaV1.PointEntity(this)

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(PointSchemaV1)

    object PointSchemaV1 : MappedSchema(PointState::class.java, 1, listOf(PointEntity::class.java)) {

        @Entity
        @Table(name = "point_state_detail")
        class PointEntity(pointState: PointState) : PersistentState(){

            @Column(name = "no_of_req_made")
            var noOfRequestMade: Long? = pointState.noOfRequestMade
            @Column(name = "no_of_resp_made")
            var noOfResponseMade: Long?=pointState.noOfResponseMade
            @Column(name = "no_of_data_contribute")
            var noOfDataContribute: Long?=pointState.noOfDataContribute
            @Column(name = "points_earned")
            var pointsEarned: Long = pointState.pointsEarned
            @Column(name = "points_due")
            var pointsDue: Long = pointState.pointsDue
            @Column(name = "net_point_balance")
            var netPointBalance: Long ?= pointState.netPointBalance
            @Column(name = "issuer")
            var issuer: String = pointState.issuer.name.toString()
            @Column(name = "account_holder")
            var accountHolder: String=pointState.accountHolder.name.toString()
            @Column(name = "no_of_aggregate_qry")
            var noOfAggregateQry :Long = pointState.noOfAggregateQry
            @Column(name = "latest_aggregate_qry_dt")
            var latestAggregateQryDate : LocalDate? = pointState.latestAggregateQryDate
            @Column(name = "update_timestamp")
            var updateTimestamp : LocalDateTime = LocalDateTime.now()

            constructor() : this(PointState(0,0,0,0,0,0,
                    Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public),
                    Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public), UniqueIdentifier("45"),0, LocalDate.now()))



        }



    }
}