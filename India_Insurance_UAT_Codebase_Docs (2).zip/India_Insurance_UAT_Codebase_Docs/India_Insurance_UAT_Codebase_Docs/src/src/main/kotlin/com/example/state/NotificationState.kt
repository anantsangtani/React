package com.example.state

import com.example.contract.InsuranceContract
import net.corda.core.contracts.Contract
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.crypto.keys
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import java.security.PublicKey
import java.time.LocalDate

data class NotificationState(val notifier : Party,
                             val aadharNo: Long,
                             val deathClaimRaiseDate: LocalDate,
                             val participantList : List<Party>,
                             override val linearId: UniqueIdentifier = UniqueIdentifier()) : LinearState{

    override val contract get() = InsuranceContract()

    /** The public keys of the involved parties. */
    override val participants: List<AbstractParty> get() = participantList

    /** Tells the vault to track a state if we are one of the parties involved. */
    override fun isRelevant(ourKeys: Set<PublicKey>) = ourKeys.intersect(participants.flatMap { it.owningKey.keys }).isNotEmpty()

}