package com.example.transaferObject

import com.example.state.AggregatedState
import com.example.state.PointState

data class CombinedStates (val aggregateState:AggregatedState,val pointState:PointState?){


}