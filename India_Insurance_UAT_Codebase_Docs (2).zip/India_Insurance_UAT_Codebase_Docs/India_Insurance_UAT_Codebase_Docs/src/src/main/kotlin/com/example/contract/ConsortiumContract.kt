package com.example.contract

import net.corda.core.contracts.CommandData
import net.corda.core.contracts.Contract
import net.corda.core.contracts.TransactionForContract
import net.corda.core.crypto.SecureHash

/**
 * Created by cordadev on 7/19/2017.
 */

open class ConsortiumContract : Contract {
    override val legalContractReference: SecureHash
        get() = SecureHash.sha256("Consortium contract")

    override fun verify(tx: TransactionForContract) {

       // System.out.print("Inside contract verify")
    }

    interface Commands : CommandData {
       
        class CreateConsortium : Commands
        class DeleteConsortium : Commands

    }
}