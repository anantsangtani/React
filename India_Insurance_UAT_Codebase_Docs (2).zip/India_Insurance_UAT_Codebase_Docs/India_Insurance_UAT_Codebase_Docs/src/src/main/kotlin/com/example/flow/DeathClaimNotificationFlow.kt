package com.example.flow

import co.paralleluniverse.fibers.Suspendable
import com.example.contract.InsuranceContract
import com.example.state.NotificationState
import net.corda.core.contracts.Command
import net.corda.core.contracts.TransactionType
import net.corda.core.flows.FlowLogic
import net.corda.core.flows.InitiatingFlow
import net.corda.core.flows.StartableByRPC
import net.corda.core.identity.Party
import net.corda.core.node.services.Vault
import net.corda.core.node.services.queryBy
import net.corda.core.node.services.vault.QueryCriteria
import net.corda.core.transactions.TransactionBuilder
import net.corda.core.utilities.ProgressTracker
import net.corda.flows.CollectSignaturesFlow
import net.corda.flows.FinalityFlow
import java.time.LocalDate
import kotlin.streams.toList

object DeathClaimNotificationFlow{
    @InitiatingFlow
    @StartableByRPC
    class Initiator(val aadharNo: Long) : FlowLogic<Unit>() {
        /**
         * The progress tracker checkpoints each stage of the flow and outputs the specified messages when each
         * checkpoint is reached in the code. See the 'progressTracker.currentStep' expressions within the call() function.
         */
        companion object {
            object GENERATING_TRANSACTION : ProgressTracker.Step("Generating transaction based on new IOU.")
            object VERIFYING_TRANSACTION : ProgressTracker.Step("Verifying contract constraints.")
            object SIGNING_TRANSACTION : ProgressTracker.Step("Signing transaction with our private key.")
            object GATHERING_SIGS : ProgressTracker.Step("Gathering the counterparty's signature.") {
                override fun childProgressTracker() = CollectSignaturesFlow.tracker()
            }

            object FINALISING_TRANSACTION : ProgressTracker.Step("Obtaining notary signature and recording transaction.") {
                override fun childProgressTracker() = FinalityFlow.tracker()
            }

            fun tracker() = ProgressTracker(
                    GENERATING_TRANSACTION,
                    VERIFYING_TRANSACTION,
                    SIGNING_TRANSACTION,
                    GATHERING_SIGS,
                    FINALISING_TRANSACTION
            )
        }

        override val progressTracker = tracker()

        /**
         * The flow logic is encapsulated within the call() method.
         */
        @Suspendable
        override fun call() {

            if(!isDeathNotificationPresent(aadharNo)){
                // Obtain a reference to the notary we want to use.
                val notary = serviceHub.networkMapCache.notaryNodes.single().notaryIdentity
                // Stage 1.
                progressTracker.currentStep = GENERATING_TRANSACTION
                val me = serviceHub.myInfo.legalIdentity

                var participantList = mutableListOf<Party>()
                participantList.add(me)
                participantList.addAll(serviceHub.networkMapCache.partyNodes.stream().map { it.legalIdentity }
                        .filter { !it.name.toString().equals("CN=Controller,O=R3,OU=corda,L=London,C=UK") }.toList())

                val notificationState = NotificationState(me,aadharNo, LocalDate.now(),participantList)

                val txCommand = Command(InsuranceContract.Commands.PublishDeathNotification(),me.owningKey )

                val txBuilder = TransactionBuilder(TransactionType.General, notary)
                txBuilder.addCommand(txCommand)
                txBuilder.addOutputState(notificationState)
                // Stage 2.
                progressTracker.currentStep = VERIFYING_TRANSACTION
                // Verify that the transaction is valid.
                txBuilder.toWireTransaction().toLedgerTransaction(serviceHub).verify()

                // Stage 3.
                progressTracker.currentStep = SIGNING_TRANSACTION
                // Sign the transaction.
                val partSignedTx = serviceHub.signInitialTransaction(txBuilder)
                // Stage 4.
                progressTracker.currentStep = FINALISING_TRANSACTION
                // Notarise and record the transaction in both parties' vaults.
                val x = subFlow(FinalityFlow(partSignedTx,FINALISING_TRANSACTION.childProgressTracker())).single()

                System.out.println("Death claim notification transaction committed with id :"+x.id)
            }

        }

        private fun isDeathNotificationPresent(aadharNo: Long): Boolean {

            try {
                val qryCriteriaUnconsumed = QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED)
                val vaultStateCount = serviceHub.vaultQueryService.queryBy<NotificationState>(qryCriteriaUnconsumed).states.filter { it.state.data.aadharNo.equals(aadharNo) }.size
                return vaultStateCount != 0
            }
            catch(e : Exception){
                System.out.print(e.printStackTrace());
                throw e ;
            }
        }

    }

    /*@InitiatedBy(Initiator::class)
    class Acceptor(val otherParty: Party) : FlowLogic<SignedTransaction>() {
        @Suspendable
        override fun call(): SignedTransaction {
            val signTransactionFlow = object : SignTransactionFlow(otherParty) {
                override fun checkTransaction(stx: SignedTransaction){}
            }

            return subFlow(signTransactionFlow)
        }
    }*/
}