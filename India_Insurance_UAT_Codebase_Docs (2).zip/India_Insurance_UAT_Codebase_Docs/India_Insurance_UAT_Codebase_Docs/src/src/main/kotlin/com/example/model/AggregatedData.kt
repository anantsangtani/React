package com.example.model

import com.example.transaferObject.AuditTrail
import net.corda.core.serialization.CordaSerializable
import java.math.BigDecimal
import java.math.BigInteger
import java.sql.ClientInfoStatus
import java.time.LocalDateTime

/**
 * Created by cordadev2 on 7/25/2017.
 */
@CordaSerializable
data class AggregatedData(val version:Int=0, val aadhar:Long, val lastNRIStatus: Char?=null, val lastKnownEmployment:String?=null,
                          val lastResidenceState :String?=null, val lastKnownPAN:String?=null, val totalTradPolicy: Long=0,
                          val totalSumAssured :BigDecimal=BigDecimal("0.0"), val totalULIPPolicy :Long=0,
                          val totalClaim:Long=0, val totalRepudiatedClaim :Long=0, val totalNomineeWisePolicy :Long=0,
                          val totalPanNo :Long=0, val ratio:Double=0.0, val sender:String,val updatedTimeStamp: LocalDateTime? = LocalDateTime.now(),
                          var monthWiseSumAssuredMap : MutableMap<String,Double> = mutableMapOf(),
                          var monthWiseClaimCountMap : MutableMap<String,Double> = mutableMapOf(),
                          var aggregateAuditTrail:MutableList<AuditTrail> = mutableListOf())

