package com.example.contract

import com.example.state.DetailedDataReqState
import com.example.state.IOUState
import net.corda.core.contracts.*
import net.corda.core.crypto.SecureHash

/**
 * A implementation of a basic smart contract in Corda.
 *
 * This contract enforces rules regarding the creation of a valid [IOUState], which in turn encapsulates an [IOU].
 *
 * For a new [IOU] to be issued onto the ledger, a transaction is required which takes:
 * - Zero input states.
 * - One output state: the new [IOU].
 * - An Create() command with the public keys of both the sender and the recipient.
 *
 * All contracts must sub-class the [Contract] interface.
 */
open class IOUContract : Contract {
    /**
     * The verify() function of all the states' contracts must not throw an exception for a transaction to be
     * considered valid.
     */
    override fun verify(tx: TransactionForContract) {
        val commands = tx.commands
        for(command in commands) {
            if (command.value is Commands.Create) {
                requireThat {

                    "One input should be consumed" using (tx.inputs.size == 1)
                    "Only one output state is expected" using (tx.outputs.size == 2)
                    "Attachment must be present" using (tx.attachments.size == 1)
                    "IOU state should be present" using (tx.outputs.get(0) is IOUState)
                    "DetailDataReqState state should be present" using (tx.outputs.get(1) is DetailedDataReqState)
                    //val output = outputs as DetailedDataReqState


                    "All participants should sign the transaction in IOU" using (tx.outputs.get(0).participants.containsAll(command.signingParties))
                }
            } /*else if (command.value is Commands.Redeem) {

            }*/
        }
        //  val command = tx.commands.requireSingleCommand<Commands.Create>()
    }

    /**
     * This contract only implements one command, Create.
     */
    interface Commands : CommandData {
        class Create : Commands
        class Redeem : Commands
    }

    /** This is a reference to the underlying legal contract template and associated parameters. */
    override val legalContractReference: SecureHash = SecureHash.sha256("IOU contract template and params")
}
