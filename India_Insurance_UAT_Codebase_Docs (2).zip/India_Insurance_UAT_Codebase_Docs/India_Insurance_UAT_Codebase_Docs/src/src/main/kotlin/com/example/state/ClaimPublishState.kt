package com.example.state

import com.example.contract.InsuranceContract
import com.example.model.Claim
import net.corda.core.contracts.LinearState
import net.corda.core.contracts.UniqueIdentifier
import net.corda.core.crypto.entropyToKeyPair
import net.corda.core.crypto.keys
import net.corda.core.identity.AbstractParty
import net.corda.core.identity.Party
import net.corda.core.schemas.MappedSchema
import net.corda.core.schemas.PersistentState
import net.corda.core.schemas.QueryableState
import org.bouncycastle.asn1.x500.X500Name
import java.math.BigInteger
import java.security.PublicKey
import java.time.LocalDate
import java.time.LocalDateTime
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Table
import javax.persistence.UniqueConstraint

/**
 * Created by cordadev on 7/24/2017.
 */


data class ClaimPublishState(val aadhar: Long,val claimId :String, val claimStatus:Char,
                             val claimSubStatus:Char?, val fraudStatus:Char?,
                             val claimDate: LocalDate, val publishTimeStamp : LocalDateTime,
                              val sender: Party,val recipient: Party,
                              override val linearId: UniqueIdentifier = UniqueIdentifier()): LinearState,QueryableState {
    override val contract get() = InsuranceContract()

    /** The public keys of the involved parties. */
    override val participants: List<AbstractParty> get() = listOf(sender, recipient).distinct()

    /** Tells the vault to track a state if we are one of the parties involved. */
    override fun isRelevant(ourKeys: Set<PublicKey>) = ourKeys.intersect(participants.flatMap { it.owningKey.keys }).isNotEmpty()


    override fun generateMappedObject(schema: MappedSchema)= ClaimPublishSchemaV1.ClaimPublishEntity(this)

    override fun supportedSchemas(): Iterable<MappedSchema> = listOf(ClaimPublishSchemaV1)

    object ClaimPublishSchemaV1 : MappedSchema(ClaimPublishState::class.java,1, listOf(ClaimPublishEntity::class.java)){

        @Entity
        @Table(name ="claim_publish_data",
                uniqueConstraints = arrayOf(UniqueConstraint(columnNames = arrayOf("claim_id","transaction_id")))
        )
        class ClaimPublishEntity(x : ClaimPublishState) : PersistentState() {

            @Column(name = "aadhar_no", nullable = false, length = 12)
            var aadhar: Long = x.aadhar
            @Column(name = "claim_id", nullable = false)
            var claimId: String? = x.claimId
            @Column(name = "claim_status", nullable = false, length = 1)
            var claimStatus: Char = x.claimStatus
            @Column(name = "claim_sub_status", length = 1)
            var claimSubStatus: Char? = x.claimSubStatus
            @Column(name = "fraud_status", length = 1)
            var fraudStatus: Char? = x.fraudStatus
            @Column(name = "claim_date", nullable = false)
            var claimDate: LocalDate = x.claimDate
            @Column(name="publish_timestamp")
            var publishTimestamp: LocalDateTime? = x.publishTimeStamp
            @Column(name = "sender", nullable = false)
            var sender: String?= x.sender.toString()

            constructor() : this(ClaimPublishState(4455,"p",'s','s','s', LocalDate.now(),LocalDateTime.now(),Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public),
                    Party(X500Name("CN=Bank C,O=Bank C,L=Tokyo,C=JP"), entropyToKeyPair(BigInteger.valueOf(60)).public), UniqueIdentifier("45")))

        }

    }

}